<?php
$page_title = 'Dashboard';
require 'includes/auth.php';
require 'includes/db.php';
require 'includes/functions.php';

requireLogin();

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch last 5 trips
$stmt = $conn->prepare("SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$recent_trips = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch stats: total_trips
$stmt = $conn->prepare("SELECT COUNT(*) AS total_trips FROM trips WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_trips = $stmt->get_result()->fetch_assoc()['total_trips'];
$stmt->close();

// Fetch stats: packing_items
$stmt = $conn->prepare("SELECT COUNT(*) AS packing_items FROM packing_items pi JOIN trips t ON pi.trip_id = t.id WHERE t.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$packing_items = $stmt->get_result()->fetch_assoc()['packing_items'];
$stmt->close();

// Fetch stats: total_notes
$stmt = $conn->prepare("SELECT COUNT(*) AS total_notes FROM trip_notes tn JOIN trips t ON tn.trip_id = t.id WHERE t.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_notes = $stmt->get_result()->fetch_assoc()['total_notes'];
$stmt->close();

// Fetch 3 popular cities
$stmt = $conn->prepare("SELECT name, country, image_url FROM cities WHERE popular = 1 LIMIT 3");
$stmt->execute();
$popular_cities = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch upcoming trips (start_date >= today, LIMIT 3)
$stmt = $conn->prepare("SELECT * FROM trips WHERE user_id = ? AND start_date >= CURDATE() ORDER BY start_date ASC LIMIT 3");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$upcoming_trips = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Determine greeting
$hour = (int)date('H');
if ($hour < 12) {
    $greeting = 'Morning';
} elseif ($hour < 17) {
    $greeting = 'Afternoon';
} else {
    $greeting = 'Evening';
}

$first_name = htmlspecialchars($user['name'] ?? $user['username'] ?? 'Traveller');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            color: #1a1a2e;
            min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* NAV */
        header { background: #0f172a; box-shadow: 0 2px 20px rgba(0,0,0,0.3); position: sticky; top:0; z-index:100; }
        header nav { display:flex; justify-content:space-between; align-items:center; padding:0 40px; height:64px; }
        .logo { font-size:20px; font-weight:800; color:#fff; display:flex; align-items:center; gap:8px; }
        .nav-menu { display:flex; list-style:none; gap:6px; align-items:center; }
        .nav-menu a { color:rgba(255,255,255,0.70); text-decoration:none; font-size:14px; font-weight:500; padding:8px 14px; border-radius:8px; transition:all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color:#fff; background:rgba(255,255,255,0.10); }
        .nav-menu .nav-cta a { background:linear-gradient(135deg,#667eea,#764ba2); color:#fff !important; }

        /* HERO */
        .hero {
            position:relative; overflow:hidden;
            background: linear-gradient(135deg, rgba(8,15,50,0.82) 0%, rgba(25,8,60,0.88) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 60px 40px 50px;
            margin-bottom: 0;
        }
        .hero::after {
            content:''; position:absolute; bottom:0; left:0; right:0; height:60px;
            background: linear-gradient(to bottom, transparent, #f0f2f8);
        }
        .hero-inner { max-width:1200px; margin:0 auto; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:30px; }
        .hero-left {}
        .hero-greeting { font-size:13px; font-weight:600; color:rgba(255,255,255,0.55); letter-spacing:1px; text-transform:uppercase; margin-bottom:10px; }
        .hero-title { font-size:36px; font-weight:900; color:#fff; line-height:1.15; margin-bottom:12px; text-shadow:0 2px 12px rgba(0,0,0,0.4); }
        .hero-title span { background:linear-gradient(135deg,#a78bfa,#60a5fa); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
        .hero-sub { font-size:15px; color:rgba(255,255,255,0.60); margin-bottom:28px; }
        .hero-btns { display:flex; gap:12px; flex-wrap:wrap; }
        .btn-hero-primary { padding:12px 28px; background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; border-radius:10px; text-decoration:none; font-weight:700; font-size:14px; box-shadow:0 4px 18px rgba(102,126,234,0.45); transition:transform 0.2s,box-shadow 0.2s; }
        .btn-hero-primary:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(102,126,234,0.55); }
        .btn-hero-outline { padding:12px 28px; background:rgba(255,255,255,0.10); color:#fff; border:1.5px solid rgba(255,255,255,0.25); border-radius:10px; text-decoration:none; font-weight:600; font-size:14px; backdrop-filter:blur(8px); transition:background 0.2s; }
        .btn-hero-outline:hover { background:rgba(255,255,255,0.18); }

        /* Hero stats */
        .hero-stats { display:flex; gap:20px; flex-wrap:wrap; }
        .hero-stat { background:rgba(255,255,255,0.10); backdrop-filter:blur(12px); border:1px solid rgba(255,255,255,0.15); border-radius:14px; padding:20px 28px; text-align:center; min-width:110px; }
        .hero-stat-num { font-size:30px; font-weight:900; color:#fff; line-height:1; }
        .hero-stat-label { font-size:12px; color:rgba(255,255,255,0.55); margin-top:5px; font-weight:500; }

        /* MAIN CONTENT */
        main { max-width:1200px; margin:0 auto; padding:40px 24px 60px; }

        /* Section header */
        .sec-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
        .sec-title { font-size:18px; font-weight:800; color:#fff; display:flex; align-items:center; gap:8px; text-shadow:0 1px 4px rgba(0,0,0,0.4); }
        .sec-link { font-size:13px; color:#a5b4fc; text-decoration:none; font-weight:600; }
        .sec-link:hover { text-decoration:underline; color:#fff; }

        /* QUICK ACTIONS */
        .actions-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:16px; margin-bottom:40px; }
        .action-card { background:rgba(255,255,255,0.12); backdrop-filter:blur(12px); border:1px solid rgba(255,255,255,0.18); border-radius:14px; padding:24px 16px; text-align:center; text-decoration:none; transition:all 0.25s; }
        .action-card:hover { transform:translateY(-4px); background:rgba(255,255,255,0.20); border-color:rgba(255,255,255,0.40); box-shadow:0 8px 24px rgba(0,0,0,0.25); }
        .action-icon { font-size:34px; margin-bottom:10px; display:block; }
        .action-label { font-size:13px; font-weight:700; color:#fff; }

        /* TWO COLUMN LAYOUT */
        .two-col { display:grid; grid-template-columns:1fr 360px; gap:28px; margin-bottom:40px; }

        /* CARDS */
        .card { background:rgba(255,255,255,0.10); backdrop-filter:blur(16px); border:1px solid rgba(255,255,255,0.16); border-radius:14px; overflow:hidden; }
        .card-header { padding:18px 24px; border-bottom:1px solid rgba(255,255,255,0.12); display:flex; align-items:center; justify-content:space-between; }
        .card-header h3 { font-size:15px; font-weight:700; color:#fff; }
        .card-body { padding:0; }

        table.dash-table { width:100%; border-collapse:collapse; }
        .dash-table th { padding:12px 20px; text-align:left; font-size:12px; font-weight:700; color:#888; text-transform:uppercase; letter-spacing:0.5px; background:#fafbff; border-bottom:1px solid #f0f0f0; }
        .dash-table td { padding:14px 20px; border-bottom:1px solid #f8f8f8; font-size:14px; color:#444; }
        .dash-table tbody tr:last-child td { border-bottom:none; }
        .dash-table tbody tr:hover td { background:#fafbff; }
        .trip-name-cell { font-weight:600; color:#1a1a2e; }
        .status-badge { display:inline-block; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:700; }
        .status-draft     { background:#fff3cd; color:#856404; }
        .status-published { background:#d4edda; color:#155724; }
        .status-shared    { background:#d1ecf1; color:#0c5460; }
        .btn-sm { padding:6px 14px; background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; border-radius:6px; text-decoration:none; font-size:12px; font-weight:600; transition:opacity 0.2s; }
        .btn-sm:hover { opacity:0.85; }

        /* EMPTY STATE */
        .empty-box { padding:40px 20px; text-align:center; }
        .empty-box .empty-icon { font-size:48px; margin-bottom:12px; }
        .empty-box p { color:#aaa; font-size:14px; margin-bottom:16px; }

        /* RIGHT SIDEBAR */
        /* Upcoming trips */
        .upcoming-list { padding:8px 0; }
        .upcoming-item { display:flex; align-items:center; gap:14px; padding:14px 20px; border-bottom:1px solid #f8f8f8; transition:background 0.2s; }
        .upcoming-item:last-child { border-bottom:none; }
        .upcoming-item:hover { background:#fafbff; }
        .upcoming-date-box { width:46px; height:46px; border-radius:10px; background:linear-gradient(135deg,#667eea,#764ba2); display:flex; flex-direction:column; align-items:center; justify-content:center; flex-shrink:0; }
        .upcoming-day { font-size:16px; font-weight:900; color:#fff; line-height:1; }
        .upcoming-mon { font-size:10px; color:rgba(255,255,255,0.75); font-weight:600; text-transform:uppercase; }
        .upcoming-info { flex:1; min-width:0; }
        .upcoming-name { font-size:14px; font-weight:600; color:#1a1a2e; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .upcoming-days-left { font-size:12px; color:#888; margin-top:2px; }

        /* POPULAR CITIES */
        .cities-row { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:40px; }
        .city-mini { border-radius:12px; overflow:hidden; position:relative; height:140px; cursor:pointer; text-decoration:none; display:block; }
        .city-mini img { width:100%; height:100%; object-fit:cover; transition:transform 0.35s; }
        .city-mini:hover img { transform:scale(1.08); }
        .city-mini-overlay { position:absolute; inset:0; background:linear-gradient(to top,rgba(0,0,0,0.70) 0%,transparent 55%); display:flex; align-items:flex-end; padding:12px; }
        .city-mini-name { color:#fff; font-size:14px; font-weight:700; }
        .city-mini-country { color:rgba(255,255,255,0.70); font-size:11px; }

        /* TIPS CARD */
        .tips-list { list-style:none; padding:16px 20px; display:flex; flex-direction:column; gap:12px; }
        .tips-list li { display:flex; gap:10px; font-size:13px; color:#555; line-height:1.5; }
        .tip-icon { font-size:16px; flex-shrink:0; }

        /* FOOTER */
        footer { background:#0f172a; color:rgba(255,255,255,0.45); text-align:center; padding:24px; font-size:13px; margin-top:0; }

        /* RESPONSIVE */
        @media (max-width:900px) { .two-col { grid-template-columns:1fr; } .cities-row { grid-template-columns:repeat(2,1fr); } }
        @media (max-width:600px) { header nav { padding:0 16px; } .hero { padding:40px 20px 36px; } .hero-title { font-size:26px; } main { padding:28px 16px 40px; } .actions-grid { grid-template-columns:repeat(2,1fr); } .cities-row { grid-template-columns:1fr 1fr; } }
    </style>
</head>
<body>

<!-- ===== HEADER / NAV ===== -->
<header>
    <nav>
        <div class="logo">✈️ Travel Planner</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>
            <li><a href="my-trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?>
            <li><a href="admin/index.php">Admin</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<!-- ===== HERO ===== -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-left">
            <p class="hero-greeting">Good <?php echo $greeting; ?>, <?php echo $first_name; ?>!</p>
            <h1 class="hero-title">Your Travel<br><span>Dashboard</span></h1>
            <p class="hero-sub">Track your adventures, plan new journeys, and explore the world.</p>
            <div class="hero-btns">
                <a href="create-trip.php" class="btn-hero-primary">➕ Plan New Trip</a>
                <a href="city-search.php" class="btn-hero-outline">🌍 Explore Cities</a>
            </div>
        </div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-num"><?php echo (int)$total_trips; ?></div>
                <div class="hero-stat-label">🗺️ Trips</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-num"><?php echo (int)$total_notes; ?></div>
                <div class="hero-stat-label">📝 Notes</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-num"><?php echo (int)$packing_items; ?></div>
                <div class="hero-stat-label">🧳 Items</div>
            </div>
        </div>
    </div>
</section>

<!-- ===== MAIN ===== -->
<main>

    <!-- QUICK ACTIONS -->
    <div class="sec-header">
        <h2 class="sec-title">⚡ Quick Actions</h2>
    </div>
    <div class="actions-grid">
        <a href="create-trip.php" class="action-card">
            <span class="action-icon">➕</span>
            <span class="action-label">Create Trip</span>
        </a>
        <a href="city-search.php" class="action-card">
            <span class="action-icon">🌍</span>
            <span class="action-label">Search Cities</span>
        </a>
        <a href="activity-search.php" class="action-card">
            <span class="action-icon">🎯</span>
            <span class="action-label">Activities</span>
        </a>
        <a href="budget.php" class="action-card">
            <span class="action-icon">💰</span>
            <span class="action-label">Budget</span>
        </a>
        <a href="packing.php" class="action-card">
            <span class="action-icon">🧳</span>
            <span class="action-label">Packing</span>
        </a>
        <a href="notes.php" class="action-card">
            <span class="action-icon">📝</span>
            <span class="action-label">Notes</span>
        </a>
        <a href="itinerary.php" class="action-card">
            <span class="action-icon">🗺️</span>
            <span class="action-label">Itinerary</span>
        </a>
        <a href="profile.php" class="action-card">
            <span class="action-icon">👤</span>
            <span class="action-label">Profile</span>
        </a>
    </div>

    <!-- TWO COLUMN: RECENT TRIPS + SIDEBAR -->
    <div class="two-col">

        <!-- LEFT: Recent Trips -->
        <div class="card">
            <div class="card-header">
                <h3>🧭 Recent Trips</h3>
                <a href="my-trips.php" class="sec-link">View all →</a>
            </div>
            <div class="card-body">
                <?php if (!empty($recent_trips)): ?>
                <table class="dash-table">
                    <thead>
                        <tr>
                            <th>Trip Name</th>
                            <th>Start Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_trips as $trip): ?>
                        <tr>
                            <td class="trip-name-cell"><?php echo htmlspecialchars($trip['title'] ?? $trip['name'] ?? 'Untitled'); ?></td>
                            <td><?php echo !empty($trip['start_date']) ? htmlspecialchars(date('M j, Y', strtotime($trip['start_date']))) : '—'; ?></td>
                            <td>
                                <?php
                                $status = strtolower($trip['status'] ?? 'draft');
                                $badge_class = 'status-draft';
                                if ($status === 'published') $badge_class = 'status-published';
                                elseif ($status === 'shared') $badge_class = 'status-shared';
                                ?>
                                <span class="status-badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars(ucfirst($status)); ?></span>
                            </td>
                            <td><a href="trip-detail.php?id=<?php echo (int)$trip['id']; ?>" class="btn-sm">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="empty-box">
                    <div class="empty-icon">🗺️</div>
                    <p>You haven't created any trips yet.</p>
                    <a href="create-trip.php" class="btn-sm">Create your first trip!</a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- RIGHT SIDEBAR -->
        <div style="display:flex; flex-direction:column; gap:24px;">

            <!-- Upcoming Trips -->
            <div class="card">
                <div class="card-header">
                    <h3>📅 Upcoming Trips</h3>
                </div>
                <div class="card-body">
                    <?php if (!empty($upcoming_trips)): ?>
                    <div class="upcoming-list">
                        <?php foreach ($upcoming_trips as $trip):
                            $start = strtotime($trip['start_date']);
                            $days_away = (int)ceil(($start - time()) / 86400);
                            $day_num = date('j', $start);
                            $month_str = date('M', $start);
                        ?>
                        <div class="upcoming-item">
                            <div class="upcoming-date-box">
                                <span class="upcoming-day"><?php echo $day_num; ?></span>
                                <span class="upcoming-mon"><?php echo $month_str; ?></span>
                            </div>
                            <div class="upcoming-info">
                                <div class="upcoming-name"><?php echo htmlspecialchars($trip['title'] ?? $trip['name'] ?? 'Untitled'); ?></div>
                                <div class="upcoming-days-left">
                                    <?php if ($days_away === 0): ?>
                                        Today!
                                    <?php elseif ($days_away === 1): ?>
                                        Tomorrow
                                    <?php else: ?>
                                        <?php echo $days_away; ?> days away
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="empty-box" style="padding:24px 20px;">
                        <div class="empty-icon" style="font-size:32px;">📅</div>
                        <p>No upcoming trips scheduled.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Travel Tips -->
            <div class="card">
                <div class="card-header">
                    <h3>💡 Travel Tips</h3>
                </div>
                <div class="card-body">
                    <ul class="tips-list">
                        <li><span class="tip-icon">🗓️</span> Book flights 6–8 weeks in advance for the best prices.</li>
                        <li><span class="tip-icon">🧳</span> Pack light — most destinations have laundry facilities.</li>
                        <li><span class="tip-icon">💳</span> Notify your bank before travelling internationally.</li>
                        <li><span class="tip-icon">📱</span> Download offline maps before you leave.</li>
                    </ul>
                </div>
            </div>

        </div><!-- /right sidebar -->
    </div><!-- /two-col -->

    <!-- POPULAR DESTINATIONS -->
    <div class="sec-header">
        <h2 class="sec-title">🌍 Popular Destinations</h2>
        <a href="city-search.php" class="sec-link">Explore all →</a>
    </div>
    <?php if (!empty($popular_cities)): ?>
    <div class="cities-row">
        <?php foreach ($popular_cities as $city): ?>
        <a href="city-search.php" class="city-mini">
            <img src="<?php echo htmlspecialchars($city['image_url'] ?? ''); ?>"
                 alt="<?php echo htmlspecialchars($city['name']); ?>"
                 onerror="this.src='https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=80'">
            <div class="city-mini-overlay">
                <div>
                    <div class="city-mini-name"><?php echo htmlspecialchars($city['name']); ?></div>
                    <div class="city-mini-country"><?php echo htmlspecialchars($city['country']); ?></div>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="card" style="margin-bottom:40px;">
        <div class="empty-box">
            <div class="empty-icon">🌍</div>
            <p>No popular destinations found. <a href="city-search.php" class="sec-link">Browse all cities</a></p>
        </div>
    </div>
    <?php endif; ?>

</main>

<!-- ===== FOOTER ===== -->
<footer>
    <p>© 2026 Travel Planner. All rights reserved.</p>
</footer>

</body>
</html>


