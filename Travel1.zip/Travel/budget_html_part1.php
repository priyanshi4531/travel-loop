<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Planner – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            color: #1a1a2e;
            min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.60), rgba(8,12,35,0.60)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* ── NAV ── */
        header { background: #0f172a; box-shadow: 0 2px 20px rgba(0,0,0,0.35); position: sticky; top: 0; z-index: 200; }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 8px; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-menu .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2); color: #fff !important; padding: 8px 16px; }
        .nav-menu .nav-cta a:hover { opacity: 0.88; }

        /* ── HERO ── */
        .hero {
            position: relative; overflow: hidden;
            background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 64px 40px 56px;
        }
        .hero-inner { max-width: 1200px; margin: 0 auto; text-align: center; }
        .hero-badge { display: inline-block; background: rgba(102,126,234,0.25); border: 1px solid rgba(102,126,234,0.45); color: #a5b4fc; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 6px 16px; border-radius: 20px; margin-bottom: 18px; }
        .hero-title { font-size: 42px; font-weight: 900; color: #fff; line-height: 1.15; margin-bottom: 14px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); }
        .hero-sub { font-size: 16px; color: rgba(255,255,255,0.62); max-width: 520px; margin: 0 auto; }

        /* ── MAIN WRAPPER ── */
        .page-main { max-width: 1200px; margin: 0 auto; padding: 40px 24px 70px; }

        /* ── CITY SELECTOR ── */
        .city-selector { margin-bottom: 32px; }
        .city-selector-label { font-size: 13px; font-weight: 700; color: rgba(255,255,255,0.55); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
        .city-pills { display: flex; flex-wrap: wrap; gap: 10px; }
        .city-pill {
            padding: 9px 20px; border-radius: 30px; border: 1.5px solid rgba(255,255,255,0.22);
            background: rgba(255,255,255,0.10); color: rgba(255,255,255,0.80);
            font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s;
            backdrop-filter: blur(8px);
        }
        .city-pill:hover { background: rgba(255,255,255,0.18); border-color: rgba(255,255,255,0.40); color: #fff; }
        .city-pill.active { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; color: #fff; box-shadow: 0 4px 14px rgba(102,126,234,0.45); }

        /* ── SECTION HEADER ── */
        .sec-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .sec-title { font-size: 20px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 10px; text-shadow: 0 1px 6px rgba(0,0,0,0.4); }
        .sec-badge { background: rgba(255,255,255,0.15); color: rgba(255,255,255,0.75); font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 12px; }

        /* ── CITY SECTION WRAPPER ── */
        .city-section { display: none; }
        .city-section.active { display: block; }

        /* ── HOTEL GRID ── */
        .hotels-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px; }
        .hotel-card {
            background: #fff; border-radius: 14px; overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.12); transition: transform 0.25s, box-shadow 0.25s;
        }
        .hotel-card:hover { transform: translateY(-5px); box-shadow: 0 12px 32px rgba(0,0,0,0.18); }
        .hotel-img { width: 100%; height: 180px; object-fit: cover; display: block; }
        .hotel-body { padding: 16px 18px 18px; }
        .hotel-stars { color: #f59e0b; font-size: 14px; margin-bottom: 6px; letter-spacing: 1px; }
        .hotel-name { font-size: 16px; font-weight: 800; color: #1a1a2e; margin-bottom: 6px; line-height: 1.3; }
        .hotel-price { font-size: 18px; font-weight: 800; color: #667eea; margin-bottom: 8px; }
        .hotel-price span { font-size: 13px; font-weight: 500; color: #888; }
        .hotel-amenities { font-size: 12px; color: #888; margin-bottom: 14px; line-height: 1.5; }
        .btn-book {
            display: block; width: 100%; padding: 10px; text-align: center;
            background: linear-gradient(135deg,#667eea,#764ba2); color: #fff;
            border: none; border-radius: 8px; font-size: 14px; font-weight: 700;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
        }
        .btn-book:hover { opacity: 0.88; transform: translateY(-1px); }

        /* ── TRANSPORT SECTION ── */
        .transport-section { margin-bottom: 48px; }
        .filter-pills { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 22px; }
        .filter-pill {
            padding: 7px 16px; border-radius: 24px; border: 1.5px solid rgba(255,255,255,0.22);
            background: rgba(255,255,255,0.10); color: rgba(255,255,255,0.75);
            font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s;
            backdrop-filter: blur(6px);
        }
        .filter-pill:hover { background: rgba(255,255,255,0.18); color: #fff; }
        .filter-pill.active { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; color: #fff; box-shadow: 0 3px 10px rgba(102,126,234,0.40); }
        .transport-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
        .transport-card {
            background: #fff; border-radius: 14px; padding: 22px 16px 18px;
            text-align: center; box-shadow: 0 4px 16px rgba(0,0,0,0.10);
            transition: transform 0.22s, box-shadow 0.22s;
        }
        .transport-card:hover { transform: translateY(-4px); box-shadow: 0 10px 28px rgba(0,0,0,0.15); }
        .transport-card.hidden { display: none; }
        .transport-icon { font-size: 40px; margin-bottom: 10px; display: block; line-height: 1; }
        .transport-type { font-size: 13px; font-weight: 700; color: #667eea; margin-bottom: 6px; }
        .transport-route { font-size: 13px; color: #444; font-weight: 600; margin-bottom: 6px; line-height: 1.4; }
        .transport-route .arrow { color: #aaa; margin: 0 4px; }
        .transport-duration { display: inline-block; background: #f0f4ff; color: #667eea; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 12px; margin-bottom: 10px; }
        .transport-price { font-size: 18px; font-weight: 800; color: #1a1a2e; margin-bottom: 12px; }
        .transport-price.free { color: #10b981; }
        .btn-select {
            display: block; width: 100%; padding: 8px; text-align: center;
            background: #f0f4ff; color: #667eea; border: 1.5px solid #c7d2fe;
            border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .btn-select:hover { background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border-color: transparent; }

        /* ── BUDGET TRACKER ── */
        .budget-section { margin-bottom: 60px; }
        .budget-card {
            background: rgba(255,255,255,0.97); border-radius: 16px;
            box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; margin-bottom: 28px;
        }
        .budget-card-header {
            padding: 20px 28px; border-bottom: 1px solid #f0f0f0;
            display: flex; align-items: center; justify-content: space-between;
        }
        .budget-card-header h3 { font-size: 17px; font-weight: 800; color: #1a1a2e; }
        .budget-form { padding: 24px 28px; }
        .form-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 16px; }
        .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group label { font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group select,
        .form-group input {
            padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 8px;
            font-size: 14px; color: #1a1a2e; font-family: inherit; transition: border-color 0.2s;
            background: #fafbff;
        }
        .form-group select:focus,
        .form-group input:focus { outline: none; border-color: #667eea; background: #fff; }
        .btn-add-budget {
            padding: 11px 28px; background: linear-gradient(135deg,#667eea,#764ba2);
            color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 700;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
        }
        .btn-add-budget:hover { opacity: 0.88; transform: translateY(-1px); }

        /* Budget table */
        .budget-trip-block { margin-bottom: 28px; }
        .budget-trip-name {
            font-size: 15px; font-weight: 800; color: #1a1a2e;
            padding: 14px 24px; background: #f8f9ff; border-bottom: 1px solid #eef0f8;
            display: flex; align-items: center; gap: 8px;
        }
        .budget-table { width: 100%; border-collapse: collapse; }
        .budget-table th {
            padding: 11px 20px; text-align: left; font-size: 11px; font-weight: 700;
            color: #888; text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafbff; border-bottom: 1px solid #f0f0f0;
        }
        .budget-table td { padding: 13px 20px; border-bottom: 1px solid #f8f8f8; font-size: 14px; color: #444; vertical-align: middle; }
        .budget-table tbody tr:last-child td { border-bottom: none; }
        .budget-table tbody tr:hover td { background: #fafbff; }
        .cat-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;
        }
        .cat-flights    { background: #dbeafe; color: #1d4ed8; }
        .cat-hotels     { background: #ede9fe; color: #6d28d9; }
        .cat-food       { background: #fef3c7; color: #92400e; }
        .cat-activities { background: #d1fae5; color: #065f46; }
        .cat-transport  { background: #e0f2fe; color: #0369a1; }
        .cat-shopping   { background: #fce7f3; color: #9d174d; }
        .cat-other      { background: #f3f4f6; color: #374151; }
        .diff-under { color: #10b981; font-weight: 700; }
        .diff-over  { color: #ef4444; font-weight: 700; }
        .diff-na    { color: #aaa; }
        .btn-delete {
            padding: 5px 12px; background: #fee2e2; color: #dc2626;
            border: none; border-radius: 6px; font-size: 12px; font-weight: 700;
            cursor: pointer; transition: background 0.2s;
        }
        .btn-delete:hover { background: #fca5a5; }

        /* Empty state */
        .empty-state { padding: 48px 20px; text-align: center; }
        .empty-state .empty-icon { font-size: 52px; margin-bottom: 14px; }
        .empty-state p { color: #aaa; font-size: 15px; margin-bottom: 18px; }
        .btn-primary-link {
            display: inline-block; padding: 10px 24px;
            background: linear-gradient(135deg,#667eea,#764ba2); color: #fff;
            border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 700;
        }

        /* ── FOOTER ── */
        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 24px; font-size: 13px; }

        /* ── RESPONSIVE ── */
        @media (max-width: 1024px) {
            .hotels-grid { grid-template-columns: repeat(2, 1fr); }
            .transport-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            header nav { padding: 0 16px; }
            .hero { padding: 44px 20px 40px; }
            .hero-title { font-size: 30px; }
            .page-main { padding: 28px 16px 50px; }
            .hotels-grid { grid-template-columns: repeat(2, 1fr); }
            .transport-grid { grid-template-columns: repeat(2, 1fr); }
            .form-row { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 520px) {
            .hotels-grid { grid-template-columns: 1fr; }
            .transport-grid { grid-template-columns: repeat(2, 1fr); }
            .form-row { grid-template-columns: 1fr; }
            .form-row-2 { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
