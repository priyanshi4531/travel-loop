<?php
$page_title = 'Analytics';
require_once '../includes/header.php';
requireAdmin();
?>

<h1>Analytics</h1>
<p>Analytics and statistics will be displayed here.</p>

<?php require_once '../includes/footer.php'; ?>
