<?php
$page_title = 'Manage Trips';
require_once '../includes/header.php';
requireAdmin();
?>

<h1>Manage Trips</h1>
<p>Trip management functionality will be implemented here.</p>

<?php require_once '../includes/footer.php'; ?>
