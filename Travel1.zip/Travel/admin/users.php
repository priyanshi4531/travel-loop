<?php
$page_title = 'Manage Users';
require_once '../includes/header.php';
requireAdmin();
?>

<h1>Manage Users</h1>
<p>User management functionality will be implemented here.</p>

<?php require_once '../includes/footer.php'; ?>
