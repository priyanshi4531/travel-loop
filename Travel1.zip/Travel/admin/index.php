<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

// ── Stats ──
$stats = [];
$stats['users']      = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$stats['trips']      = $conn->query("SELECT COUNT(*) as c FROM trips")->fetch_assoc()['c'];
$stats['cities']     = $conn->query("SELECT COUNT(*) as c FROM cities")->fetch_assoc()['c'];
$stats['activities'] = $conn->query("SELECT COUNT(*) as c FROM activities")->fetch_assoc()['c'];
$stats['packing']    = $conn->query("SELECT COUNT(*) as c FROM packing_items")->fetch_assoc()['c'];
$stats['notes']      = $conn->query("SELECT COUNT(*) as c FROM trip_notes")->fetch_assoc()['c'];
$stats['budget']     = $conn->query("SELECT COALESCE(SUM(estimated_cost),0) as c FROM budget_items")->fetch_assoc()['c'];

// ── Recent users (last 8) ──
$users_stmt = $conn->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 8");
$recent_users = $users_stmt->fetch_all(MYSQLI_ASSOC);

// ── Recent trips (last 8) ──
$trips_stmt = $conn->query("SELECT t.id, t.name, t.status, t.start_date, t.end_date, t.budget, t.currency, u.name as user_name FROM trips t JOIN users u ON t.user_id=u.id ORDER BY t.created_at DESC LIMIT 8");
$recent_trips = $trips_stmt->fetch_all(MYSQLI_ASSOC);

// ── All cities ──
$cities_stmt = $conn->query("SELECT c.id, c.name, c.country, c.popular, COUNT(a.id) as act_count FROM cities c LEFT JOIN activities a ON a.city_id=c.id GROUP BY c.id ORDER BY c.popular DESC, c.name ASC");
$all_cities = $cities_stmt->fetch_all(MYSQLI_ASSOC);

// ── Trip status breakdown ──
$status_stmt = $conn->query("SELECT status, COUNT(*) as cnt FROM trips GROUP BY status");
$status_data = [];
while ($row = $status_stmt->fetch_assoc()) { $status_data[$row['status']] = $row['cnt']; }

// ── Top cities by activity count ──
$top_cities = $conn->query("SELECT c.name, COUNT(a.id) as act_count FROM cities c LEFT JOIN activities a ON a.city_id=c.id GROUP BY c.id ORDER BY act_count DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard — Travel Planner</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; }

    /* Sidebar */
    .sidebar { position: fixed; left: 0; top: 0; bottom: 0; width: 240px; background: #1e293b; border-right: 1px solid rgba(255,255,255,0.06); display: flex; flex-direction: column; z-index: 100; }
    .sidebar-logo { padding: 24px 20px; font-size: 18px; font-weight: 800; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; gap: 10px; }
    .sidebar-badge { background: rgba(239,68,68,0.20); color: #fca5a5; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 10px; letter-spacing: 0.5px; }
    .sidebar-nav { padding: 16px 12px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 9px; color: rgba(255,255,255,0.55); font-size: 14px; font-weight: 500; text-decoration: none; transition: all 0.2s; margin-bottom: 4px; cursor: pointer; }
    .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.08); color: #fff; }
    .nav-item .nav-icon { font-size: 18px; width: 24px; text-align: center; }
    .nav-section-label { font-size: 10px; font-weight: 700; color: rgba(255,255,255,0.25); text-transform: uppercase; letter-spacing: 1px; padding: 12px 14px 6px; }
    .sidebar-footer { padding: 16px 12px; border-top: 1px solid rgba(255,255,255,0.06); }
    .sidebar-footer a { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 9px; color: rgba(255,255,255,0.45); font-size: 13px; font-weight: 500; text-decoration: none; transition: all 0.2s; }
    .sidebar-footer a:hover { background: rgba(239,68,68,0.15); color: #fca5a5; }

    /* Main content */
    .main-content { margin-left: 240px; min-height: 100vh; }
    .topbar { background: #1e293b; border-bottom: 1px solid rgba(255,255,255,0.06); padding: 0 32px; height: 64px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 50; }
    .topbar-title { font-size: 18px; font-weight: 800; color: #fff; }
    .topbar-right { display: flex; align-items: center; gap: 14px; }
    .admin-avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg,#ef4444,#b91c1c); display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 800; color: #fff; }
    .admin-name { font-size: 14px; font-weight: 600; color: rgba(255,255,255,0.75); }

    /* Page content */
    .page-content { padding: 32px; }

    /* Section */
    .section { display: none; }
    .section.active { display: block; }
    .section-title { font-size: 22px; font-weight: 800; color: #fff; margin-bottom: 24px; display: flex; align-items: center; gap: 10px; }

    /* Stats grid */
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; margin-bottom: 32px; }
    .stat-card { background: #1e293b; border-radius: 14px; padding: 22px 24px; border: 1px solid rgba(255,255,255,0.06); transition: transform 0.2s; }
    .stat-card:hover { transform: translateY(-3px); }
    .stat-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
    .stat-icon-wrap { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .stat-num { font-size: 30px; font-weight: 900; color: #fff; line-height: 1; margin-bottom: 4px; }
    .stat-label { font-size: 13px; color: rgba(255,255,255,0.45); font-weight: 500; }

    /* Table card */
    .table-card { background: #1e293b; border-radius: 14px; border: 1px solid rgba(255,255,255,0.06); overflow: hidden; margin-bottom: 28px; }
    .table-card-header { padding: 18px 24px; border-bottom: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: space-between; }
    .table-card-header h3 { font-size: 15px; font-weight: 700; color: #fff; }
    .table-card-header span { font-size: 12px; color: rgba(255,255,255,0.35); }
    table { width: 100%; border-collapse: collapse; }
    th { padding: 12px 20px; text-align: left; font-size: 11px; font-weight: 700; color: rgba(255,255,255,0.35); text-transform: uppercase; letter-spacing: 0.5px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(255,255,255,0.06); }
    td { padding: 14px 20px; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 14px; color: rgba(255,255,255,0.75); vertical-align: middle; }
    tbody tr:last-child td { border-bottom: none; }
    tbody tr:hover td { background: rgba(255,255,255,0.03); }

    /* Badges */
    .badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
    .badge-admin     { background: rgba(239,68,68,0.20);  color: #fca5a5; }
    .badge-user      { background: rgba(99,102,241,0.20); color: #a5b4fc; }
    .badge-draft     { background: rgba(251,191,36,0.20); color: #fde68a; }
    .badge-published { background: rgba(34,197,94,0.20);  color: #86efac; }
    .badge-shared    { background: rgba(96,165,250,0.20);  color: #bfdbfe; }
    .badge-popular   { background: rgba(251,191,36,0.20); color: #fde68a; }

    /* Two col */
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 28px; }

    /* City grid */
    .city-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
    .city-card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 18px; transition: background 0.2s; }
    .city-card:hover { background: rgba(255,255,255,0.07); }
    .city-name { font-size: 15px; font-weight: 700; color: #fff; margin-bottom: 4px; }
    .city-country { font-size: 12px; color: rgba(255,255,255,0.40); margin-bottom: 10px; }
    .city-meta { display: flex; align-items: center; justify-content: space-between; }
    .city-acts { font-size: 12px; color: rgba(255,255,255,0.50); }

    /* Status breakdown */
    .status-breakdown { display: flex; flex-direction: column; gap: 14px; padding: 20px 24px; }
    .status-row { display: flex; align-items: center; gap: 14px; }
    .status-row-label { font-size: 13px; font-weight: 600; color: rgba(255,255,255,0.65); width: 90px; }
    .status-bar-wrap { flex: 1; height: 8px; background: rgba(255,255,255,0.08); border-radius: 10px; overflow: hidden; }
    .status-bar { height: 100%; border-radius: 10px; }
    .bar-draft     { background: #f59e0b; }
    .bar-published { background: #22c55e; }
    .bar-shared    { background: #60a5fa; }
    .status-row-count { font-size: 13px; font-weight: 700; color: #fff; width: 30px; text-align: right; }

    @media (max-width: 1100px) { .stats-grid { grid-template-columns: repeat(2,1fr); } .city-grid { grid-template-columns: repeat(2,1fr); } }
    @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } .two-col { grid-template-columns: 1fr; } }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-logo">⚙️ Admin <span class="sidebar-badge">PANEL</span></div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Main</div>
    <a class="nav-item active" onclick="showSection('dashboard',this)"><span class="nav-icon">📊</span> Dashboard</a>
    <a class="nav-item" onclick="showSection('users',this)"><span class="nav-icon">👥</span> Users</a>
    <a class="nav-item" onclick="showSection('trips',this)"><span class="nav-icon">🗺️</span> Trips</a>
    <a class="nav-item" onclick="showSection('cities',this)"><span class="nav-icon">🌍</span> Cities</a>
    <div class="nav-section-label">System</div>
    <a class="nav-item" href="../dashboard.php"><span class="nav-icon">🏠</span> User Dashboard</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><span>🚪</span> Logout</a>
  </div>
</div>

<!-- Main Content -->
<div class="main-content">
  <div class="topbar">
    <div class="topbar-title" id="topbar-title">Dashboard Overview</div>
    <div class="topbar-right">
      <div class="admin-name">Admin</div>
      <div class="admin-avatar">A</div>
    </div>
  </div>

  <div class="page-content">

    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- SECTION: Dashboard                                      -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="section active" id="sec-dashboard">

      <!-- Stats Grid -->
      <div class="stats-grid">

        <!-- Users -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['users']); ?></div>
              <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(99,102,241,0.20);">👥</div>
          </div>
        </div>

        <!-- Trips -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['trips']); ?></div>
              <div class="stat-label">Total Trips</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(34,197,94,0.20);">🗺️</div>
          </div>
        </div>

        <!-- Cities -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['cities']); ?></div>
              <div class="stat-label">Cities</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(251,191,36,0.20);">🌍</div>
          </div>
        </div>

        <!-- Activities -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['activities']); ?></div>
              <div class="stat-label">Activities</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(239,68,68,0.20);">🎯</div>
          </div>
        </div>

        <!-- Packing Items -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['packing']); ?></div>
              <div class="stat-label">Packing Items</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(96,165,250,0.20);">🧳</div>
          </div>
        </div>

        <!-- Notes -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num"><?php echo htmlspecialchars($stats['notes']); ?></div>
              <div class="stat-label">Notes</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(168,85,247,0.20);">📝</div>
          </div>
        </div>

        <!-- Total Budget Est. -->
        <div class="stat-card">
          <div class="stat-top">
            <div>
              <div class="stat-num">$<?php echo number_format($stats['budget'], 0); ?></div>
              <div class="stat-label">Total Budget Est.</div>
            </div>
            <div class="stat-icon-wrap" style="background: rgba(34,197,94,0.20);">💰</div>
          </div>
        </div>

      </div><!-- /.stats-grid -->

      <!-- Two-col: Recent Users + Trip Status -->
      <div class="two-col">

        <!-- Recent Users -->
        <div class="table-card">
          <div class="table-card-header">
            <h3>🕐 Recent Users</h3>
            <span><?php echo count($recent_users); ?> shown</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Joined</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_users as $user): ?>
              <tr>
                <td><?php echo htmlspecialchars($user['name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td>
                  <?php if ($user['role'] === 'admin'): ?>
                    <span class="badge badge-admin">admin</span>
                  <?php else: ?>
                    <span class="badge badge-user">user</span>
                  <?php endif; ?>
                </td>
                <td><?php echo htmlspecialchars(date('M j, Y', strtotime($user['created_at']))); ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Trip Status Breakdown -->
        <div class="table-card">
          <div class="table-card-header">
            <h3>📊 Trip Status</h3>
            <span><?php echo htmlspecialchars($stats['trips']); ?> total</span>
          </div>
          <?php
            $total_trips = max(1, (int)$stats['trips']);
            $draft_cnt     = isset($status_data['draft'])     ? (int)$status_data['draft']     : 0;
            $published_cnt = isset($status_data['published']) ? (int)$status_data['published'] : 0;
            $shared_cnt    = isset($status_data['shared'])    ? (int)$status_data['shared']    : 0;
            $draft_pct     = round($draft_cnt     / $total_trips * 100);
            $published_pct = round($published_cnt / $total_trips * 100);
            $shared_pct    = round($shared_cnt    / $total_trips * 100);
          ?>
          <div class="status-breakdown">
            <div class="status-row">
              <div class="status-row-label">Draft</div>
              <div class="status-bar-wrap">
                <div class="status-bar bar-draft" style="width: <?php echo $draft_pct; ?>%;"></div>
              </div>
              <div class="status-row-count"><?php echo $draft_cnt; ?></div>
            </div>
            <div class="status-row">
              <div class="status-row-label">Published</div>
              <div class="status-bar-wrap">
                <div class="status-bar bar-published" style="width: <?php echo $published_pct; ?>%;"></div>
              </div>
              <div class="status-row-count"><?php echo $published_cnt; ?></div>
            </div>
            <div class="status-row">
              <div class="status-row-label">Shared</div>
              <div class="status-bar-wrap">
                <div class="status-bar bar-shared" style="width: <?php echo $shared_pct; ?>%;"></div>
              </div>
              <div class="status-row-count"><?php echo $shared_cnt; ?></div>
            </div>
          </div>
        </div>

      </div><!-- /.two-col -->

      <!-- Recent Trips (full width) -->
      <div class="table-card">
        <div class="table-card-header">
          <h3>🗺️ Recent Trips</h3>
          <span><?php echo count($recent_trips); ?> shown</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Trip Name</th>
              <th>User</th>
              <th>Start Date</th>
              <th>Status</th>
              <th>Budget</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_trips as $trip): ?>
            <tr>
              <td><?php echo htmlspecialchars($trip['name']); ?></td>
              <td><?php echo htmlspecialchars($trip['user_name']); ?></td>
              <td><?php echo $trip['start_date'] ? htmlspecialchars(date('M j, Y', strtotime($trip['start_date']))) : '—'; ?></td>
              <td>
                <?php
                  $s = $trip['status'];
                  $badge_class = 'badge-' . htmlspecialchars($s);
                ?>
                <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($s); ?></span>
              </td>
              <td>
                <?php if ($trip['budget']): ?>
                  <?php echo htmlspecialchars($trip['currency'] ?? 'USD'); ?> <?php echo number_format((float)$trip['budget'], 0); ?>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div><!-- /#sec-dashboard -->


    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- SECTION: Users                                          -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="section" id="sec-users">
      <div class="section-title">👥 All Users</div>

      <div class="table-card">
        <div class="table-card-header">
          <h3>Registered Users</h3>
          <span><?php echo count($recent_users); ?> records</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_users as $i => $user): ?>
            <tr>
              <td><?php echo $i + 1; ?></td>
              <td><?php echo htmlspecialchars($user['name']); ?></td>
              <td><?php echo htmlspecialchars($user['email']); ?></td>
              <td>
                <?php if ($user['role'] === 'admin'): ?>
                  <span class="badge badge-admin">admin</span>
                <?php else: ?>
                  <span class="badge badge-user">user</span>
                <?php endif; ?>
              </td>
              <td><?php echo htmlspecialchars(date('M j, Y', strtotime($user['created_at']))); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div><!-- /#sec-users -->


    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- SECTION: Trips                                          -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="section" id="sec-trips">
      <div class="section-title">🗺️ All Trips</div>

      <div class="table-card">
        <div class="table-card-header">
          <h3>Trip Records</h3>
          <span><?php echo count($recent_trips); ?> records</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Trip Name</th>
              <th>User</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Status</th>
              <th>Budget</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_trips as $i => $trip): ?>
            <tr>
              <td><?php echo $i + 1; ?></td>
              <td><?php echo htmlspecialchars($trip['name']); ?></td>
              <td><?php echo htmlspecialchars($trip['user_name']); ?></td>
              <td><?php echo $trip['start_date'] ? htmlspecialchars(date('M j, Y', strtotime($trip['start_date']))) : '—'; ?></td>
              <td><?php echo isset($trip['end_date']) && $trip['end_date'] ? htmlspecialchars(date('M j, Y', strtotime($trip['end_date']))) : '—'; ?></td>
              <td>
                <?php $s = $trip['status']; ?>
                <span class="badge badge-<?php echo htmlspecialchars($s); ?>"><?php echo htmlspecialchars($s); ?></span>
              </td>
              <td>
                <?php if ($trip['budget']): ?>
                  <?php echo htmlspecialchars($trip['currency'] ?? 'USD'); ?> <?php echo number_format((float)$trip['budget'], 0); ?>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div><!-- /#sec-trips -->


    <!-- ═══════════════════════════════════════════════════════ -->
    <!-- SECTION: Cities                                         -->
    <!-- ═══════════════════════════════════════════════════════ -->
    <div class="section" id="sec-cities">
      <div class="section-title">🌍 Cities &amp; Destinations</div>

      <div class="city-grid">
        <?php foreach ($all_cities as $city): ?>
        <div class="city-card">
          <div class="city-name"><?php echo htmlspecialchars($city['name']); ?></div>
          <div class="city-country"><?php echo htmlspecialchars($city['country']); ?></div>
          <div class="city-meta">
            <div class="city-acts">🎯 <?php echo (int)$city['act_count']; ?> activit<?php echo $city['act_count'] == 1 ? 'y' : 'ies'; ?></div>
            <?php if ($city['popular']): ?>
              <span class="badge badge-popular">⭐ Popular</span>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

    </div><!-- /#sec-cities -->

  </div><!-- /.page-content -->
</div><!-- /.main-content -->

<script>
function showSection(name, el) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById('sec-' + name).classList.add('active');
    if (el) el.classList.add('active');
    const titles = {
        dashboard: 'Dashboard Overview',
        users:     'User Management',
        trips:     'Trip Management',
        cities:    'Cities & Destinations'
    };
    document.getElementById('topbar-title').textContent = titles[name] || name;
}
</script>

</body>
</html>
