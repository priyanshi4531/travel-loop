-- Travel Planner Database
-- Import this file into phpMyAdmin or run: mysql -u root -p < travel_planner.sql

CREATE DATABASE IF NOT EXISTS `travel_planner` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `travel_planner`;

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `bio` TEXT DEFAULT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `country` VARCHAR(100) DEFAULT NULL,
  `additional_info` TEXT DEFAULT NULL,
  `role` ENUM('user','admin') NOT NULL DEFAULT 'user',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: trips
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trips` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `cover_photo` VARCHAR(255) DEFAULT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `status` ENUM('draft','published','shared') NOT NULL DEFAULT 'draft',
  `share_token` VARCHAR(64) DEFAULT NULL,
  `budget` DECIMAL(12,2) DEFAULT 0.00,
  `currency` VARCHAR(10) DEFAULT 'USD',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `trips_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: cities
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cities` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `country` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `image_url` VARCHAR(255) DEFAULT NULL,
  `popular` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: trip_cities
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trip_cities` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `city_id` INT(11) NOT NULL,
  `arrival_date` DATE DEFAULT NULL,
  `departure_date` DATE DEFAULT NULL,
  `order_index` INT(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  KEY `city_id` (`city_id`),
  CONSTRAINT `tc_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tc_city_fk` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: activities
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activities` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `city_id` INT(11) NOT NULL,
  `category` ENUM('sightseeing','food','adventure','culture','shopping','nightlife') NOT NULL DEFAULT 'sightseeing',
  `cost` DECIMAL(10,2) DEFAULT 0.00,
  `duration_hours` DECIMAL(4,1) DEFAULT 1.0,
  `image_url` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  CONSTRAINT `act_city_fk` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: trip_activities
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trip_activities` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `trip_city_id` INT(11) NOT NULL,
  `activity_id` INT(11) NOT NULL,
  `scheduled_date` DATE DEFAULT NULL,
  `scheduled_time` TIME DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `cost_override` DECIMAL(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  KEY `trip_city_id` (`trip_city_id`),
  KEY `activity_id` (`activity_id`),
  CONSTRAINT `ta_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ta_tc_fk` FOREIGN KEY (`trip_city_id`) REFERENCES `trip_cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ta_act_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: budget_items
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `budget_items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `category` ENUM('flights','hotels','food','activities','transport','shopping','other') NOT NULL DEFAULT 'other',
  `description` VARCHAR(255) NOT NULL,
  `estimated_cost` DECIMAL(12,2) DEFAULT 0.00,
  `actual_cost` DECIMAL(12,2) DEFAULT NULL,
  `currency` VARCHAR(10) DEFAULT 'USD',
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  CONSTRAINT `bi_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: packing_items
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `packing_items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `item_name` VARCHAR(200) NOT NULL,
  `category` ENUM('clothing','toiletries','documents','electronics','medicine','other') NOT NULL DEFAULT 'other',
  `is_packed` TINYINT(1) NOT NULL DEFAULT 0,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `pi_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pi_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: trip_notes
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trip_notes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `content` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tn_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tn_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table: shared_trips
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `shared_trips` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `trip_id` INT(11) NOT NULL,
  `share_token` VARCHAR(64) NOT NULL UNIQUE,
  `is_public` TINYINT(1) NOT NULL DEFAULT 1,
  `views` INT(11) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `trip_id` (`trip_id`),
  CONSTRAINT `st_trip_fk` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================================
-- SAMPLE DATA
-- ========================================================

-- Admin user (password: admin123)
INSERT INTO `users` (`name`, `email`, `password`, `bio`, `role`) VALUES
('Admin User', 'admin@travelplanner.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Platform administrator', 'admin'),
('Jane Doe', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Avid traveler and food lover', 'user'),
('John Smith', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Adventure seeker', 'user');

-- 10 Popular Cities
INSERT INTO `cities` (`name`, `country`, `description`, `image_url`, `popular`) VALUES
('Paris', 'France', 'The City of Light, famous for the Eiffel Tower, world-class cuisine, and romantic ambiance. Paris is a global center for art, fashion, gastronomy, and culture.', 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800', 1),
('Tokyo', 'Japan', 'A dazzling metropolis where ancient temples meet futuristic skyscrapers. Tokyo offers an unparalleled blend of tradition and innovation, with incredible food and vibrant neighborhoods.', 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800', 1),
('New York', 'USA', 'The city that never sleeps. New York is a global icon with world-famous landmarks, diverse neighborhoods, Broadway shows, and an unmatched energy that captivates millions.', 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800', 1),
('Rome', 'Italy', 'The Eternal City, where every cobblestone tells a story. Rome is home to the Colosseum, Vatican City, and some of the world''s finest pasta and gelato.', 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800', 1),
('Bali', 'Indonesia', 'Island of the Gods. Bali enchants visitors with its lush rice terraces, ancient temples, vibrant arts scene, and some of the world''s best surf and spa experiences.', 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800', 1),
('London', 'United Kingdom', 'A world-class city steeped in history and culture. London offers iconic landmarks, world-renowned museums, diverse cuisine, and a thriving arts and entertainment scene.', 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800', 1),
('Barcelona', 'Spain', 'A vibrant city on the Mediterranean coast, famous for Gaudí''s architectural masterpieces, beautiful beaches, delicious tapas, and a lively nightlife scene.', 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800', 1),
('Dubai', 'UAE', 'A city of superlatives. Dubai dazzles with its futuristic skyline, luxury shopping, desert adventures, and world-record-breaking attractions in the heart of the Arabian Desert.', 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800', 1),
('Sydney', 'Australia', 'Australia''s harbour city is famous for its iconic Opera House, stunning beaches, vibrant food scene, and outdoor lifestyle that perfectly blends urban sophistication with natural beauty.', 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=800', 1),
('Bangkok', 'Thailand', 'Thailand''s capital is a city of contrasts — ornate temples and palaces sit alongside modern malls and bustling street markets, all fueled by some of the world''s most exciting street food.', 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=800', 1);

-- Activities for Paris (city_id=1)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Eiffel Tower Visit', 'Ascend the iconic iron lattice tower for breathtaking panoramic views of Paris. Book tickets in advance to skip the long queues.', 1, 'sightseeing', 26.00, 3.0, 'https://images.unsplash.com/photo-1543349689-9a4d426bee8e?w=600'),
('Louvre Museum', 'Explore the world''s largest art museum, home to the Mona Lisa, Venus de Milo, and thousands of other masterpieces spanning thousands of years of history.', 1, 'culture', 17.00, 4.0, 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600'),
('Seine River Cruise', 'Glide along the Seine River on a scenic boat cruise, passing under historic bridges and alongside iconic Parisian landmarks illuminated at night.', 1, 'sightseeing', 15.00, 1.5, 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600'),
('Montmartre & Sacré-Cœur', 'Wander through the charming hilltop neighborhood of Montmartre, visit the stunning white-domed Sacré-Cœur Basilica, and watch street artists at work.', 1, 'culture', 0.00, 3.0, 'https://images.unsplash.com/photo-1550340499-a6c60fc8287c?w=600'),
('French Cooking Class', 'Learn to cook classic French dishes like croissants, coq au vin, and crème brûlée with a professional Parisian chef in a hands-on cooking workshop.', 1, 'food', 95.00, 3.5, 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600');

-- Activities for Tokyo (city_id=2)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Senso-ji Temple', 'Visit Tokyo''s oldest and most significant Buddhist temple in the historic Asakusa district. Explore the Nakamise shopping street leading to the temple gate.', 2, 'culture', 0.00, 2.0, 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=600'),
('Shibuya Crossing', 'Experience the world''s busiest pedestrian crossing, where up to 3,000 people cross simultaneously. Best viewed from the Starbucks overlooking the intersection.', 2, 'sightseeing', 0.00, 1.0, 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600'),
('Tsukiji Outer Market Food Tour', 'Sample fresh sushi, tamagoyaki, and other Japanese delicacies at the famous Tsukiji Outer Market, a paradise for food lovers and culinary adventurers.', 2, 'food', 30.00, 2.5, 'https://images.unsplash.com/photo-1553621042-f6e147245754?w=600'),
('teamLab Borderless', 'Immerse yourself in a world of digital art at this groundbreaking museum where artworks move freely and interact with visitors in stunning ways.', 2, 'culture', 32.00, 3.0, 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600'),
('Mount Fuji Day Trip', 'Take a day trip from Tokyo to Japan''s iconic snow-capped volcano. Hike the trails, visit the Fuji Five Lakes, and enjoy spectacular views of this sacred mountain.', 2, 'adventure', 80.00, 10.0, 'https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=600');

-- Activities for New York (city_id=3)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Statue of Liberty & Ellis Island', 'Take a ferry to Liberty Island to see the iconic Statue of Liberty up close, then visit Ellis Island to learn about America''s immigration history.', 3, 'sightseeing', 24.00, 4.0, 'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?w=600'),
('Central Park Bike Tour', 'Explore the 843-acre urban oasis of Central Park on a guided bike tour, visiting Bethesda Fountain, Strawberry Fields, and the Jacqueline Kennedy Onassis Reservoir.', 3, 'adventure', 45.00, 3.0, 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600'),
('Broadway Show', 'Experience the magic of live theater on the world-famous Broadway strip. From classic musicals to cutting-edge dramas, there''s a show for every taste.', 3, 'culture', 120.00, 3.0, 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=600'),
('NYC Food Tour - Brooklyn', 'Taste your way through Brooklyn''s diverse food scene, sampling artisan pizza, bagels, dumplings, and craft beer in one of NYC''s most vibrant boroughs.', 3, 'food', 65.00, 3.5, 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600');

-- Activities for Rome (city_id=4)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Colosseum & Roman Forum', 'Step back in time at the ancient Colosseum, the largest amphitheater ever built, then explore the ruins of the Roman Forum and Palatine Hill.', 4, 'culture', 18.00, 4.0, 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=600'),
('Vatican Museums & Sistine Chapel', 'Marvel at Michelangelo''s breathtaking ceiling in the Sistine Chapel and explore the vast Vatican Museums, home to one of the world''s greatest art collections.', 4, 'culture', 20.00, 4.0, 'https://images.unsplash.com/photo-1531572753322-ad063cecc140?w=600'),
('Trevi Fountain & Gelato Walk', 'Toss a coin in the magnificent Trevi Fountain for good luck, then stroll through Rome''s historic center sampling artisan gelato from the city''s best gelaterie.', 4, 'food', 10.00, 2.0, 'https://images.unsplash.com/photo-1529260830199-42c24126f198?w=600'),
('Pasta Making Class', 'Learn the art of making fresh pasta from scratch with a local Roman chef. Make tagliatelle, ravioli, and gnocchi, then enjoy your creations with wine.', 4, 'food', 75.00, 3.0, 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600');

-- Activities for Bali (city_id=5)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Ubud Rice Terrace Trek', 'Hike through the stunning emerald-green Tegallalang Rice Terraces near Ubud, one of Bali''s most iconic landscapes, and learn about traditional Balinese irrigation.', 5, 'adventure', 15.00, 3.0, 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600'),
('Tanah Lot Temple Sunset', 'Watch the sun set behind the dramatic sea temple of Tanah Lot, perched on a rocky outcrop in the ocean — one of Bali''s most photographed and sacred sites.', 5, 'culture', 5.00, 2.0, 'https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=600'),
('Balinese Cooking Class', 'Visit a local market to select fresh ingredients, then learn to prepare traditional Balinese dishes like satay, nasi goreng, and black rice pudding.', 5, 'food', 35.00, 4.0, 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600'),
('Surf Lesson at Kuta Beach', 'Take a beginner surf lesson on the famous waves of Kuta Beach with a certified instructor. Equipment and safety gear included.', 5, 'adventure', 25.00, 2.0, 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600');

-- Activities for London (city_id=6)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Tower of London & Crown Jewels', 'Explore the historic Tower of London, a UNESCO World Heritage Site, and marvel at the dazzling Crown Jewels, including the Imperial State Crown.', 6, 'culture', 30.00, 3.0, 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=600'),
('British Museum', 'Discover human history and culture at the world-famous British Museum, home to over 8 million works including the Rosetta Stone and Elgin Marbles.', 6, 'culture', 0.00, 4.0, 'https://images.unsplash.com/photo-1526129318478-62ed807ebdf9?w=600'),
('Borough Market Food Tour', 'Graze through London''s oldest and most renowned food market, sampling artisan cheeses, fresh bread, international street food, and craft beverages.', 6, 'food', 20.00, 2.0, 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600'),
('West End Theatre Show', 'Catch a world-class performance in London''s legendary West End theatre district, home to long-running musicals and acclaimed dramatic productions.', 6, 'culture', 85.00, 3.0, 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=600');

-- Activities for Barcelona (city_id=7)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Sagrada Família', 'Visit Gaudí''s unfinished masterpiece, the breathtaking Sagrada Família basilica, a UNESCO World Heritage Site that has been under construction since 1882.', 7, 'culture', 26.00, 2.5, 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=600'),
('Park Güell', 'Explore Gaudí''s whimsical hilltop park with its colorful mosaic terraces, gingerbread gatehouses, and stunning panoramic views over Barcelona.', 7, 'sightseeing', 10.00, 2.0, 'https://images.unsplash.com/photo-1583422409516-2895a77efded?w=600'),
('La Boqueria Market & Tapas Tour', 'Wander through the vibrant La Boqueria market on Las Ramblas, then join a tapas tour through the Gothic Quarter sampling patatas bravas, jamón, and cava.', 7, 'food', 40.00, 3.0, 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600');

-- Activities for Dubai (city_id=8)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Burj Khalifa At the Top', 'Ascend to the observation deck of the world''s tallest building for jaw-dropping 360-degree views of Dubai''s futuristic skyline, desert, and Arabian Gulf.', 8, 'sightseeing', 40.00, 2.0, 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600'),
('Desert Safari & BBQ Dinner', 'Experience the thrill of dune bashing in a 4x4, try sandboarding, ride a camel, and enjoy a traditional Bedouin camp dinner under the stars.', 8, 'adventure', 75.00, 6.0, 'https://images.unsplash.com/photo-1451337516015-6b6e9a44a8a3?w=600'),
('Dubai Mall & Dubai Fountain', 'Shop at the world''s largest mall, then watch the spectacular Dubai Fountain show — the world''s largest choreographed fountain system — at the base of Burj Khalifa.', 8, 'shopping', 0.00, 3.0, 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600');

-- Activities for Sydney (city_id=9)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Sydney Opera House Tour', 'Take a guided tour of the iconic Sydney Opera House, a UNESCO World Heritage Site, and learn about its fascinating history and stunning architecture.', 9, 'culture', 43.00, 1.5, 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=600'),
('Bondi to Coogee Coastal Walk', 'Hike the spectacular 6km coastal trail from Bondi Beach to Coogee, passing dramatic cliffs, ocean pools, and some of Sydney''s most beautiful beaches.', 9, 'adventure', 0.00, 3.0, 'https://images.unsplash.com/photo-1523428096881-5bd79d043006?w=600'),
('Sydney Harbour Bridge Climb', 'Climb to the summit of the iconic Sydney Harbour Bridge for unparalleled 360-degree views of the harbour, Opera House, and city skyline.', 9, 'adventure', 174.00, 3.5, 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=600');

-- Activities for Bangkok (city_id=10)
INSERT INTO `activities` (`name`, `description`, `city_id`, `category`, `cost`, `duration_hours`, `image_url`) VALUES
('Grand Palace & Wat Phra Kaew', 'Explore the dazzling Grand Palace complex and the Temple of the Emerald Buddha, the most sacred Buddhist temple in Thailand, adorned with intricate gold and mosaic work.', 10, 'culture', 15.00, 3.0, 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=600'),
('Bangkok Street Food Night Tour', 'Explore Bangkok''s legendary street food scene after dark, sampling pad thai, mango sticky rice, grilled satay, and exotic fruits from the city''s best street vendors.', 10, 'food', 35.00, 3.0, 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600'),
('Chao Phraya River & Temple Hop', 'Take a longtail boat along the Chao Phraya River, stopping at Wat Arun (Temple of Dawn), Wat Pho (Reclining Buddha), and other riverside temples.', 10, 'culture', 20.00, 4.0, 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=600'),
('Muay Thai Class', 'Train with professional Muay Thai fighters at a traditional Bangkok gym. Learn the basics of Thailand''s national martial art in an authentic setting.', 10, 'adventure', 30.00, 2.0, 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=600');
