<?php
$page_title = 'Trip Details';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id  = $_SESSION['user_id'];
$trip_id  = (int)($_GET['id'] ?? 0);

if (!$trip_id) { header('Location: my_trips.php'); exit(); }

// ── Fetch trip (must belong to user) ─────────────────────────────
$stmt = $conn->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $trip_id, $user_id);
$stmt->execute();
$trip = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$trip) { header('Location: my_trips.php'); exit(); }

// ── Fetch packing items ───────────────────────────────────────────
$pack_stmt = $conn->prepare("SELECT * FROM packing_items WHERE trip_id = ? ORDER BY category, item_name");
$pack_stmt->bind_param("i", $trip_id);
$pack_stmt->execute();
$packing = $pack_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$pack_stmt->close();

$packed_count = count(array_filter($packing, fn($i) => $i['is_packed']));
$pack_pct     = count($packing) > 0 ? round(($packed_count / count($packing)) * 100) : 0;

// ── Fetch notes ───────────────────────────────────────────────────
$notes_stmt = $conn->prepare("SELECT * FROM trip_notes WHERE trip_id = ? ORDER BY updated_at DESC");
$notes_stmt->bind_param("i", $trip_id);
$notes_stmt->execute();
$notes = $notes_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$notes_stmt->close();

// ── Fetch budget items ────────────────────────────────────────────
$budget_stmt = $conn->prepare("SELECT * FROM budget_items WHERE trip_id = ? ORDER BY category");
$budget_stmt->bind_param("i", $trip_id);
$budget_stmt->execute();
$budget_items = $budget_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$budget_stmt->close();

$total_est = array_sum(array_column($budget_items, 'estimated_cost'));
$total_act = array_sum(array_filter(array_column($budget_items, 'actual_cost'), fn($v) => $v !== null && $v !== ''));

// ── Duration ─────────────────────────────────────────────────────
$duration_days = null;
if (!empty($trip['start_date']) && !empty($trip['end_date'])) {
    $diff = (strtotime($trip['end_date']) - strtotime($trip['start_date'])) / 86400;
    $duration_days = max(1, (int)$diff + 1);
}

$cat_icons = ['flights'=>'✈️','hotels'=>'🏨','food'=>'🍽️','activities'=>'🎯','transport'=>'🚌','shopping'=>'🛍️','other'=>'📦'];
$note_colors = ['#fef9c3','#dbeafe','#d1fae5','#fce7f3','#ede9fe','#ffedd5'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($trip['name']); ?> – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif; color: #1a1a2e; min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* NAV */
        header { background: #0f172a; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 20px rgba(0,0,0,0.3); }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2) !important; color: #fff !important; }

        /* HERO */
        .trip-hero {
            position: relative; overflow: hidden; min-height: 320px;
            display: flex; align-items: flex-end;
        }
        .trip-hero-bg {
            position: absolute; inset: 0;
            background: linear-gradient(135deg, rgba(8,15,50,0.70) 0%, rgba(25,8,60,0.80) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
        }
        <?php if (!empty($trip['cover_photo']) && file_exists(__DIR__ . '/assets/uploads/' . $trip['cover_photo'])): ?>
        .trip-hero-bg {
            background: linear-gradient(to top, rgba(8,12,35,0.85) 0%, rgba(8,12,35,0.30) 100%),
                        url('assets/uploads/<?php echo htmlspecialchars($trip['cover_photo']); ?>') center/cover no-repeat;
        }
        <?php endif; ?>
        .trip-hero-content { position: relative; z-index: 1; width: 100%; max-width: 1200px; margin: 0 auto; padding: 40px 40px 44px; }
        .breadcrumb { font-size: 13px; color: rgba(255,255,255,0.55); margin-bottom: 14px; }
        .breadcrumb a { color: rgba(255,255,255,0.55); text-decoration: none; }
        .breadcrumb a:hover { color: #fff; }
        .trip-hero-title { font-size: 40px; font-weight: 900; color: #fff; margin-bottom: 12px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); line-height: 1.15; }
        .trip-meta { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 22px; }
        .meta-tag { display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.15); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.20); color: rgba(255,255,255,0.90); font-size: 13px; font-weight: 600; padding: 6px 14px; border-radius: 20px; }
        .status-draft     { background: rgba(251,191,36,0.25); border-color: rgba(251,191,36,0.40); color: #fde68a; }
        .status-published { background: rgba(34,197,94,0.25);  border-color: rgba(34,197,94,0.40);  color: #86efac; }
        .status-shared    { background: rgba(96,165,250,0.25);  border-color: rgba(96,165,250,0.40);  color: #bfdbfe; }
        .hero-actions { display: flex; gap: 10px; flex-wrap: wrap; }
        .btn-edit { padding: 10px 22px; background: rgba(255,255,255,0.15); backdrop-filter: blur(8px); color: #fff; border: 1.5px solid rgba(255,255,255,0.30); border-radius: 9px; text-decoration: none; font-size: 14px; font-weight: 700; transition: background 0.2s; }
        .btn-edit:hover { background: rgba(255,255,255,0.25); }
        .btn-delete { padding: 10px 22px; background: rgba(239,68,68,0.20); backdrop-filter: blur(8px); color: #fca5a5; border: 1.5px solid rgba(239,68,68,0.35); border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; transition: background 0.2s; }
        .btn-delete:hover { background: rgba(239,68,68,0.35); }

        /* MAIN */
        main { max-width: 1200px; margin: 0 auto; padding: 36px 40px 70px; }

        /* STATS ROW */
        .stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 36px; }
        .stat-card { background: rgba(255,255,255,0.97); border-radius: 14px; padding: 20px 22px; box-shadow: 0 4px 18px rgba(0,0,0,0.10); text-align: center; }
        .stat-icon { font-size: 28px; margin-bottom: 8px; }
        .stat-num  { font-size: 26px; font-weight: 900; color: #667eea; line-height: 1; margin-bottom: 4px; }
        .stat-label{ font-size: 12px; color: #888; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }

        /* TWO COL */
        .two-col { display: grid; grid-template-columns: 1fr 360px; gap: 28px; margin-bottom: 36px; }

        /* CARD */
        .card { background: rgba(255,255,255,0.97); border-radius: 14px; box-shadow: 0 4px 18px rgba(0,0,0,0.10); overflow: hidden; margin-bottom: 24px; }
        .card:last-child { margin-bottom: 0; }
        .card-header { padding: 16px 22px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
        .card-header h3 { font-size: 15px; font-weight: 800; color: #1a1a2e; }
        .card-link { font-size: 13px; color: #667eea; text-decoration: none; font-weight: 600; }
        .card-link:hover { text-decoration: underline; }
        .card-body { padding: 20px 22px; }

        /* DESCRIPTION */
        .trip-desc { font-size: 15px; color: #444; line-height: 1.7; }

        /* PROGRESS */
        .progress-wrap { margin-bottom: 16px; }
        .progress-label { display: flex; justify-content: space-between; font-size: 13px; font-weight: 600; color: #555; margin-bottom: 7px; }
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 10px; overflow: hidden; }
        .progress-fill { height: 100%; background: linear-gradient(135deg,#667eea,#764ba2); border-radius: 10px; }

        /* PACKING LIST */
        .pack-item { display: flex; align-items: center; gap: 10px; padding: 9px 0; border-bottom: 1px solid #f8f8f8; font-size: 14px; }
        .pack-item:last-child { border-bottom: none; }
        .pack-check { width: 20px; height: 20px; border-radius: 5px; border: 2px solid #c7d2fe; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
        .pack-check.done { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; color: #fff; font-size: 11px; font-weight: 800; }
        .pack-name { flex: 1; color: #1a1a2e; }
        .pack-name.done { text-decoration: line-through; color: #aaa; }
        .pack-cat { font-size: 11px; color: #888; background: #f3f4f6; padding: 2px 8px; border-radius: 10px; }

        /* NOTES */
        .notes-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .note-mini { border-radius: 10px; padding: 14px; }
        .note-mini-title { font-size: 13px; font-weight: 800; color: #1a1a2e; margin-bottom: 5px; }
        .note-mini-body  { font-size: 12px; color: #555; line-height: 1.5;
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }

        /* BUDGET TABLE */
        .budget-table { width: 100%; border-collapse: collapse; }
        .budget-table th { padding: 10px 16px; text-align: left; font-size: 11px; font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.5px; background: #fafbff; border-bottom: 1px solid #f0f0f0; }
        .budget-table td { padding: 12px 16px; border-bottom: 1px solid #f8f8f8; font-size: 13px; color: #444; }
        .budget-table tbody tr:last-child td { border-bottom: none; }
        .cat-badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 9px; border-radius: 12px; font-size: 11px; font-weight: 700; }
        .cat-flights    { background: #dbeafe; color: #1d4ed8; }
        .cat-hotels     { background: #ede9fe; color: #6d28d9; }
        .cat-food       { background: #fef3c7; color: #92400e; }
        .cat-activities { background: #d1fae5; color: #065f46; }
        .cat-transport  { background: #e0f2fe; color: #0369a1; }
        .cat-shopping   { background: #fce7f3; color: #9d174d; }
        .cat-other      { background: #f3f4f6; color: #374151; }
        .budget-total { padding: 14px 16px; background: #f8f9ff; border-top: 2px solid #eef0f8; display: flex; justify-content: space-between; font-size: 14px; font-weight: 800; color: #1a1a2e; }

        /* EMPTY */
        .empty-mini { padding: 28px 16px; text-align: center; color: #bbb; font-size: 14px; }
        .empty-mini .ei { font-size: 36px; margin-bottom: 8px; }

        /* QUICK LINKS */
        .quick-links { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding: 16px 22px; }
        .quick-link { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: #f8f9ff; border-radius: 10px; text-decoration: none; color: #1a1a2e; font-size: 13px; font-weight: 600; border: 1.5px solid #eef0f8; transition: all 0.2s; }
        .quick-link:hover { background: #eef0ff; border-color: #c7d2fe; color: #667eea; }
        .quick-link-icon { font-size: 20px; }

        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 22px; font-size: 13px; }

        @media (max-width: 1000px) { .two-col { grid-template-columns: 1fr; } .stats-row { grid-template-columns: repeat(2,1fr); } }
        @media (max-width: 600px) { header nav { padding: 0 16px; } .trip-hero-content { padding: 28px 20px 32px; } .trip-hero-title { font-size: 26px; } main { padding: 24px 16px 50px; } .stats-row { grid-template-columns: repeat(2,1fr); } .notes-grid { grid-template-columns: 1fr; } .quick-links { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php">Budget</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<!-- HERO -->
<div class="trip-hero">
    <div class="trip-hero-bg"></div>
    <div class="trip-hero-content">
        <div class="breadcrumb">
            <a href="dashboard.php">Dashboard</a> &nbsp;/&nbsp;
            <a href="my_trips.php">My Trips</a> &nbsp;/&nbsp;
            <?php echo htmlspecialchars($trip['name']); ?>
        </div>
        <h1 class="trip-hero-title"><?php echo htmlspecialchars($trip['name']); ?></h1>
        <div class="trip-meta">
            <?php if (!empty($trip['start_date'])): ?>
                <span class="meta-tag">📅 <?php echo date('M j, Y', strtotime($trip['start_date'])); ?></span>
            <?php endif; ?>
            <?php if (!empty($trip['end_date'])): ?>
                <span class="meta-tag">🏁 <?php echo date('M j, Y', strtotime($trip['end_date'])); ?></span>
            <?php endif; ?>
            <?php if ($duration_days): ?>
                <span class="meta-tag">⏱️ <?php echo $duration_days; ?> day<?php echo $duration_days > 1 ? 's' : ''; ?></span>
            <?php endif; ?>
            <?php if (!empty($trip['budget']) && $trip['budget'] > 0): ?>
                <span class="meta-tag">💰 <?php echo htmlspecialchars($trip['currency'] ?? 'USD'); ?> <?php echo number_format($trip['budget'], 0); ?></span>
            <?php endif; ?>
            <span class="meta-tag status-<?php echo htmlspecialchars($trip['status']); ?>">
                <?php
                $status_icons = ['draft'=>'🗒️','published'=>'✅','shared'=>'🔗'];
                echo ($status_icons[$trip['status']] ?? '📌') . ' ' . ucfirst(htmlspecialchars($trip['status']));
                ?>
            </span>
        </div>
        <div class="hero-actions">
            <a href="edit-trip.php?id=<?php echo $trip_id; ?>" class="btn-edit">✏️ Edit Trip</a>
            <form method="POST" action="delete_trip.php" style="display:inline;"
                  onsubmit="return confirm('Delete this trip permanently? This cannot be undone.');">
                <input type="hidden" name="trip_id" value="<?php echo $trip_id; ?>">
                <button type="submit" class="btn-delete">🗑️ Delete</button>
            </form>
        </div>
    </div>
</div>

<main>

    <!-- STATS ROW -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon">🧳</div>
            <div class="stat-num"><?php echo count($packing); ?></div>
            <div class="stat-label">Packing Items</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">✅</div>
            <div class="stat-num"><?php echo $pack_pct; ?>%</div>
            <div class="stat-label">Packed</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📝</div>
            <div class="stat-num"><?php echo count($notes); ?></div>
            <div class="stat-label">Notes</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">💰</div>
            <div class="stat-num">$<?php echo number_format($total_est, 0); ?></div>
            <div class="stat-label">Est. Budget</div>
        </div>
    </div>

    <div class="two-col">

        <!-- LEFT -->
        <div>
            <!-- Description -->
            <?php if (!empty($trip['description'])): ?>
            <div class="card">
                <div class="card-header"><h3>📋 About This Trip</h3></div>
                <div class="card-body">
                    <p class="trip-desc"><?php echo nl2br(htmlspecialchars($trip['description'])); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Budget -->
            <div class="card">
                <div class="card-header">
                    <h3>💰 Budget</h3>
                    <a href="budget.php" class="card-link">Manage →</a>
                </div>
                <?php if (!empty($budget_items)): ?>
                <table class="budget-table">
                    <thead>
                        <tr><th>Category</th><th>Description</th><th>Estimated</th><th>Actual</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($budget_items as $bi):
                            $cat = strtolower($bi['category'] ?? 'other');
                            $icon = $cat_icons[$cat] ?? '📦';
                        ?>
                        <tr>
                            <td><span class="cat-badge cat-<?php echo htmlspecialchars($cat); ?>"><?php echo $icon . ' ' . ucfirst($cat); ?></span></td>
                            <td><?php echo htmlspecialchars($bi['description']); ?></td>
                            <td>$<?php echo number_format($bi['estimated_cost'], 2); ?></td>
                            <td><?php echo ($bi['actual_cost'] !== null && $bi['actual_cost'] !== '') ? '$' . number_format($bi['actual_cost'], 2) : '—'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="budget-total">
                    <span>Total Estimated</span>
                    <span>$<?php echo number_format($total_est, 2); ?></span>
                </div>
                <?php else: ?>
                <div class="empty-mini"><div class="ei">💰</div><p>No budget items yet. <a href="budget.php" style="color:#667eea;">Add some →</a></p></div>
                <?php endif; ?>
            </div>

            <!-- Notes -->
            <div class="card">
                <div class="card-header">
                    <h3>📝 Notes</h3>
                    <a href="notes.php" class="card-link">All Notes →</a>
                </div>
                <?php if (!empty($notes)): ?>
                <div class="card-body">
                    <div class="notes-grid">
                        <?php foreach (array_slice($notes, 0, 4) as $idx => $note): ?>
                        <div class="note-mini" style="background:<?php echo $note_colors[$idx % count($note_colors)]; ?>;">
                            <div class="note-mini-title"><?php echo htmlspecialchars($note['title']); ?></div>
                            <div class="note-mini-body"><?php echo htmlspecialchars($note['content']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="empty-mini"><div class="ei">📝</div><p>No notes yet. <a href="notes.php" style="color:#667eea;">Add a note →</a></p></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- RIGHT SIDEBAR -->
        <div>
            <!-- Packing progress -->
            <div class="card">
                <div class="card-header">
                    <h3>🧳 Packing</h3>
                    <a href="packing.php" class="card-link">Manage →</a>
                </div>
                <?php if (!empty($packing)): ?>
                <div class="card-body">
                    <div class="progress-wrap">
                        <div class="progress-label">
                            <span>Progress</span>
                            <span><?php echo $packed_count; ?>/<?php echo count($packing); ?> (<?php echo $pack_pct; ?>%)</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:<?php echo $pack_pct; ?>%"></div>
                        </div>
                    </div>
                    <?php foreach (array_slice($packing, 0, 8) as $item): ?>
                    <div class="pack-item">
                        <div class="pack-check <?php echo $item['is_packed'] ? 'done' : ''; ?>">
                            <?php echo $item['is_packed'] ? '✓' : ''; ?>
                        </div>
                        <span class="pack-name <?php echo $item['is_packed'] ? 'done' : ''; ?>">
                            <?php echo htmlspecialchars($item['item_name']); ?>
                        </span>
                        <span class="pack-cat"><?php echo htmlspecialchars($item['category']); ?></span>
                    </div>
                    <?php endforeach; ?>
                    <?php if (count($packing) > 8): ?>
                    <div style="padding:10px 0 0;text-align:center;font-size:13px;color:#888;">
                        +<?php echo count($packing) - 8; ?> more items
                        <a href="packing.php" style="color:#667eea;font-weight:600;"> View all →</a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="empty-mini"><div class="ei">🧳</div><p>No packing items. <a href="packing.php" style="color:#667eea;">Start packing →</a></p></div>
                <?php endif; ?>
            </div>

            <!-- Quick Links -->
            <div class="card">
                <div class="card-header"><h3>⚡ Quick Actions</h3></div>
                <div class="quick-links">
                    <a href="itinerary.php" class="quick-link"><span class="quick-link-icon">📅</span> Itinerary</a>
                    <a href="packing.php"   class="quick-link"><span class="quick-link-icon">🧳</span> Packing</a>
                    <a href="notes.php"     class="quick-link"><span class="quick-link-icon">📝</span> Notes</a>
                    <a href="budget.php"    class="quick-link"><span class="quick-link-icon">💰</span> Budget</a>
                    <a href="city-search.php" class="quick-link"><span class="quick-link-icon">🌍</span> Cities</a>
                    <a href="activity-search.php" class="quick-link"><span class="quick-link-icon">🎯</span> Activities</a>
                </div>
            </div>
        </div>

    </div>
</main>

<footer><p>© 2026 Travel Planner. All rights reserved.</p></footer>
</body>
</html>
