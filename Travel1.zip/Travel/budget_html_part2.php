
<!-- ===== NAVBAR ===== -->
<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my-trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php" class="active">Budget</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?>
            <li><a href="admin/index.php">Admin</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<!-- ===== HERO ===== -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-badge">💰 Budget Planner</div>
        <h1 class="hero-title">💰 Travel Budget Planner</h1>
        <p class="hero-sub">Hotels, Transport &amp; Budget tracking for every trip</p>
    </div>
</section>

<!-- ===== PAGE MAIN ===== -->
<div class="page-main">

    <!-- ── CITY SELECTOR ── -->
    <div class="city-selector">
        <div class="city-selector-label">🌍 Select a City</div>
        <div class="city-pills">
            <?php
            $city_keys = array_keys($transport_options);
            foreach ($city_keys as $idx => $city_name):
                $active_class = ($idx === 0) ? ' active' : '';
            ?>
            <button class="city-pill<?php echo $active_class; ?>"
                    onclick="showCity('<?php echo htmlspecialchars($city_name, ENT_QUOTES); ?>')">
                <?php echo htmlspecialchars($city_name); ?>
            </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── PER-CITY SECTIONS ── -->
    <?php foreach ($transport_options as $city_name => $transports):
        $is_first = ($city_name === $city_keys[0]);
        $hotels   = $hotels_data[$city_name] ?? [];
        $city_id  = 'city-' . preg_replace('/\s+/', '-', $city_name);
    ?>
    <div id="<?php echo htmlspecialchars($city_id); ?>"
         class="city-section<?php echo $is_first ? ' active' : ''; ?>">

        <!-- ── SECTION A: HOTELS ── -->
        <div class="sec-header">
            <h2 class="sec-title">🏨 Hotel Booking
                <span class="sec-badge">Price: High → Low</span>
            </h2>
        </div>
        <div class="hotels-grid">
            <?php foreach ($hotels as $hotel): ?>
            <div class="hotel-card">
                <img class="hotel-img"
                     src="<?php echo htmlspecialchars($hotel['img']); ?>"
                     alt="<?php echo htmlspecialchars($hotel['name']); ?>"
                     loading="lazy"
                     onerror="this.src='https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70'">
                <div class="hotel-body">
                    <div class="hotel-stars">
                        <?php echo str_repeat('⭐', (int)$hotel['stars']); ?>
                    </div>
                    <div class="hotel-name"><?php echo htmlspecialchars($hotel['name']); ?></div>
                    <div class="hotel-price">
                        $<?php echo number_format($hotel['price']); ?>
                        <span>/ night</span>
                    </div>
                    <div class="hotel-amenities"><?php echo htmlspecialchars($hotel['amenities']); ?></div>
                    <button class="btn-book">Book Now</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- ── SECTION B: TRANSPORT ── -->
        <div class="transport-section">
            <div class="sec-header">
                <h2 class="sec-title">🚌 Transport Options</h2>
            </div>

            <!-- Filter pills -->
            <div class="filter-pills" id="filter-<?php echo htmlspecialchars($city_id); ?>">
                <button class="filter-pill active" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'all', this)">All</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Flight', this)">✈️ Flight</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Cab', this)">🚕 Cab</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Bus', this)">🚌 Bus</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Metro', this)">🚇 Metro/Train</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Tuk', this)">🛺 Auto/Tuk-Tuk</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Express', this)">🚄 Express</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Scooter', this)">🛵 Scooter</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Bike', this)">🚲 Bike</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Ferry', this)">🚢 Ferry</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Walk', this)">🚶 Walk</button>
            </div>

            <!-- Transport cards -->
            <div class="transport-grid" id="tgrid-<?php echo htmlspecialchars($city_id); ?>">
                <?php foreach ($transports as $t):
                    // Extract the text label from the emoji+text type string
                    $type_raw = $t['type'];
                    // Build a data-type attribute with the raw type for JS filtering
                ?>
                <div class="transport-card" data-type="<?php echo htmlspecialchars($type_raw); ?>">
                    <span class="transport-icon"><?php
                        // Extract just the emoji (first grapheme cluster)
                        preg_match('/^\X/u', $type_raw, $em);
                        echo isset($em[0]) ? htmlspecialchars($em[0]) : '🚗';
                    ?></span>
                    <div class="transport-type"><?php
                        // Strip leading emoji for the label
                        $label = trim(preg_replace('/^\X\s*/u', '', $type_raw));
                        echo htmlspecialchars($label);
                    ?></div>
                    <div class="transport-route">
                        <?php echo htmlspecialchars($t['from']); ?>
                        <span class="arrow">→</span>
                        <?php echo htmlspecialchars($t['to']); ?>
                    </div>
                    <span class="transport-duration"><?php echo htmlspecialchars($t['duration']); ?></span>
                    <div class="transport-price<?php echo ($t['price'] == 0) ? ' free' : ''; ?>">
                        <?php echo ($t['price'] == 0) ? 'Free' : '$' . number_format($t['price']); ?>
                    </div>
                    <button class="btn-select">Select</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div><!-- /city-section -->
    <?php endforeach; ?>

    <!-- ── BUDGET TRACKER ── -->
    <div class="budget-section">
        <div class="sec-header">
            <h2 class="sec-title">📊 Budget Tracker</h2>
        </div>

        <?php if (!empty($user_trips)): ?>
        <!-- Add Budget Item Form -->
        <div class="budget-card">
            <div class="budget-card-header">
                <h3>➕ Add Budget Item</h3>
            </div>
            <form method="POST" action="budget.php" class="budget-form">
                <input type="hidden" name="add_budget" value="1">
                <div class="form-row">
                    <div class="form-group">
                        <label>Trip</label>
                        <select name="trip_id" required>
                            <option value="">— Select Trip —</option>
                            <?php foreach ($user_trips as $trip): ?>
                            <option value="<?php echo (int)$trip['id']; ?>">
                                <?php echo htmlspecialchars($trip['name'] ?? $trip['title'] ?? 'Trip #' . $trip['id']); ?>
                                <?php if (!empty($trip['start_date'])): ?>
                                    (<?php echo date('M Y', strtotime($trip['start_date'])); ?>)
                                <?php endif; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category" required>
                            <option value="flights">✈️ Flights</option>
                            <option value="hotels">🏨 Hotels</option>
                            <option value="food">🍽️ Food</option>
                            <option value="activities">🎯 Activities</option>
                            <option value="transport">🚌 Transport</option>
                            <option value="shopping">🛍️ Shopping</option>
                            <option value="other">📦 Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Currency</label>
                        <select name="currency">
                            <option value="USD">USD $</option>
                            <option value="EUR">EUR €</option>
                            <option value="GBP">GBP £</option>
                            <option value="JPY">JPY ¥</option>
                            <option value="AUD">AUD A$</option>
                            <option value="SGD">SGD S$</option>
                            <option value="THB">THB ฿</option>
                            <option value="IDR">IDR Rp</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group" style="grid-column: span 3;">
                        <label>Description</label>
                        <input type="text" name="description" placeholder="e.g. Return flight to Paris" required maxlength="255">
                    </div>
                </div>
                <div class="form-row-2">
                    <div class="form-group">
                        <label>Estimated Cost</label>
                        <input type="number" name="estimated_cost" placeholder="0.00" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label>Actual Cost <span style="font-weight:400;color:#aaa;">(optional)</span></label>
                        <input type="number" name="actual_cost" placeholder="0.00" step="0.01" min="0">
                    </div>
                </div>
                <button type="submit" class="btn-add-budget">➕ Add Item</button>
            </form>
        </div>

        <!-- Budget Items by Trip -->
        <?php if (!empty($budget_by_trip)):
            $cat_icons = [
                'flights'    => '✈️',
                'hotels'     => '🏨',
                'food'       => '🍽️',
                'activities' => '🎯',
                'transport'  => '🚌',
                'shopping'   => '🛍️',
                'other'      => '📦',
            ];
            foreach ($budget_by_trip as $trip_id => $trip_data):
                $items = $trip_data['items'] ?? [];
                $total_est = array_sum(array_column($items, 'estimated_cost'));
                $total_act = array_sum(array_filter(array_column($items, 'actual_cost'), fn($v) => $v !== null));
        ?>
        <div class="budget-card budget-trip-block">
            <div class="budget-trip-name">
                🗺️ <?php echo htmlspecialchars($trip_data['name']); ?>
                <span style="margin-left:auto;font-size:13px;font-weight:600;color:#888;">
                    Est: $<?php echo number_format($total_est, 2); ?>
                    <?php if ($total_act > 0): ?>
                    &nbsp;|&nbsp; Actual: $<?php echo number_format($total_act, 2); ?>
                    <?php endif; ?>
                </span>
            </div>
            <table class="budget-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Estimated</th>
                        <th>Actual</th>
                        <th>Difference</th>
                        <th>Currency</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item):
                        $cat = strtolower($item['category'] ?? 'other');
                        $icon = $cat_icons[$cat] ?? '📦';
                        $est  = floatval($item['estimated_cost']);
                        $act  = ($item['actual_cost'] !== null && $item['actual_cost'] !== '') ? floatval($item['actual_cost']) : null;
                        if ($act !== null) {
                            $diff = $act - $est;
                            $diff_class = ($diff <= 0) ? 'diff-under' : 'diff-over';
                            $diff_str   = ($diff <= 0 ? '-$' . number_format(abs($diff), 2) : '+$' . number_format($diff, 2));
                        }
                    ?>
                    <tr>
                        <td>
                            <span class="cat-badge cat-<?php echo htmlspecialchars($cat); ?>">
                                <?php echo $icon; ?> <?php echo htmlspecialchars(ucfirst($cat)); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                        <td>$<?php echo number_format($est, 2); ?></td>
                        <td><?php echo ($act !== null) ? '$' . number_format($act, 2) : '<span class="diff-na">—</span>'; ?></td>
                        <td>
                            <?php if ($act !== null): ?>
                                <span class="<?php echo $diff_class; ?>"><?php echo $diff_str; ?></span>
                            <?php else: ?>
                                <span class="diff-na">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($item['currency'] ?? 'USD'); ?></td>
                        <td>
                            <form method="POST" action="budget.php" style="display:inline;">
                                <input type="hidden" name="delete_item" value="1">
                                <input type="hidden" name="item_id" value="<?php echo (int)$item['id']; ?>">
                                <button type="submit" class="btn-delete"
                                        onclick="return confirm('Delete this budget item?')">🗑️</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="budget-card">
            <div class="empty-state">
                <div class="empty-icon">📊</div>
                <p>No budget items yet. Add your first item above!</p>
            </div>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <!-- No trips -->
        <div class="budget-card">
            <div class="empty-state">
                <div class="empty-icon">🗺️</div>
                <p>You need to create a trip before tracking your budget.</p>
                <a href="create-trip.php" class="btn-primary-link">➕ Create Your First Trip</a>
            </div>
        </div>
        <?php endif; ?>
    </div><!-- /budget-section -->

</div><!-- /page-main -->

<!-- ===== FOOTER ===== -->
<footer>
    <p>© 2026 Travel Planner. All rights reserved.</p>
</footer>

<script>
// ── Show/hide city sections ──────────────────────────────────────────
function showCity(cityName) {
    // Hide all city sections
    document.querySelectorAll('.city-section').forEach(function(el) {
        el.classList.remove('active');
    });
    // Deactivate all city pills
    document.querySelectorAll('.city-pill').forEach(function(btn) {
        btn.classList.remove('active');
    });
    // Show the selected city section
    var cityId = 'city-' + cityName.replace(/\s+/g, '-');
    var section = document.getElementById(cityId);
    if (section) section.classList.add('active');
    // Activate the clicked pill
    document.querySelectorAll('.city-pill').forEach(function(btn) {
        if (btn.textContent.trim() === cityName) btn.classList.add('active');
    });
}

// ── Transport filter ─────────────────────────────────────────────────
function filterTransport(cityId, keyword, clickedBtn) {
    // Update active pill
    var pillContainer = document.getElementById('filter-' + cityId);
    if (pillContainer) {
        pillContainer.querySelectorAll('.filter-pill').forEach(function(p) {
            p.classList.remove('active');
        });
    }
    if (clickedBtn) clickedBtn.classList.add('active');

    // Show/hide transport cards
    var grid = document.getElementById('tgrid-' + cityId);
    if (!grid) return;
    grid.querySelectorAll('.transport-card').forEach(function(card) {
        if (keyword === 'all') {
            card.classList.remove('hidden');
        } else {
            var type = card.getAttribute('data-type') || '';
            if (type.toLowerCase().indexOf(keyword.toLowerCase()) !== -1) {
                card.classList.remove('hidden');
            } else {
                card.classList.add('hidden');
            }
        }
    });
}

// ── On page load: show first city ───────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
    var firstPill = document.querySelector('.city-pill');
    if (firstPill) {
        var firstCity = firstPill.textContent.trim();
        showCity(firstCity);
    }
});
</script>
</body>
</html>
