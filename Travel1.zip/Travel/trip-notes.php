<?php
$page_title = 'Trip Notes';
require_once 'includes/header.php';
requireLogin();
?>

<h1>Trip Notes</h1>
<p>Manage your trip notes here.</p>

<?php require_once 'includes/footer.php'; ?>
