<?php
$page_title = 'Search Cities';
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

// Fetch all cities ordered by popular first, then name
$stmt = $conn->prepare("SELECT * FROM cities ORDER BY popular DESC, name ASC");
$stmt->execute();
$cities = $stmt->get_result();
$stmt->close();

// Fetch activity counts per city
$act_stmt = $conn->prepare("SELECT city_id, COUNT(*) as total FROM activities GROUP BY city_id");
$act_stmt->execute();
$act_result = $act_stmt->get_result();
$activity_counts = [];
while ($row = $act_result->fetch_assoc()) {
    $activity_counts[$row['city_id']] = $row['total'];
}
$act_stmt->close();

// Collect all cities into array for JS filtering
$all_cities = [];
while ($city = $cities->fetch_assoc()) {
    $city['activity_count'] = $activity_counts[$city['id']] ?? 0;
    $all_cities[] = $city;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Travel Planner</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* ── Hero ── */
        .page-hero {
            background:
                linear-gradient(135deg, rgba(10,20,60,0.72) 0%, rgba(30,10,70,0.78) 100%),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat;
            border-radius: 14px;
            padding: 52px 40px;
            text-align: center;
            margin-bottom: 36px;
            position: relative;
            overflow: hidden;
        }
        .page-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(ellipse 70% 60% at 50% 50%, rgba(102,126,234,0.18) 0%, transparent 70%);
        }
        .page-hero h1 {
            color: #fff;
            font-size: 34px;
            font-weight: 900;
            margin: 0 0 10px;
            position: relative;
        }
        .page-hero p {
            color: rgba(255,255,255,0.68);
            font-size: 15px;
            margin: 0 0 28px;
            position: relative;
        }

        /* ── Search bar ── */
        .search-bar-wrap {
            position: relative;
            max-width: 520px;
            margin: 0 auto;
        }
        .search-bar-wrap .search-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            pointer-events: none;
        }
        #city-search-input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            border-radius: 50px;
            border: none;
            font-size: 15px;
            font-family: inherit;
            background: rgba(255,255,255,0.95);
            color: #1a1a2e;
            box-shadow: 0 8px 30px rgba(0,0,0,0.25);
            outline: none;
            transition: box-shadow 0.25s;
        }
        #city-search-input:focus {
            box-shadow: 0 8px 30px rgba(102,126,234,0.40);
        }
        #city-search-input::placeholder { color: #9ca3af; }

        /* ── Toolbar ── */
        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
            margin-bottom: 28px;
        }
        .results-count {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }
        .results-count span { color: #667eea; font-weight: 700; }

        /* Filter pills */
        .filter-pills {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .pill {
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dde1ec;
            background: white;
            color: #555;
            transition: all 0.2s;
        }
        .pill:hover  { border-color: #667eea; color: #667eea; }
        .pill.active { background: #667eea; color: white; border-color: #667eea; }

        /* ── Cities grid ── */
        .cities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }

        /* ── City card ── */
        .city-card {
            background: white;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 3px 12px rgba(0,0,0,0.09);
            transition: transform 0.25s, box-shadow 0.25s;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            flex-direction: column;
        }
        .city-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 32px rgba(0,0,0,0.15);
        }

        /* Image */
        .city-img-wrap {
            position: relative;
            height: 200px;
            overflow: hidden;
        }
        .city-img-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.4s;
            border-radius: 0;
        }
        .city-card:hover .city-img-wrap img { transform: scale(1.07); }

        /* Popular badge */
        .popular-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            background: linear-gradient(135deg, #f59e0b, #ef4444);
            color: white;
            font-size: 11px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 20px;
            letter-spacing: 0.5px;
        }

        /* Activity count badge */
        .activity-badge {
            position: absolute;
            top: 12px;
            right: 12px;
            background: rgba(0,0,0,0.55);
            backdrop-filter: blur(6px);
            color: white;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 20px;
        }

        /* Card body */
        .city-body {
            padding: 20px 22px 22px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .city-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .city-name {
            font-size: 20px;
            font-weight: 800;
            color: #1a1a2e;
            margin: 0;
        }
        .city-country {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 13px;
            color: #667eea;
            font-weight: 600;
            white-space: nowrap;
        }
        .city-desc {
            font-size: 13px;
            color: #666;
            line-height: 1.6;
            flex: 1;
            /* clamp to 3 lines */
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            margin-bottom: 16px;
        }
        .city-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .activities-info {
            font-size: 13px;
            color: #888;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .btn-explore {
            padding: 8px 18px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 3px 10px rgba(102,126,234,0.30);
        }
        .btn-explore:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 16px rgba(102,126,234,0.45);
        }

        /* ── Empty state ── */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: #aaa;
        }
        .empty-state .empty-icon { font-size: 56px; margin-bottom: 14px; }
        .empty-state p { font-size: 16px; }

        /* ── Responsive ── */
        @media (max-width: 600px) {
            .page-hero { padding: 36px 20px; }
            .page-hero h1 { font-size: 24px; }
            .cities-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <!-- Nav -->
    <header>
        <nav>
            <div class="logo">✈️ Travel Planner</div>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="my_trips.php">My Trips</a></li>
                <li><a href="city-search.php" style="color:#a78bfa;">Cities</a></li>
                <li><a href="activity-search.php">Activities</a></li>
                <li><a href="profile.php">Profile</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin/index.php">Admin</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Hero with search -->
        <div class="page-hero">
            <h1>🌍 Explore Destinations</h1>
            <p>Discover amazing cities around the world and plan your next adventure</p>
            <div class="search-bar-wrap">
                <span class="search-icon">🔍</span>
                <input type="text" id="city-search-input"
                       placeholder="Search cities or countries…"
                       oninput="filterCities()">
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="results-count">
                Showing <span id="result-count"><?php echo count($all_cities); ?></span>
                of <?php echo count($all_cities); ?> destinations
            </div>
            <div class="filter-pills">
                <button class="pill active" onclick="setFilter('all', this)">🌐 All</button>
                <button class="pill" onclick="setFilter('popular', this)">⭐ Popular</button>
                <button class="pill" onclick="setFilter('asia', this)">🌏 Asia</button>
                <button class="pill" onclick="setFilter('europe', this)">🏰 Europe</button>
                <button class="pill" onclick="setFilter('americas', this)">🗽 Americas</button>
                <button class="pill" onclick="setFilter('oceania', this)">🦘 Oceania</button>
                <button class="pill" onclick="setFilter('middleeast', this)">🕌 Middle East</button>
            </div>
        </div>

        <!-- Cities grid -->
        <div class="cities-grid" id="cities-grid">
            <?php foreach ($all_cities as $city): ?>
                <a class="city-card"
                   href="activity-search.php?city_id=<?php echo (int)$city['id']; ?>"
                   data-name="<?php echo strtolower(htmlspecialchars($city['name'])); ?>"
                   data-country="<?php echo strtolower(htmlspecialchars($city['country'])); ?>"
                   data-popular="<?php echo $city['popular'] ? '1' : '0'; ?>">

                    <div class="city-img-wrap">
                        <img src="<?php echo htmlspecialchars($city['image_url']); ?>"
                             alt="<?php echo htmlspecialchars($city['name']); ?>"
                             loading="lazy"
                             onerror="this.src='https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=60'">

                        <?php if ($city['popular']): ?>
                            <span class="popular-badge">⭐ Popular</span>
                        <?php endif; ?>

                        <span class="activity-badge">
                            🎯 <?php echo $city['activity_count']; ?> activities
                        </span>
                    </div>

                    <div class="city-body">
                        <div class="city-header">
                            <h3 class="city-name"><?php echo htmlspecialchars($city['name']); ?></h3>
                            <span class="city-country">
                                📍 <?php echo htmlspecialchars($city['country']); ?>
                            </span>
                        </div>
                        <p class="city-desc"><?php echo htmlspecialchars($city['description']); ?></p>
                        <div class="city-footer">
                            <span class="activities-info">
                                🎯 <?php echo $city['activity_count']; ?> things to do
                            </span>
                            <span class="btn-explore">Explore →</span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>

            <div class="empty-state" id="empty-state" style="display:none;">
                <div class="empty-icon">🔍</div>
                <p>No cities found matching your search.</p>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
    </footer>
    <script src="assets/js/main.js"></script>
    <script>
        // Region → country mapping
        const regionMap = {
            asia:       ['japan','thailand','indonesia','china','india','singapore','malaysia','vietnam','south korea'],
            europe:     ['france','italy','spain','united kingdom','germany','netherlands','portugal','greece','switzerland'],
            americas:   ['usa','canada','brazil','mexico','argentina','colombia','peru','chile'],
            oceania:    ['australia','new zealand','fiji'],
            middleeast: ['uae','saudi arabia','qatar','jordan','egypt','turkey','israel'],
        };

        let activeFilter = 'all';
        let searchQuery  = '';

        function filterCities() {
            searchQuery = document.getElementById('city-search-input').value.toLowerCase().trim();
            applyFilters();
        }

        function setFilter(filter, btn) {
            activeFilter = filter;
            document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            applyFilters();
        }

        function applyFilters() {
            const cards   = document.querySelectorAll('.city-card');
            let visible   = 0;

            cards.forEach(card => {
                const name    = card.dataset.name;
                const country = card.dataset.country;
                const popular = card.dataset.popular === '1';

                // text search
                const matchSearch = !searchQuery ||
                    name.includes(searchQuery) ||
                    country.includes(searchQuery);

                // region / popular filter
                let matchFilter = true;
                if (activeFilter === 'popular') {
                    matchFilter = popular;
                } else if (activeFilter !== 'all') {
                    const countries = regionMap[activeFilter] || [];
                    matchFilter = countries.some(c => country.includes(c));
                }

                const show = matchSearch && matchFilter;
                card.style.display = show ? '' : 'none';
                if (show) visible++;
            });

            document.getElementById('result-count').textContent = visible;
            document.getElementById('empty-state').style.display = visible === 0 ? 'block' : 'none';
        }
    </script>
</body>
</html>
