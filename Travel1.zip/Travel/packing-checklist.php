<?php
$page_title = 'Packing Checklist';
require_once 'includes/header.php';
requireLogin();
?>

<h1>Packing Checklist</h1>
<p>Manage your packing checklist here.</p>

<?php require_once 'includes/footer.php'; ?>
