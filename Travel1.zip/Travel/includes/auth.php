<?php
// Authentication functions
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        // Works from any subfolder
        $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/admin');
        header('Location: /Travel/login.php');
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /Travel/dashboard.php');
        exit();
    }
}

function logout() {
    session_destroy();
    header('Location: /Travel/login.php');
    exit();
}
?>
