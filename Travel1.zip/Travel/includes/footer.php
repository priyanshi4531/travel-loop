    </main>
    <footer>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
    </footer>
    <script src="assets/js/main.js"></script>
</body>
</html>
