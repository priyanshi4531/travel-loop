*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    background:
        linear-gradient(160deg, rgba(8,15,45,0.78) 0%, rgba(30,10,60,0.82) 100%),
        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
        center / cover no-repeat fixed;
}

/* ── Card ── */
.auth-card {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 440px;
    background: rgba(12, 18, 52, 0.85);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 22px;
    padding: 44px 40px 36px;
    box-shadow: 0 28px 70px rgba(0,0,0,0.55);
}

/* ── Brand ── */
.auth-brand { text-align: center; margin-bottom: 30px; }
.brand-icon {
    font-size: 50px;
    display: block;
    margin-bottom: 10px;
    filter: drop-shadow(0 3px 10px rgba(0,0,0,0.5));
}
.auth-brand h1 {
    color: #ffffff;
    font-size: 26px;
    font-weight: 800;
    margin: 0 0 6px;
    text-shadow: 0 2px 10px rgba(0,0,0,0.4);
}
.auth-brand p {
    color: rgba(255,255,255,0.55);
    font-size: 14px;
}

/* ── Alert ── */
.alert {
    padding: 12px 15px;
    border-radius: 9px;
    font-size: 13px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 500;
}
.alert-error   { background: rgba(239,68,68,0.18);  color: #fca5a5; border-left: 3px solid #ef4444; }
.alert-success { background: rgba(34,197,94,0.18);  color: #86efac; border-left: 3px solid #22c55e; }

/* ── Form group ── */
.form-group { margin-bottom: 18px; }

.form-group label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #e2e8f0;
    margin-bottom: 8px;
    letter-spacing: 0.3px;
}

.form-group input,
.form-group textarea,
.form-group select {
    width: 100%;
    padding: 13px 16px;
    background: rgba(255,255,255,0.08);
    border: 1.5px solid rgba(255,255,255,0.18);
    border-radius: 10px;
    font-size: 14px;
    font-family: inherit;
    color: #f1f5f9;
    transition: border-color 0.25s, background 0.25s, box-shadow 0.25s;
}
.form-group textarea {
    resize: vertical;
    min-height: 80px;
    padding-top: 12px;
}
.form-group input::placeholder,
.form-group textarea::placeholder {
    color: rgba(255,255,255,0.32);
}
.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #818cf8;
    background: rgba(255,255,255,0.13);
    box-shadow: 0 0 0 3px rgba(129,140,248,0.22);
    color: #ffffff;
}

/* ── Password wrap ── */
.pw-wrap { position: relative; }
.pw-wrap input { padding-right: 46px; }
.toggle-pw {
    position: absolute;
    right: 13px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    font-size: 16px;
    color: rgba(255,255,255,0.40);
    padding: 0;
    line-height: 1;
}
.toggle-pw:hover { color: rgba(255,255,255,0.85); }

/* ── Form row (2 cols) ── */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}

/* ── Submit button ── */
.btn-auth {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #7c9ef5 0%, #9b6fd4 100%);
    color: #ffffff;
    border: none;
    border-radius: 11px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    letter-spacing: 0.4px;
    transition: transform 0.2s, box-shadow 0.2s;
    margin-top: 4px;
    box-shadow: 0 4px 20px rgba(124,158,245,0.45);
}
.btn-auth:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 28px rgba(124,158,245,0.60);
}
.btn-auth:active { transform: translateY(0); }

/* ── Divider ── */
.divider {
    display: flex;
    align-items: center;
    text-align: center;
    margin: 22px 0 18px;
    color: rgba(255,255,255,0.25);
    font-size: 12px;
}
.divider::before, .divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(255,255,255,0.12);
}
.divider span { padding: 0 12px; }

/* ── Footer link ── */
.auth-footer {
    text-align: center;
    font-size: 14px;
    color: rgba(255,255,255,0.55);
}
.auth-footer a {
    color: #a78bfa;
    font-weight: 700;
    text-decoration: none;
}
.auth-footer a:hover { color: #ffffff; text-decoration: underline; }

/* ── Avatar picker ── */
.avatar-picker {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 22px;
}
.avatar-ring {
    position: relative;
    width: 88px;
    height: 88px;
    cursor: pointer;
}
.avatar-ring img {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid rgba(255,255,255,0.30);
    box-shadow: 0 4px 18px rgba(0,0,0,0.40);
    display: block;
}
.avatar-overlay {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    background: rgba(0,0,0,0.45);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    opacity: 0;
    transition: opacity 0.2s;
}
.avatar-ring:hover .avatar-overlay { opacity: 1; }
.avatar-ring input[type="file"] {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
    border-radius: 50%;
}
.avatar-hint {
    margin-top: 8px;
    font-size: 12px;
    color: rgba(255,255,255,0.40);
}

/* ── Required star ── */
.req { color: #f87171; margin-left: 2px; }

/* ── Responsive ── */
@media (max-width: 500px) {
    .auth-card { padding: 34px 22px 28px; border-radius: 0; }
    .form-row  { grid-template-columns: 1fr; }
}
