<?php
$page_title = 'Search Activities';
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

// Pre-filter by city if passed from city-search
$filter_city_id = isset($_GET['city_id']) ? (int)$_GET['city_id'] : 0;

// Fetch all cities for the filter dropdown
$cities_stmt = $conn->prepare("SELECT id, name, country FROM cities ORDER BY name ASC");
$cities_stmt->execute();
$all_cities = $cities_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$cities_stmt->close();

// Fetch activities — filter by city if provided
if ($filter_city_id > 0) {
    $act_stmt = $conn->prepare(
        "SELECT a.*, c.name AS city_name, c.country
         FROM activities a
         JOIN cities c ON a.city_id = c.id
         WHERE a.city_id = ?
         ORDER BY a.category, a.name"
    );
    $act_stmt->bind_param("i", $filter_city_id);
} else {
    $act_stmt = $conn->prepare(
        "SELECT a.*, c.name AS city_name, c.country
         FROM activities a
         JOIN cities c ON a.city_id = c.id
         ORDER BY c.name, a.category, a.name"
    );
}
$act_stmt->execute();
$activities_raw = $act_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$act_stmt->close();

// Category icons & labels
$cat_icons = [
    'sightseeing' => '🏛️',
    'food'        => '🍜',
    'adventure'   => '🧗',
    'culture'     => '🎭',
    'shopping'    => '🛍️',
    'nightlife'   => '🌙',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family:'Inter','Segoe UI',sans-serif;
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* ── Hero ── */
        .page-hero {
            background:
                linear-gradient(135deg, rgba(8,15,50,0.80) 0%, rgba(25,8,60,0.86) 100%),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center/cover no-repeat;
            padding: 52px 40px 44px;
            text-align: center;
            margin-bottom: 36px;
            border-radius: 14px;
            position: relative;
            overflow: hidden;
        }
        .page-hero::before {
            content:''; position:absolute; inset:0;
            background: radial-gradient(ellipse 60% 50% at 50% 50%, rgba(102,126,234,0.20) 0%, transparent 70%);
        }
        .page-hero h1 { color:#fff; font-size:32px; font-weight:900; margin:0 0 8px; position:relative; }
        .page-hero p  { color:rgba(255,255,255,0.65); font-size:15px; margin:0 0 26px; position:relative; }

        /* ── Search + filters ── */
        .search-row {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            max-width: 800px;
            margin: 0 auto;
            position: relative;
        }
        .search-wrap { position:relative; flex:1; min-width:220px; }
        .search-wrap .s-icon { position:absolute; left:16px; top:50%; transform:translateY(-50%); font-size:16px; pointer-events:none; }
        #act-search {
            width:100%; padding:13px 16px 13px 46px;
            border-radius:10px; border:none; font-size:14px; font-family:inherit;
            background:rgba(255,255,255,0.95); color:#1a1a2e;
            box-shadow:0 4px 20px rgba(0,0,0,0.20); outline:none;
        }
        #act-search::placeholder { color:#9ca3af; }
        #act-search:focus { box-shadow:0 4px 20px rgba(102,126,234,0.35); }

        .filter-select {
            padding:13px 16px; border-radius:10px; border:none;
            font-size:14px; font-family:inherit;
            background:rgba(255,255,255,0.95); color:#1a1a2e;
            box-shadow:0 4px 20px rgba(0,0,0,0.20); outline:none; cursor:pointer;
            min-width:160px;
        }

        /* ── Toolbar ── */
        .toolbar {
            display:flex; align-items:center; justify-content:space-between;
            flex-wrap:wrap; gap:12px; margin-bottom:24px;
        }
        .result-count { font-size:14px; color:#666; font-weight:500; }
        .result-count span { color:#667eea; font-weight:700; }

        /* Category pills */
        .cat-pills { display:flex; gap:8px; flex-wrap:wrap; }
        .cat-pill {
            padding:6px 14px; border-radius:20px; font-size:13px; font-weight:600;
            cursor:pointer; border:1.5px solid #dde1ec; background:#fff; color:#555;
            transition:all 0.2s;
        }
        .cat-pill:hover  { border-color:#667eea; color:#667eea; }
        .cat-pill.active { background:#667eea; color:#fff; border-color:#667eea; }

        /* ── Activities grid ── */
        .activities-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill, minmax(300px,1fr));
            gap:22px;
        }

        /* ── Activity card ── */
        .act-card {
            background:#fff; border-radius:14px;
            box-shadow:0 2px 10px rgba(0,0,0,0.08);
            overflow:hidden; display:flex; flex-direction:column;
            transition:transform 0.25s, box-shadow 0.25s;
        }
        .act-card:hover { transform:translateY(-5px); box-shadow:0 10px 28px rgba(0,0,0,0.13); }

        .act-img-wrap { position:relative; height:180px; overflow:hidden; }
        .act-img-wrap img {
            width:100%; height:100%; object-fit:cover; display:block;
            transition:transform 0.4s;
        }
        .act-card:hover .act-img-wrap img { transform:scale(1.07); }

        .cat-badge {
            position:absolute; top:10px; left:10px;
            background:rgba(0,0,0,0.55); backdrop-filter:blur(6px);
            color:#fff; font-size:11px; font-weight:700;
            padding:4px 10px; border-radius:20px;
            text-transform:capitalize;
        }
        .cost-badge {
            position:absolute; top:10px; right:10px;
            background:linear-gradient(135deg,#667eea,#764ba2);
            color:#fff; font-size:12px; font-weight:700;
            padding:4px 10px; border-radius:20px;
        }

        .act-body { padding:18px 20px 20px; flex:1; display:flex; flex-direction:column; }
        .act-name { font-size:16px; font-weight:800; color:#1a1a2e; margin:0 0 6px; }
        .act-location {
            font-size:12px; color:#667eea; font-weight:600;
            margin-bottom:10px; display:flex; align-items:center; gap:4px;
        }
        .act-desc {
            font-size:13px; color:#666; line-height:1.6; flex:1;
            display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden;
            margin-bottom:14px;
        }
        .act-meta {
            display:flex; align-items:center; justify-content:space-between;
            padding-top:12px; border-top:1px solid #f0f0f0;
        }
        .act-duration { font-size:12px; color:#888; display:flex; align-items:center; gap:4px; }
        .act-cost-label { font-size:13px; font-weight:700; color:#667eea; }

        /* ── Empty state ── */
        .empty-state {
            grid-column:1/-1; text-align:center; padding:60px 20px;
            background:#fff; border-radius:14px;
            box-shadow:0 2px 10px rgba(0,0,0,0.07);
        }
        .empty-state .ei { font-size:56px; margin-bottom:14px; }
        .empty-state p { color:#aaa; font-size:15px; }

        /* ── Nav ── */
        header { background:#0f172a; position:sticky; top:0; z-index:100; box-shadow:0 2px 20px rgba(0,0,0,0.3); }
        header nav { display:flex; justify-content:space-between; align-items:center; padding:0 40px; height:64px; }
        .logo { font-size:20px; font-weight:800; color:#fff; }
        .nav-menu { display:flex; list-style:none; gap:6px; align-items:center; }
        .nav-menu a { color:rgba(255,255,255,0.70); text-decoration:none; font-size:14px; font-weight:500; padding:8px 14px; border-radius:8px; transition:all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color:#fff; background:rgba(255,255,255,0.10); }

        main { max-width:1200px; margin:0 auto; padding:32px 24px 60px; }
        footer { background:#0f172a; color:rgba(255,255,255,0.40); text-align:center; padding:22px; font-size:13px; margin-top:40px; }

        @media(max-width:600px) {
            .page-hero { padding:36px 20px; }
            .page-hero h1 { font-size:24px; }
            header nav { padding:0 16px; }
            .activities-grid { grid-template-columns:1fr; }
        }
    </style>
</head>
<body>

<header>
    <nav>
        <div class="logo">✈️ Travel Planner</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php" class="active">Activities</a></li>
            <li><a href="budget.php">Budget</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<main>
    <!-- Hero -->
    <div class="page-hero">
        <h1>🎯 Discover Activities</h1>
        <p>Find the best things to do across <?php echo count($all_cities); ?> destinations worldwide</p>
        <div class="search-row">
            <div class="search-wrap">
                <span class="s-icon">🔍</span>
                <input type="text" id="act-search" placeholder="Search activities, cities…" oninput="filterActivities()">
            </div>
            <select class="filter-select" id="city-filter" onchange="filterActivities()">
                <option value="">🌍 All Cities</option>
                <?php foreach ($all_cities as $c): ?>
                    <option value="<?php echo (int)$c['id']; ?>"
                        <?php echo $filter_city_id === (int)$c['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($c['name'] . ', ' . $c['country']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <!-- Toolbar -->
    <div class="toolbar">
        <div class="result-count">
            Showing <span id="act-count"><?php echo count($activities_raw); ?></span> activities
        </div>
        <div class="cat-pills">
            <button class="cat-pill active" onclick="setCat('all',this)">🌐 All</button>
            <button class="cat-pill" onclick="setCat('sightseeing',this)">🏛️ Sightseeing</button>
            <button class="cat-pill" onclick="setCat('food',this)">🍜 Food</button>
            <button class="cat-pill" onclick="setCat('adventure',this)">🧗 Adventure</button>
            <button class="cat-pill" onclick="setCat('culture',this)">🎭 Culture</button>
            <button class="cat-pill" onclick="setCat('shopping',this)">🛍️ Shopping</button>
            <button class="cat-pill" onclick="setCat('nightlife',this)">🌙 Nightlife</button>
        </div>
    </div>

    <!-- Grid -->
    <div class="activities-grid" id="act-grid">
        <?php foreach ($activities_raw as $act):
            $icon = $cat_icons[$act['category']] ?? '🎯';
            $cost_label = $act['cost'] > 0 ? '$' . number_format($act['cost'], 0) : 'Free';
        ?>
        <div class="act-card"
             data-name="<?php echo strtolower(htmlspecialchars($act['name'])); ?>"
             data-city="<?php echo strtolower(htmlspecialchars($act['city_name'])); ?>"
             data-country="<?php echo strtolower(htmlspecialchars($act['country'])); ?>"
             data-category="<?php echo htmlspecialchars($act['category']); ?>"
             data-cityid="<?php echo (int)$act['city_id']; ?>">

            <div class="act-img-wrap">
                <?php if (!empty($act['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($act['image_url']); ?>"
                         alt="<?php echo htmlspecialchars($act['name']); ?>"
                         loading="lazy"
                         onerror="this.src='https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=60'">
                <?php else: ?>
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:48px;"><?php echo $icon; ?></div>
                <?php endif; ?>
                <span class="cat-badge"><?php echo $icon . ' ' . ucfirst($act['category']); ?></span>
                <span class="cost-badge"><?php echo $cost_label; ?></span>
            </div>

            <div class="act-body">
                <h3 class="act-name"><?php echo htmlspecialchars($act['name']); ?></h3>
                <div class="act-location">
                    📍 <?php echo htmlspecialchars($act['city_name'] . ', ' . $act['country']); ?>
                </div>
                <p class="act-desc"><?php echo htmlspecialchars($act['description']); ?></p>
                <div class="act-meta">
                    <span class="act-duration">⏱️ <?php echo number_format($act['duration_hours'], 1); ?> hrs</span>
                    <span class="act-cost-label"><?php echo $cost_label; ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="empty-state" id="act-empty" style="display:none;">
            <div class="ei">🔍</div>
            <p>No activities found. Try a different search or filter.</p>
        </div>
    </div>
</main>

<footer><p>&copy; 2026 Travel Planner. All rights reserved.</p></footer>
<script>
    let activeCat = 'all';

    function filterActivities() {
        const q      = document.getElementById('act-search').value.toLowerCase().trim();
        const cityId = document.getElementById('city-filter').value;
        const cards  = document.querySelectorAll('.act-card');
        let visible  = 0;

        cards.forEach(card => {
            const matchSearch = !q || card.dataset.name.includes(q) || card.dataset.city.includes(q) || card.dataset.country.includes(q);
            const matchCat    = activeCat === 'all' || card.dataset.category === activeCat;
            const matchCity   = !cityId || card.dataset.cityid === cityId;
            const show = matchSearch && matchCat && matchCity;
            card.style.display = show ? '' : 'none';
            if (show) visible++;
        });

        document.getElementById('act-count').textContent = visible;
        document.getElementById('act-empty').style.display = visible === 0 ? 'block' : 'none';
    }

    function setCat(cat, btn) {
        activeCat = cat;
        document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        filterActivities();
    }

    // Apply city filter from URL on load
    window.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        const cid = urlParams.get('city_id');
        if (cid) {
            document.getElementById('city-filter').value = cid;
            filterActivities();
        }
    });
</script>
</body>
</html>
