<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Logged-in users go straight to dashboard
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

// Fetch a few popular cities for the showcase
$cities_stmt = $conn->prepare("SELECT name, country, image_url FROM cities WHERE popular = 1 ORDER BY id LIMIT 6");
$cities_stmt->execute();
$popular_cities = $cities_stmt->get_result();
$cities_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Planner – Plan Your Next Adventure</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --purple: #667eea;
            --violet: #764ba2;
            --dark:   #0d1117;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--dark);
            color: #f1f5f9;
            overflow-x: hidden;
        }

        /* ══════════════════════════════════════
           NAV
        ══════════════════════════════════════ */
        nav {
            position: fixed;
            top: 0; left: 0; right: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 60px;
            background: rgba(13,17,23,0.70);
            backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255,255,255,0.07);
            transition: background 0.3s;
        }
        .nav-logo {
            font-size: 20px;
            font-weight: 800;
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .nav-links { display: flex; align-items: center; gap: 28px; }
        .nav-links a {
            color: rgba(255,255,255,0.70);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: #fff; }
        .nav-btn {
            padding: 9px 22px;
            background: linear-gradient(135deg, var(--purple), var(--violet));
            color: #fff !important;
            border-radius: 8px;
            font-weight: 700 !important;
            font-size: 14px !important;
            box-shadow: 0 3px 14px rgba(102,126,234,0.40);
            transition: transform 0.2s, box-shadow 0.2s !important;
        }
        .nav-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102,126,234,0.55) !important;
        }

        /* ══════════════════════════════════════
           HERO
        ══════════════════════════════════════ */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 120px 24px 80px;
            position: relative;
            overflow: hidden;
            background:
                linear-gradient(160deg, rgba(8,12,40,0.80) 0%, rgba(25,8,55,0.85) 100%),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat;
        }

        /* animated particles */
        .hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 50% at 20% 30%, rgba(102,126,234,0.18) 0%, transparent 70%),
                radial-gradient(ellipse 50% 40% at 80% 70%, rgba(118,75,162,0.18) 0%, transparent 70%);
            pointer-events: none;
        }

        .hero-content { position: relative; z-index: 1; max-width: 780px; }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(102,126,234,0.18);
            border: 1px solid rgba(102,126,234,0.35);
            border-radius: 30px;
            padding: 7px 18px;
            font-size: 13px;
            color: #a5b4fc;
            font-weight: 600;
            margin-bottom: 28px;
            letter-spacing: 0.3px;
        }

        .hero h1 {
            font-size: clamp(38px, 6vw, 68px);
            font-weight: 900;
            line-height: 1.10;
            color: #ffffff;
            margin-bottom: 22px;
            text-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }
        .hero h1 span {
            background: linear-gradient(135deg, #a78bfa, #60a5fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero p {
            font-size: 18px;
            color: rgba(255,255,255,0.68);
            line-height: 1.7;
            max-width: 560px;
            margin: 0 auto 40px;
        }

        .hero-btns {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn-primary {
            padding: 15px 36px;
            background: linear-gradient(135deg, var(--purple), var(--violet));
            color: #fff;
            border-radius: 12px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 700;
            box-shadow: 0 6px 24px rgba(102,126,234,0.45);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 32px rgba(102,126,234,0.60);
        }
        .btn-outline {
            padding: 15px 36px;
            background: rgba(255,255,255,0.08);
            color: #fff;
            border: 1.5px solid rgba(255,255,255,0.25);
            border-radius: 12px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 600;
            backdrop-filter: blur(8px);
            transition: background 0.2s, border-color 0.2s;
        }
        .btn-outline:hover {
            background: rgba(255,255,255,0.14);
            border-color: rgba(255,255,255,0.45);
        }

        /* scroll indicator */
        .scroll-hint {
            position: absolute;
            bottom: 32px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            color: rgba(255,255,255,0.35);
            font-size: 12px;
            animation: bounce 2s ease-in-out infinite;
        }
        @keyframes bounce {
            0%,100% { transform: translateX(-50%) translateY(0); }
            50%      { transform: translateX(-50%) translateY(8px); }
        }

        /* ══════════════════════════════════════
           STATS BAR
        ══════════════════════════════════════ */
        .stats-bar {
            background: rgba(255,255,255,0.04);
            border-top: 1px solid rgba(255,255,255,0.07);
            border-bottom: 1px solid rgba(255,255,255,0.07);
            padding: 32px 60px;
            display: flex;
            justify-content: center;
            gap: 80px;
            flex-wrap: wrap;
        }
        .stat-item { text-align: center; }
        .stat-num {
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--purple), #60a5fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .stat-label { font-size: 13px; color: rgba(255,255,255,0.50); margin-top: 4px; }

        /* ══════════════════════════════════════
           FEATURES
        ══════════════════════════════════════ */
        section { padding: 90px 60px; }
        .section-label {
            text-align: center;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: #a78bfa;
            margin-bottom: 14px;
        }
        .section-title {
            text-align: center;
            font-size: clamp(26px, 4vw, 40px);
            font-weight: 800;
            color: #fff;
            margin-bottom: 14px;
        }
        .section-sub {
            text-align: center;
            font-size: 16px;
            color: rgba(255,255,255,0.50);
            max-width: 520px;
            margin: 0 auto 56px;
            line-height: 1.6;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 24px;
            max-width: 1100px;
            margin: 0 auto;
        }
        .feature-card {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 16px;
            padding: 32px 28px;
            transition: transform 0.25s, border-color 0.25s, background 0.25s;
        }
        .feature-card:hover {
            transform: translateY(-6px);
            border-color: rgba(102,126,234,0.40);
            background: rgba(102,126,234,0.07);
        }
        .feature-icon {
            font-size: 36px;
            margin-bottom: 16px;
            display: block;
        }
        .feature-card h3 {
            font-size: 18px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 10px;
        }
        .feature-card p {
            font-size: 14px;
            color: rgba(255,255,255,0.52);
            line-height: 1.65;
        }

        /* ══════════════════════════════════════
           DESTINATIONS
        ══════════════════════════════════════ */
        .destinations { background: rgba(255,255,255,0.02); }
        .dest-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            max-width: 1100px;
            margin: 0 auto;
        }
        .dest-card {
            position: relative;
            border-radius: 16px;
            overflow: hidden;
            height: 220px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .dest-card:hover { transform: scale(1.03); }
        .dest-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.4s;
        }
        .dest-card:hover img { transform: scale(1.08); }
        .dest-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.75) 0%, transparent 55%);
            display: flex;
            align-items: flex-end;
            padding: 20px;
        }
        .dest-info h3 { font-size: 18px; font-weight: 700; color: #fff; }
        .dest-info p  { font-size: 13px; color: rgba(255,255,255,0.70); }

        /* ══════════════════════════════════════
           HOW IT WORKS
        ══════════════════════════════════════ */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 32px;
            max-width: 900px;
            margin: 0 auto;
            text-align: center;
        }
        .step-num {
            width: 52px; height: 52px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--purple), var(--violet));
            color: #fff;
            font-size: 20px;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            box-shadow: 0 4px 18px rgba(102,126,234,0.40);
        }
        .step-title { font-size: 17px; font-weight: 700; color: #fff; margin-bottom: 8px; }
        .step-desc  { font-size: 14px; color: rgba(255,255,255,0.50); line-height: 1.6; }

        /* ══════════════════════════════════════
           CTA BANNER
        ══════════════════════════════════════ */
        .cta-section {
            padding: 90px 60px;
            text-align: center;
            background:
                linear-gradient(135deg, rgba(102,126,234,0.15) 0%, rgba(118,75,162,0.15) 100%),
                rgba(255,255,255,0.02);
            border-top: 1px solid rgba(255,255,255,0.07);
        }
        .cta-section h2 {
            font-size: clamp(28px, 4vw, 44px);
            font-weight: 900;
            color: #fff;
            margin-bottom: 16px;
        }
        .cta-section p {
            font-size: 17px;
            color: rgba(255,255,255,0.55);
            margin-bottom: 36px;
        }

        /* ══════════════════════════════════════
           FOOTER
        ══════════════════════════════════════ */
        footer {
            background: rgba(0,0,0,0.40);
            border-top: 1px solid rgba(255,255,255,0.07);
            padding: 32px 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 16px;
        }
        footer .logo { font-size: 16px; font-weight: 700; color: rgba(255,255,255,0.70); }
        footer p { font-size: 13px; color: rgba(255,255,255,0.35); }
        footer .footer-links { display: flex; gap: 20px; }
        footer .footer-links a {
            font-size: 13px;
            color: rgba(255,255,255,0.40);
            text-decoration: none;
            transition: color 0.2s;
        }
        footer .footer-links a:hover { color: rgba(255,255,255,0.80); }

        /* ══════════════════════════════════════
           RESPONSIVE
        ══════════════════════════════════════ */
        @media (max-width: 768px) {
            nav { padding: 16px 24px; }
            .nav-links .nav-hide { display: none; }
            section { padding: 60px 24px; }
            .stats-bar { padding: 28px 24px; gap: 40px; }
            .cta-section { padding: 60px 24px; }
            footer { padding: 28px 24px; flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>

    <!-- ══ NAV ══ -->
    <nav>
        <a href="index.php" class="nav-logo">✈️ Travel Planner</a>
        <div class="nav-links">
            <a href="#features" class="nav-hide">Features</a>
            <a href="#destinations" class="nav-hide">Destinations</a>
            <a href="login.php">Login</a>
            <a href="signup.php" class="nav-btn">Get Started</a>
        </div>
    </nav>

    <!-- ══ HERO ══ -->
    <section class="hero">
        <div class="hero-content">
            <div class="hero-badge">🌍 &nbsp;Your Smart Travel Companion</div>
            <h1>Plan Your Next<br><span>Dream Adventure</span></h1>
            <p>Build itineraries, track budgets, discover destinations, and share your journeys — all in one beautiful place.</p>
            <div class="hero-btns">
                <a href="signup.php" class="btn-primary">🚀 Start Planning Free</a>
                <a href="login.php"  class="btn-outline">Login to Dashboard</a>
            </div>
        </div>
        <div class="scroll-hint">
            <span>Scroll</span>
            <span style="font-size:18px;">↓</span>
        </div>
    </section>

    <!-- ══ STATS ══ -->
    <div class="stats-bar">
        <div class="stat-item">
            <div class="stat-num">10+</div>
            <div class="stat-label">Popular Destinations</div>
        </div>
        <div class="stat-item">
            <div class="stat-num">50+</div>
            <div class="stat-label">Activities Listed</div>
        </div>
        <div class="stat-item">
            <div class="stat-num">100%</div>
            <div class="stat-label">Free to Use</div>
        </div>
        <div class="stat-item">
            <div class="stat-num">∞</div>
            <div class="stat-label">Trips You Can Plan</div>
        </div>
    </div>

    <!-- ══ FEATURES ══ -->
    <section id="features">
        <div class="section-label">What We Offer</div>
        <h2 class="section-title">Everything You Need to Travel Smarter</h2>
        <p class="section-sub">From planning to packing, we've got every step of your journey covered.</p>

        <div class="features-grid">
            <div class="feature-card">
                <span class="feature-icon">🗺️</span>
                <h3>Trip Planning</h3>
                <p>Create detailed trips with destinations, dates, cover photos and status tracking — all in one place.</p>
            </div>
            <div class="feature-card">
                <span class="feature-icon">📅</span>
                <h3>Itinerary Builder</h3>
                <p>Build day-by-day itineraries with activities, timings and notes for every stop on your journey.</p>
            </div>
            <div class="feature-card">
                <span class="feature-icon">💰</span>
                <h3>Budget Tracker</h3>
                <p>Set a budget, log expenses by category, and see exactly where your money is going in real time.</p>
            </div>
            <div class="feature-card">
                <span class="feature-icon">🧳</span>
                <h3>Packing Checklist</h3>
                <p>Never forget anything again. Build smart packing lists by category and check items off as you go.</p>
            </div>
            <div class="feature-card">
                <span class="feature-icon">🏙️</span>
                <h3>City Discovery</h3>
                <p>Explore popular cities around the world and discover top-rated activities, food spots and sights.</p>
            </div>
            <div class="feature-card">
                <span class="feature-icon">🔗</span>
                <h3>Share Itineraries</h3>
                <p>Share your trip plans with friends and family via a unique link — no account needed to view.</p>
            </div>
        </div>
    </section>

    <!-- ══ DESTINATIONS ══ -->
    <section id="destinations" class="destinations">
        <div class="section-label">Explore</div>
        <h2 class="section-title">Popular Destinations</h2>
        <p class="section-sub">Get inspired by some of the world's most loved travel destinations.</p>

        <div class="dest-grid">
            <?php while ($city = $popular_cities->fetch_assoc()): ?>
                <div class="dest-card">
                    <img src="<?php echo htmlspecialchars($city['image_url']); ?>"
                         alt="<?php echo htmlspecialchars($city['name']); ?>"
                         loading="lazy">
                    <div class="dest-overlay">
                        <div class="dest-info">
                            <h3><?php echo htmlspecialchars($city['name']); ?></h3>
                            <p><?php echo htmlspecialchars($city['country']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- ══ HOW IT WORKS ══ -->
    <section>
        <div class="section-label">Simple Process</div>
        <h2 class="section-title">How It Works</h2>
        <p class="section-sub">Get started in minutes and be planning your dream trip today.</p>

        <div class="steps-grid">
            <div>
                <div class="step-num">1</div>
                <div class="step-title">Create Account</div>
                <div class="step-desc">Sign up for free in under a minute. No credit card required.</div>
            </div>
            <div>
                <div class="step-num">2</div>
                <div class="step-title">Plan Your Trip</div>
                <div class="step-desc">Add destinations, set dates, build your itinerary and set a budget.</div>
            </div>
            <div>
                <div class="step-num">3</div>
                <div class="step-title">Discover Activities</div>
                <div class="step-desc">Browse curated activities and add them to your day-by-day plan.</div>
            </div>
            <div>
                <div class="step-num">4</div>
                <div class="step-title">Travel & Share</div>
                <div class="step-desc">Hit the road and share your itinerary with anyone via a link.</div>
            </div>
        </div>
    </section>

    <!-- ══ CTA ══ -->
    <div class="cta-section">
        <h2>Ready to Start Your Adventure?</h2>
        <p>Join thousands of travellers already planning smarter with Travel Planner.</p>
        <a href="signup.php" class="btn-primary" style="font-size:17px;padding:16px 44px;">
            🚀 Create Free Account
        </a>
    </div>

    <!-- ══ FOOTER ══ -->
    <footer>
        <div class="logo">✈️ Travel Planner</div>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
        <div class="footer-links">
            <a href="login.php">Login</a>
            <a href="signup.php">Sign Up</a>
            <a href="admin-login.php">Admin</a>
        </div>
    </footer>

</body>
</html>

