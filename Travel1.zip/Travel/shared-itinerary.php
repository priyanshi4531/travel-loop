<?php
$page_title = 'Shared Itinerary';
require_once 'includes/header.php';
?>

<h1>Shared Itinerary</h1>
<p>View shared itinerary here.</p>

<?php require_once 'includes/footer.php'; ?>
