<?php
$page_title = 'Edit Trip';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$trip_id = (int)($_GET['id'] ?? 0);

if (!$trip_id) { header('Location: my_trips.php'); exit(); }

// Fetch trip — must belong to user
$stmt = $conn->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $trip_id, $user_id);
$stmt->execute();
$trip = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$trip) { header('Location: my_trips.php'); exit(); }

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = sanitizeInput($_POST['name']        ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $start_date  = sanitizeInput($_POST['start_date']  ?? '');
    $end_date    = sanitizeInput($_POST['end_date']    ?? '');
    $status      = sanitizeInput($_POST['status']      ?? 'draft');
    $budget      = floatval($_POST['budget']           ?? 0);
    $currency    = sanitizeInput($_POST['currency']    ?? 'USD');

    $allowed_statuses  = ['draft','published','shared'];
    $allowed_currencies= ['USD','EUR','GBP','PKR','AED','JPY','AUD','CAD','INR','SGD'];

    if (empty($name)) {
        $error = 'Trip name is required.';
    } elseif (!empty($start_date) && !empty($end_date) && $end_date < $start_date) {
        $error = 'End date cannot be before start date.';
    } elseif (!in_array($status, $allowed_statuses) || !in_array($currency, $allowed_currencies)) {
        $error = 'Invalid status or currency.';
    } else {
        // Handle cover photo
        $cover_photo = $trip['cover_photo'];
        if (!empty($_FILES['cover_photo']['name'])) {
            $file     = $_FILES['cover_photo'];
            $allowed  = ['image/jpeg','image/png','image/gif','image/webp'];
            $finfo    = finfo_open(FILEINFO_MIME_TYPE);
            $mime     = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            if (!in_array($mime, $allowed)) {
                $error = 'Cover photo must be JPEG, PNG, GIF or WebP.';
            } elseif ($file['size'] > 5 * 1024 * 1024) {
                $error = 'Cover photo must be smaller than 5 MB.';
            } else {
                $ext         = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $new_photo   = 'trip_' . $user_id . '_' . time() . '.' . $ext;
                $upload_dir  = __DIR__ . '/assets/uploads/';
                if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_photo)) {
                    // Delete old photo
                    if (!empty($trip['cover_photo']) && file_exists($upload_dir . $trip['cover_photo'])) {
                        unlink($upload_dir . $trip['cover_photo']);
                    }
                    $cover_photo = $new_photo;
                } else {
                    $error = 'Failed to upload photo.';
                }
            }
        }

        if (empty($error)) {
            $start_val = !empty($start_date) ? $start_date : null;
            $end_val   = !empty($end_date)   ? $end_date   : null;
            $upd = $conn->prepare(
                "UPDATE trips SET name=?, description=?, cover_photo=?, start_date=?, end_date=?, status=?, budget=?, currency=? WHERE id=? AND user_id=?"
            );
            $upd->bind_param("ssssssdsii", $name, $description, $cover_photo, $start_val, $end_val, $status, $budget, $currency, $trip_id, $user_id);
            if ($upd->execute()) {
                $success = 'Trip updated successfully!';
                // Refresh trip data
                $stmt2 = $conn->prepare("SELECT * FROM trips WHERE id = ?");
                $stmt2->bind_param("i", $trip_id); $stmt2->execute();
                $trip = $stmt2->get_result()->fetch_assoc(); $stmt2->close();
            } else {
                $error = 'Failed to update trip.';
            }
            $upd->close();
        }
    }
}

$currencies = ['USD'=>'🇺🇸 USD','EUR'=>'🇪🇺 EUR','GBP'=>'🇬🇧 GBP','PKR'=>'🇵🇰 PKR','AED'=>'🇦🇪 AED','JPY'=>'🇯🇵 JPY','AUD'=>'🇦🇺 AUD','CAD'=>'🇨🇦 CAD','INR'=>'🇮🇳 INR','SGD'=>'🇸🇬 SGD'];
$avatar_src = !empty($trip['cover_photo']) && file_exists(__DIR__ . '/assets/uploads/' . $trip['cover_photo'])
    ? 'assets/uploads/' . htmlspecialchars($trip['cover_photo']) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Trip – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Inter', 'Segoe UI', sans-serif; color: #1a1a2e; min-height: 100vh;
            background: linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat fixed; }
        header { background: #0f172a; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 20px rgba(0,0,0,0.3); }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2) !important; color: #fff !important; }

        .hero { background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                    url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 48px 40px 40px; }
        .hero-inner { max-width: 900px; margin: 0 auto; }
        .breadcrumb { font-size: 13px; color: rgba(255,255,255,0.50); margin-bottom: 12px; }
        .breadcrumb a { color: rgba(255,255,255,0.50); text-decoration: none; }
        .breadcrumb a:hover { color: #fff; }
        .hero h1 { font-size: 30px; font-weight: 900; color: #fff; text-shadow: 0 2px 12px rgba(0,0,0,0.4); }

        main { max-width: 900px; margin: 0 auto; padding: 36px 24px 70px; }

        .alert { padding: 12px 18px; border-radius: 9px; font-size: 14px; margin-bottom: 24px; font-weight: 500; }
        .alert-success { background: rgba(34,197,94,0.18); color: #86efac; border-left: 3px solid #22c55e; }
        .alert-error   { background: rgba(239,68,68,0.18); color: #fca5a5; border-left: 3px solid #ef4444; }

        .form-card { background: rgba(255,255,255,0.97); border-radius: 16px; box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; margin-bottom: 24px; }
        .form-card-header { padding: 18px 28px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; gap: 10px; }
        .form-card-header h3 { font-size: 16px; font-weight: 800; color: #1a1a2e; }
        .form-body { padding: 24px 28px; }
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-group label { display: block; font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .form-group input,
        .form-group select,
        .form-group textarea { width: 100%; padding: 11px 14px; border: 1.5px solid #e5e7eb; border-radius: 9px; font-size: 14px; font-family: inherit; color: #1a1a2e; background: #fafbff; transition: border-color 0.2s; }
        .form-group textarea { resize: vertical; min-height: 110px; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #667eea; background: #fff; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }

        /* Cover photo */
        .photo-preview { width: 100%; height: 200px; object-fit: cover; border-radius: 10px; margin-bottom: 12px; display: block; }
        .photo-placeholder { width: 100%; height: 200px; background: linear-gradient(135deg,#667eea,#764ba2); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 48px; margin-bottom: 12px; }
        .upload-area { border: 2px dashed #c5cae9; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; background: #fafbff; position: relative; transition: border-color 0.2s, background 0.2s; }
        .upload-area:hover { border-color: #667eea; background: #f0f3ff; }
        .upload-area input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
        .upload-area p { font-size: 13px; color: #888; }

        /* Status options */
        .status-options { display: flex; gap: 12px; flex-wrap: wrap; }
        .status-opt { flex: 1; min-width: 140px; padding: 14px; border: 1.5px solid #e5e7eb; border-radius: 10px; cursor: pointer; transition: all 0.2s; }
        .status-opt:hover { border-color: #667eea; background: #f8f9ff; }
        .status-opt input[type="radio"] { display: none; }
        .status-opt.selected { border-color: #667eea; background: #f0f3ff; }
        .status-opt-label { font-size: 14px; font-weight: 700; color: #1a1a2e; }
        .status-opt-desc  { font-size: 12px; color: #888; margin-top: 3px; }

        /* Buttons */
        .btn-row { display: flex; gap: 12px; align-items: center; }
        .btn-submit { padding: 13px 32px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; cursor: pointer; transition: opacity 0.2s, transform 0.15s; box-shadow: 0 4px 16px rgba(102,126,234,0.40); }
        .btn-submit:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn-cancel { padding: 13px 24px; background: #f3f4f6; color: #555; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; text-decoration: none; transition: background 0.2s; }
        .btn-cancel:hover { background: #e5e7eb; }

        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 22px; font-size: 13px; }
        @media (max-width: 600px) { header nav { padding: 0 16px; } .hero { padding: 36px 20px; } main { padding: 24px 16px 50px; } .form-row, .form-row-3 { grid-template-columns: 1fr; } .form-body { padding: 20px; } }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<div class="hero">
    <div class="hero-inner">
        <div class="breadcrumb">
            <a href="dashboard.php">Dashboard</a> &nbsp;/&nbsp;
            <a href="my_trips.php">My Trips</a> &nbsp;/&nbsp;
            <a href="trip-detail.php?id=<?php echo $trip_id; ?>"><?php echo htmlspecialchars($trip['name']); ?></a> &nbsp;/&nbsp;
            Edit
        </div>
        <h1>✏️ Edit Trip</h1>
    </div>
</div>

<main>
    <?php if ($error): ?>
        <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success">✅ <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data" novalidate>

        <!-- Trip Details -->
        <div class="form-card">
            <div class="form-card-header"><h3>📋 Trip Details</h3></div>
            <div class="form-body">
                <div class="form-group">
                    <label>Trip Name *</label>
                    <input type="text" name="name" required maxlength="200"
                           value="<?php echo htmlspecialchars($trip['name']); ?>">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" placeholder="What's this trip about?"><?php echo htmlspecialchars($trip['description'] ?? ''); ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" name="start_date" value="<?php echo htmlspecialchars($trip['start_date'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" name="end_date" value="<?php echo htmlspecialchars($trip['end_date'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Budget -->
        <div class="form-card">
            <div class="form-card-header"><h3>💰 Budget</h3></div>
            <div class="form-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Total Budget</label>
                        <input type="number" name="budget" min="0" step="0.01" placeholder="0.00"
                               value="<?php echo htmlspecialchars($trip['budget'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Currency</label>
                        <select name="currency">
                            <?php foreach ($currencies as $code => $label): ?>
                                <option value="<?php echo $code; ?>" <?php echo ($trip['currency'] ?? 'USD') === $code ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cover Photo -->
        <div class="form-card">
            <div class="form-card-header"><h3>🖼️ Cover Photo</h3></div>
            <div class="form-body">
                <?php if ($avatar_src): ?>
                    <img src="<?php echo $avatar_src; ?>" alt="Cover" class="photo-preview" id="photo-preview">
                <?php else: ?>
                    <div class="photo-placeholder" id="photo-placeholder">🌍</div>
                    <img src="" alt="Preview" class="photo-preview" id="photo-preview" style="display:none;">
                <?php endif; ?>
                <div class="upload-area">
                    <input type="file" name="cover_photo" accept="image/jpeg,image/png,image/gif,image/webp"
                           onchange="previewPhoto(this)">
                    <p>📷 Click to change cover photo &nbsp;·&nbsp; JPEG, PNG, GIF or WebP &nbsp;·&nbsp; Max 5 MB</p>
                </div>
            </div>
        </div>

        <!-- Status -->
        <div class="form-card">
            <div class="form-card-header"><h3>📌 Status</h3></div>
            <div class="form-body">
                <div class="status-options" id="status-opts">
                    <?php
                    $statuses = ['draft'=>['🗒️','Draft','Work in progress, only visible to you.'],
                                 'published'=>['✅','Published','Finalized and saved to your profile.'],
                                 'shared'=>['🔗','Shared','Anyone with the link can view it.']];
                    foreach ($statuses as $val => [$icon, $lbl, $desc]):
                        $sel = ($trip['status'] === $val) ? ' selected' : '';
                    ?>
                    <label class="status-opt<?php echo $sel; ?>">
                        <input type="radio" name="status" value="<?php echo $val; ?>" <?php echo $sel ? 'checked' : ''; ?>>
                        <div class="status-opt-label"><?php echo $icon . ' ' . $lbl; ?></div>
                        <div class="status-opt-desc"><?php echo $desc; ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="btn-row">
            <button type="submit" class="btn-submit">💾 Save Changes</button>
            <a href="trip-detail.php?id=<?php echo $trip_id; ?>" class="btn-cancel">Cancel</a>
        </div>

    </form>
</main>

<footer><p>© 2026 Travel Planner. All rights reserved.</p></footer>
<script>
function previewPhoto(input) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        const img = document.getElementById('photo-preview');
        const ph  = document.getElementById('photo-placeholder');
        img.src = e.target.result;
        img.style.display = 'block';
        if (ph) ph.style.display = 'none';
    };
    reader.readAsDataURL(input.files[0]);
}
document.querySelectorAll('.status-opt input[type="radio"]').forEach(r => {
    r.addEventListener('change', () => {
        document.querySelectorAll('.status-opt').forEach(o => o.classList.remove('selected'));
        r.closest('.status-opt').classList.add('selected');
    });
});
</script>
</body>
</html>
