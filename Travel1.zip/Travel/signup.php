<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name            = sanitizeInput($_POST['name']            ?? '');
    $email           = sanitizeInput($_POST['email']           ?? '');
    $city            = sanitizeInput($_POST['city']            ?? '');
    $country         = sanitizeInput($_POST['country']         ?? '');
    $additional_info = sanitizeInput($_POST['additional_info'] ?? '');
    $password        = $_POST['password']          ?? '';
    $confirm_password= $_POST['confirm_password']  ?? '';

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Name, email and password fields are required.';
    } elseif (!validateEmail($email)) {
        $error = 'Invalid email format.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $avatar = null;
        if (!empty($_FILES['avatar']['name'])) {
            $file    = $_FILES['avatar'];
            $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
            $finfo   = finfo_open(FILEINFO_MIME_TYPE);
            $mime    = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            if (!in_array($mime, $allowed)) {
                $error = 'Profile photo must be JPEG, PNG, GIF or WebP.';
            } elseif ($file['size'] > 3 * 1024 * 1024) {
                $error = 'Profile photo must be smaller than 3 MB.';
            } else {
                $ext    = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $avatar = 'avatar_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], __DIR__ . '/assets/uploads/' . $avatar)) {
                    $error = 'Failed to upload photo.'; $avatar = null;
                }
            }
        }
        if (empty($error)) {
            $chk = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $chk->bind_param("s", $email); $chk->execute();
            if ($chk->get_result()->num_rows > 0) {
                $error = 'This email is already registered.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $ins = $conn->prepare(
                    "INSERT INTO users (name,email,password,avatar,city,country,additional_info,role)
                     VALUES (?,?,?,?,?,?,?,'user')"
                );
                $ins->bind_param("sssssss", $name, $email, $hashed, $avatar, $city, $country, $additional_info);
                if ($ins->execute()) {
                    $success = 'Account created! Redirecting to login…';
                    header('refresh:2;url=login.php');
                } else {
                    $error = 'Error creating account. Please try again.';
                }
                $ins->close();
            }
            $chk->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up – Travel Planner</title>
    <style>
        <?php include 'includes/auth-styles.css.php'; ?>

        /* ── Signup: centered rounded box (same style as login) ── */
        body {
            align-items: center;
            justify-content: center;
            padding: 32px 16px;
        }
        .auth-card {
            max-width: 500px;
            width: 100%;
            min-height: auto;
            border-radius: 20px;
            padding: 40px 44px 36px;
            background: rgba(12, 18, 52, 0.88);
            box-shadow: 0 28px 70px rgba(0,0,0,0.55);
            border: 1px solid rgba(255,255,255,0.14);
        }
        @media (max-width: 540px) {
            .auth-card { padding: 32px 22px 28px; border-radius: 16px; }
            .form-row  { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-icon">✈️</span>
            <h1>Create Account</h1>
            <p>Join thousands of travellers planning smarter</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" action="" enctype="multipart/form-data" novalidate>

            <!-- Profile photo -->
            <div class="avatar-picker">
                <div class="avatar-ring">
                    <img id="avatar-preview"
                         src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 88 88'%3E%3Ccircle cx='44' cy='44' r='44' fill='%23667eea'/%3E%3Ccircle cx='44' cy='34' r='15' fill='rgba(255,255,255,0.75)'/%3E%3Cellipse cx='44' cy='78' rx='25' ry='19' fill='rgba(255,255,255,0.75)'/%3E%3C/svg%3E"
                         alt="Avatar preview">
                    <div class="avatar-overlay">📷</div>
                    <input type="file" name="avatar" accept="image/jpeg,image/png,image/gif,image/webp"
                           onchange="previewAvatar(this)">
                </div>
                <span class="avatar-hint">Click to add profile photo (optional)</span>
            </div>

            <!-- Name -->
            <div class="form-group">
                <label for="name">👤 Full Name <span class="req">*</span></label>
                <input type="text" id="name" name="name" placeholder="John Doe" required
                       value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">📧 Email Address <span class="req">*</span></label>
                <input type="email" id="email" name="email" placeholder="you@example.com" required
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>

            <!-- City + Country -->
            <div class="form-row">
                <div class="form-group">
                    <label for="city">🏙️ City</label>
                    <input type="text" id="city" name="city" placeholder="Karachi"
                           value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="country">🌐 Country</label>
                    <input type="text" id="country" name="country" placeholder="Pakistan"
                           value="<?php echo htmlspecialchars($_POST['country'] ?? ''); ?>">
                </div>
            </div>

            <!-- About -->
            <div class="form-group">
                <label for="additional_info">📝 About You</label>
                <textarea id="additional_info" name="additional_info"
                          placeholder="Tell us about your travel interests…"><?php echo htmlspecialchars($_POST['additional_info'] ?? ''); ?></textarea>
            </div>

            <!-- Password -->
            <div class="form-group">
                <label for="password">🔒 Password <span class="req">*</span></label>
                <div class="pw-wrap">
                    <input type="password" id="password" name="password"
                           placeholder="Min. 6 characters" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('password',this)">👁️</button>
                </div>
            </div>

            <!-- Confirm Password -->
            <div class="form-group">
                <label for="confirm_password">🔒 Confirm Password <span class="req">*</span></label>
                <div class="pw-wrap">
                    <input type="password" id="confirm_password" name="confirm_password"
                           placeholder="Repeat your password" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('confirm_password',this)">👁️</button>
                </div>
            </div>

            <button type="submit" class="btn-auth">Register &amp; Start Exploring ✈️</button>
        </form>

        <div class="divider"><span>or</span></div>
        <p class="auth-footer">Already have an account? <a href="login.php">Login here</a></p>
    </div>

    <script>
        function togglePw(id, btn) {
            const inp = document.getElementById(id);
            inp.type = inp.type === 'password' ? 'text' : 'password';
            btn.textContent = inp.type === 'password' ? '👁️' : '🙈';
        }
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => { document.getElementById('avatar-preview').src = e.target.result; };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>
