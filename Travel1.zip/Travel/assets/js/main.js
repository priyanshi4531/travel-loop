// Travel Planner - Main JavaScript
document.addEventListener("DOMContentLoaded", function () {
  // Initialize any JavaScript functionality here
  console.log("Travel Planner loaded");
});
