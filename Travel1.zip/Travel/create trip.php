<?php
session_start();
include 'db.php';

if(isset($_POST['create'])){

    $user_id = $_SESSION['user_id'];
    $trip_name = $_POST['trip_name'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $description = $_POST['description'];

    $photo = $_FILES['photo']['name'];
    move_uploaded_file($_FILES['photo']['tmp_name'],"uploads/".$photo);

    $sql = "INSERT INTO trips(user_id,trip_name,start_date,end_date,description,cover_photo)
            VALUES('$user_id','$trip_name','$start_date','$end_date','$description','$photo')";

    mysqli_query($conn,$sql);

    echo "Trip Created";
}
?>

<form method="POST" enctype="multipart/form-data">

    <input type="text" name="trip_name" placeholder="Trip Name"><br><br>

    <input type="date" name="start_date"><br><br>

    <input type="date" name="end_date"><br><br>

    <textarea name="description"></textarea><br><br>

    <input type="file" name="photo"><br><br>

    <button name="create">Create Trip</button>

</form>