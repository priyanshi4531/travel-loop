<?php
$page_title = 'Itinerary';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$msg = ''; $msg_type = '';

// ── Handle add itinerary entry ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_entry'])) {
    $trip_id    = (int)($_POST['trip_id']    ?? 0);
    $city_name  = sanitizeInput($_POST['city']        ?? '');
    $travel_date= sanitizeInput($_POST['travel_date'] ?? '');
    $activity   = sanitizeInput($_POST['activity']    ?? '');
    $notes      = sanitizeInput($_POST['notes']       ?? '');

    if (empty($city_name) || empty($travel_date) || empty($activity)) {
        $msg = 'City, date and activity are required.'; $msg_type = 'error';
    } else {
        // Verify trip belongs to user
        $chk = $conn->prepare("SELECT id FROM trips WHERE id = ? AND user_id = ?");
        $chk->bind_param("ii", $trip_id, $user_id); $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            // Find or create city
            $city_stmt = $conn->prepare("SELECT id FROM cities WHERE name = ? LIMIT 1");
            $city_stmt->bind_param("s", $city_name); $city_stmt->execute();
            $city_row = $city_stmt->get_result()->fetch_assoc();
            $city_stmt->close();

            if ($city_row) {
                $city_id = $city_row['id'];
            } else {
                // Use first available city as fallback or skip
                $city_id = null;
            }

            // Insert into trip_notes as itinerary entry (using trip_notes table)
            $ins = $conn->prepare("INSERT INTO trip_notes (trip_id, user_id, title, content) VALUES (?, ?, ?, ?)");
            $title   = $travel_date . ' | ' . $city_name . ' — ' . $activity;
            $content = $notes ?: $activity;
            $ins->bind_param("iiss", $trip_id, $user_id, $title, $content);
            $ins->execute(); $ins->close();
            $msg = 'Itinerary entry added!'; $msg_type = 'success';
        }
        $chk->close();
    }
}

// ── Handle delete entry ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_entry'])) {
    $note_id = (int)$_POST['note_id'];
    $del = $conn->prepare("DELETE tn FROM trip_notes tn JOIN trips t ON tn.trip_id=t.id WHERE tn.id=? AND t.user_id=?");
    $del->bind_param("ii", $note_id, $user_id); $del->execute(); $del->close();
    header('Location: itinerary.php'); exit();
}

// ── Fetch user trips ──────────────────────────────────────────────
$trips_stmt = $conn->prepare("SELECT id, name, start_date, end_date FROM trips WHERE user_id = ? ORDER BY created_at DESC");
$trips_stmt->bind_param("i", $user_id); $trips_stmt->execute();
$user_trips = $trips_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$trips_stmt->close();

// ── Fetch itinerary entries (from trip_notes, title contains date|city) ──
$notes_stmt = $conn->prepare(
    "SELECT tn.*, t.name AS trip_name
     FROM trip_notes tn
     JOIN trips t ON tn.trip_id = t.id
     WHERE t.user_id = ?
     ORDER BY tn.trip_id, tn.title ASC"
);
$notes_stmt->bind_param("i", $user_id); $notes_stmt->execute();
$all_notes = $notes_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$notes_stmt->close();

// Group by trip
$itinerary_by_trip = [];
foreach ($all_notes as $note) {
    $itinerary_by_trip[$note['trip_id']]['name']    = $note['trip_name'];
    $itinerary_by_trip[$note['trip_id']]['entries'][] = $note;
}

// Fetch all cities for autocomplete
$cities_stmt = $conn->prepare("SELECT name FROM cities ORDER BY name ASC");
$cities_stmt->execute();
$city_names = array_column($cities_stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'name');
$cities_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif; color: #1a1a2e; min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.60), rgba(8,12,35,0.60)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }
        header { background: #0f172a; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 20px rgba(0,0,0,0.3); }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2) !important; color: #fff !important; }

        .hero {
            background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 56px 40px 48px; text-align: center;
        }
        .hero-badge { display: inline-block; background: rgba(102,126,234,0.25); border: 1px solid rgba(102,126,234,0.45); color: #a5b4fc; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 6px 16px; border-radius: 20px; margin-bottom: 16px; }
        .hero h1 { font-size: 36px; font-weight: 900; color: #fff; margin-bottom: 10px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); }
        .hero p  { font-size: 15px; color: rgba(255,255,255,0.62); }

        main { max-width: 1100px; margin: 0 auto; padding: 36px 24px 70px; }

        .alert { padding: 12px 18px; border-radius: 9px; font-size: 14px; margin-bottom: 24px; font-weight: 500; }
        .alert-success { background: rgba(34,197,94,0.18); color: #86efac; border-left: 3px solid #22c55e; }
        .alert-error   { background: rgba(239,68,68,0.18); color: #fca5a5; border-left: 3px solid #ef4444; }

        .layout { display: grid; grid-template-columns: 340px 1fr; gap: 28px; align-items: start; }

        .card { background: rgba(255,255,255,0.97); border-radius: 16px; box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; margin-bottom: 24px; }
        .card:last-child { margin-bottom: 0; }
        .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; }
        .card-header h3 { font-size: 16px; font-weight: 800; color: #1a1a2e; }

        .form-body { padding: 22px 24px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 7px; }
        .form-group input,
        .form-group select,
        .form-group textarea { width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 8px; font-size: 14px; font-family: inherit; color: #1a1a2e; background: #fafbff; transition: border-color 0.2s; }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus { outline: none; border-color: #667eea; background: #fff; }
        .btn-add { width: 100%; padding: 12px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; transition: opacity 0.2s, transform 0.15s; }
        .btn-add:hover { opacity: 0.88; transform: translateY(-1px); }

        .sec-title { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; text-shadow: 0 1px 6px rgba(0,0,0,0.4); }

        /* Timeline */
        .trip-block { margin-bottom: 28px; }
        .trip-header { padding: 16px 24px; background: linear-gradient(135deg,#667eea,#764ba2); display: flex; align-items: center; justify-content: space-between; }
        .trip-header h4 { font-size: 15px; font-weight: 800; color: #fff; }
        .trip-header span { font-size: 12px; color: rgba(255,255,255,0.75); }

        .timeline { padding: 20px 24px; }
        .timeline-entry { display: flex; gap: 16px; margin-bottom: 20px; position: relative; }
        .timeline-entry:last-child { margin-bottom: 0; }
        .timeline-entry::before { content: ''; position: absolute; left: 19px; top: 36px; bottom: -20px; width: 2px; background: #e5e7eb; }
        .timeline-entry:last-child::before { display: none; }

        .tl-dot { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg,#667eea,#764ba2); display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; box-shadow: 0 3px 10px rgba(102,126,234,0.35); }
        .tl-content { flex: 1; background: #f8f9ff; border-radius: 10px; padding: 14px 16px; border: 1px solid #eef0f8; }
        .tl-date { font-size: 11px; font-weight: 700; color: #667eea; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
        .tl-title { font-size: 14px; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; }
        .tl-notes { font-size: 13px; color: #666; line-height: 1.5; }
        .tl-actions { display: flex; justify-content: flex-end; margin-top: 8px; }
        .btn-del { background: none; border: none; color: #ddd; cursor: pointer; font-size: 15px; transition: color 0.2s; }
        .btn-del:hover { color: #ef4444; }

        .empty-state { padding: 48px 20px; text-align: center; }
        .empty-state .ei { font-size: 52px; margin-bottom: 14px; }
        .empty-state p { color: #aaa; font-size: 15px; }

        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 22px; font-size: 13px; }

        @media (max-width: 900px) { .layout { grid-template-columns: 1fr; } }
        @media (max-width: 600px) { header nav { padding: 0 16px; } .hero { padding: 40px 20px; } .hero h1 { font-size: 26px; } main { padding: 24px 16px 50px; } }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php">Budget</a></li>
            <li><a href="packing.php">Packing</a></li>
            <li><a href="itinerary.php" class="active">Itinerary</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<div class="hero">
    <div class="hero-badge">📅 Itinerary Builder</div>
    <h1>Plan Your Day-by-Day Journey</h1>
    <p>Add activities, cities and notes to build your perfect travel itinerary</p>
</div>

<main>
    <?php if ($msg): ?>
        <div class="alert alert-<?php echo $msg_type; ?>"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="layout">

        <!-- ── LEFT: Add Entry Form ── -->
        <div>
            <div class="card">
                <div class="card-header">
                    <h3>➕ Add Itinerary Entry</h3>
                </div>
                <?php if (!empty($user_trips)): ?>
                <form method="POST" action="" class="form-body">
                    <input type="hidden" name="add_entry" value="1">

                    <div class="form-group">
                        <label>Trip</label>
                        <select name="trip_id" required>
                            <option value="">— Select Trip —</option>
                            <?php foreach ($user_trips as $t): ?>
                                <option value="<?php echo (int)$t['id']; ?>">
                                    <?php echo htmlspecialchars($t['name']); ?>
                                    <?php if (!empty($t['start_date'])): ?>
                                        (<?php echo date('M Y', strtotime($t['start_date'])); ?>)
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Travel Date</label>
                        <input type="date" name="travel_date" required>
                    </div>

                    <div class="form-group">
                        <label>City / Destination</label>
                        <input type="text" name="city" list="city-list"
                               placeholder="e.g. Paris" required>
                        <datalist id="city-list">
                            <?php foreach ($city_names as $cn): ?>
                                <option value="<?php echo htmlspecialchars($cn); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="form-group">
                        <label>Activity / Plan</label>
                        <input type="text" name="activity"
                               placeholder="e.g. Visit Eiffel Tower" required maxlength="200">
                    </div>

                    <div class="form-group">
                        <label>Notes <span style="font-weight:400;color:#aaa;">(optional)</span></label>
                        <textarea name="notes" placeholder="Any extra details, timings, tips…"></textarea>
                    </div>

                    <button type="submit" class="btn-add">📅 Add to Itinerary</button>
                </form>
                <?php else: ?>
                <div class="empty-state">
                    <div class="ei">🗺️</div>
                    <p>Create a trip first to build your itinerary!</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ── RIGHT: Timeline View ── -->
        <div>
            <div class="sec-title">📅 Your Itineraries</div>

            <?php if (!empty($itinerary_by_trip)): ?>
                <?php foreach ($itinerary_by_trip as $trip_id => $trip_data):
                    $entries = $trip_data['entries'];
                    $day_icons = ['🌅','🏛️','🍽️','🎭','🌆','🌙','🎯','🚶','🏖️','🗺️'];
                ?>
                <div class="card trip-block">
                    <div class="trip-header">
                        <h4>🗺️ <?php echo htmlspecialchars($trip_data['name']); ?></h4>
                        <span><?php echo count($entries); ?> entries</span>
                    </div>
                    <div class="timeline">
                        <?php foreach ($entries as $idx => $entry):
                            // Parse title: "date | city — activity"
                            $parts = explode(' | ', $entry['title'], 2);
                            $date_part = $parts[0] ?? '';
                            $rest      = $parts[1] ?? $entry['title'];
                            $sub_parts = explode(' — ', $rest, 2);
                            $city_part = $sub_parts[0] ?? '';
                            $act_part  = $sub_parts[1] ?? $rest;
                            $icon = $day_icons[$idx % count($day_icons)];
                            $formatted_date = !empty($date_part) && strtotime($date_part)
                                ? date('D, M j Y', strtotime($date_part))
                                : $date_part;
                        ?>
                        <div class="timeline-entry">
                            <div class="tl-dot"><?php echo $icon; ?></div>
                            <div class="tl-content">
                                <div class="tl-date">
                                    <?php echo htmlspecialchars($formatted_date); ?>
                                    <?php if ($city_part): ?>
                                        &nbsp;·&nbsp; 📍 <?php echo htmlspecialchars($city_part); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="tl-title"><?php echo htmlspecialchars($act_part); ?></div>
                                <?php if (!empty($entry['content']) && $entry['content'] !== $act_part): ?>
                                    <div class="tl-notes"><?php echo htmlspecialchars($entry['content']); ?></div>
                                <?php endif; ?>
                                <div class="tl-actions">
                                    <form method="POST" action="" style="display:inline;">
                                        <input type="hidden" name="delete_entry" value="1">
                                        <input type="hidden" name="note_id" value="<?php echo (int)$entry['id']; ?>">
                                        <button type="submit" class="btn-del"
                                                onclick="return confirm('Remove this entry?')" title="Remove">🗑️</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>

            <?php else: ?>
                <div class="card">
                    <div class="empty-state">
                        <div class="ei">📅</div>
                        <p>No itinerary entries yet.<br>Add your first activity from the form!</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<footer><p>© 2026 Travel Planner. All rights reserved.</p></footer>
</body>
</html>