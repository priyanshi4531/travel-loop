<?php
$page_title = 'Create New Trip';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

requireLogin();

$user_id = $_SESSION['user_id'];
$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ── Sanitize text inputs ──────────────────────────────────────
    $name        = sanitizeInput($_POST['name']        ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $start_date  = sanitizeInput($_POST['start_date']  ?? '');
    $end_date    = sanitizeInput($_POST['end_date']    ?? '');
    $status      = sanitizeInput($_POST['status']      ?? 'draft');
    $budget      = floatval($_POST['budget']           ?? 0);
    $currency    = sanitizeInput($_POST['currency']    ?? 'USD');

    // ── Validation ────────────────────────────────────────────────
    $allowed_statuses  = ['draft', 'published', 'shared'];
    $allowed_currencies = ['USD', 'EUR', 'GBP', 'PKR', 'AED', 'JPY', 'AUD', 'CAD', 'INR', 'SGD'];

    if (empty($name)) {
        $error = 'Trip name is required.';
    } elseif (!empty($start_date) && !empty($end_date) && $end_date < $start_date) {
        $error = 'End date cannot be before the start date.';
    } elseif (!in_array($status, $allowed_statuses)) {
        $error = 'Invalid status selected.';
    } elseif (!in_array($currency, $allowed_currencies)) {
        $error = 'Invalid currency selected.';
    } else {
        // ── Cover photo upload ────────────────────────────────────
        $cover_photo = null;

        if (!empty($_FILES['cover_photo']['name'])) {
            $file      = $_FILES['cover_photo'];
            $allowed   = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $max_size  = 5 * 1024 * 1024; // 5 MB

            $finfo    = finfo_open(FILEINFO_MIME_TYPE);
            $mime     = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            if (!in_array($mime, $allowed)) {
                $error = 'Cover photo must be a JPEG, PNG, GIF, or WebP image.';
            } elseif ($file['size'] > $max_size) {
                $error = 'Cover photo must be smaller than 5 MB.';
            } else {
                $ext         = pathinfo($file['name'], PATHINFO_EXTENSION);
                $cover_photo = 'trip_' . $user_id . '_' . time() . '.' . strtolower($ext);
                $upload_dir  = __DIR__ . '/assets/uploads/';

                if (!move_uploaded_file($file['tmp_name'], $upload_dir . $cover_photo)) {
                    $error       = 'Failed to upload cover photo. Please try again.';
                    $cover_photo = null;
                }
            }
        }

        // ── Insert into DB ────────────────────────────────────────
        if (empty($error)) {
            $stmt = $conn->prepare(
                "INSERT INTO trips (user_id, name, description, cover_photo, start_date, end_date, status, budget, currency)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            $start_date_val = !empty($start_date) ? $start_date : null;
            $end_date_val   = !empty($end_date)   ? $end_date   : null;

            $stmt->bind_param(
                "issssssds",
                $user_id,
                $name,
                $description,
                $cover_photo,
                $start_date_val,
                $end_date_val,
                $status,
                $budget,
                $currency
            );

            if ($stmt->execute()) {
                $new_trip_id = $stmt->insert_id;
                $stmt->close();
                setMessage('Trip "' . htmlspecialchars($name) . '" created successfully!', 'success');
                header('Location: trip-detail.php?id=' . $new_trip_id);
                exit();
            } else {
                $error = 'Database error. Please try again.';
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Travel Planner</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
            min-height: 100vh;
        }
        /* ── Page layout ── */
        .page-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 36px 32px;
            border-radius: 12px;
            margin-bottom: 32px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .page-hero-icon { font-size: 48px; line-height: 1; }
        .page-hero h1  { color: white; margin: 0 0 4px; font-size: 26px; }
        .page-hero p   { margin: 0; opacity: 0.88; font-size: 14px; }

        /* ── Two-column layout ── */
        .form-layout {
            display: grid;
            grid-template-columns: 1fr 340px;
            gap: 28px;
            align-items: start;
        }

        /* ── Cards ── */
        .form-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            padding: 28px 32px;
            margin-bottom: 24px;
        }
        .form-card:last-child { margin-bottom: 0; }
        .card-title {
            font-size: 16px;
            font-weight: 700;
            color: #2c3e50;
            margin: 0 0 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* ── Form elements ── */
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #444;
            margin-bottom: 7px;
        }
        .required-star { color: #e74c3c; margin-left: 2px; }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="number"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid #dde1ec;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            color: #1a1a2e;
            background: #fafbff;
            transition: border-color 0.25s, box-shadow 0.25s;
        }
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.15);
            background: white;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 110px;
        }

        /* Date row */
        .date-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        /* Budget row */
        .budget-row {
            display: grid;
            grid-template-columns: 1fr 120px;
            gap: 12px;
        }

        /* ── Cover photo upload ── */
        .upload-area {
            border: 2px dashed #c5cae9;
            border-radius: 10px;
            padding: 28px 20px;
            text-align: center;
            cursor: pointer;
            transition: border-color 0.25s, background 0.25s;
            background: #fafbff;
            position: relative;
        }
        .upload-area:hover,
        .upload-area.drag-over {
            border-color: #667eea;
            background: #f0f3ff;
        }
        .upload-area input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
            width: 100%;
            height: 100%;
        }
        .upload-icon  { font-size: 36px; margin-bottom: 8px; }
        .upload-text  { font-size: 14px; color: #555; margin-bottom: 4px; }
        .upload-hint  { font-size: 12px; color: #aaa; }

        /* Preview */
        #photo-preview {
            display: none;
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 12px;
        }

        /* ── Status badges ── */
        .status-options {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .status-option {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 12px 14px;
            border: 1.5px solid #e8e8e8;
            border-radius: 8px;
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
        }
        .status-option:hover { border-color: #667eea; background: #f8f9ff; }
        .status-option input[type="radio"] { margin-top: 2px; accent-color: #667eea; }
        .status-option-label { font-size: 13px; font-weight: 600; color: #2c3e50; }
        .status-option-desc  { font-size: 12px; color: #888; margin-top: 2px; }
        .status-option.selected { border-color: #667eea; background: #f0f3ff; }

        /* ── Alert ── */
        .alert {
            padding: 13px 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-error   { background: #fde8e8; color: #c0392b; border-left: 4px solid #e74c3c; }
        .alert-success { background: #e8f8f0; color: #1e8449; border-left: 4px solid #27ae60; }

        /* ── Submit button ── */
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            letter-spacing: 0.3px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102,126,234,0.4);
        }
        .btn-submit:active { transform: translateY(0); }

        .btn-cancel {
            display: block;
            text-align: center;
            margin-top: 12px;
            color: #888;
            font-size: 14px;
            text-decoration: none;
        }
        .btn-cancel:hover { color: #e74c3c; }

        /* ── Tips card ── */
        .tips-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .tips-list li {
            display: flex;
            gap: 10px;
            font-size: 13px;
            color: #555;
            line-height: 1.5;
        }
        .tips-list li span.tip-icon { font-size: 16px; flex-shrink: 0; }

        /* ── Responsive ── */
        @media (max-width: 900px) {
            .form-layout { grid-template-columns: 1fr; }
        }
        @media (max-width: 560px) {
            .date-row, .budget-row { grid-template-columns: 1fr; }
            .form-card { padding: 20px; }
        }
    </style>
</head>
<body>
    <!-- ── Nav ── -->
    <header>
        <nav>
            <div class="logo">✈️ Travel Planner</div>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="my_trips.php">My Trips</a></li>
                <li><a href="profile.php">Profile</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin/index.php">Admin</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Hero -->
        <div class="page-hero">
            <div class="page-hero-icon">🗺️</div>
            <div>
                <h1>Plan a New Trip</h1>
                <p>Fill in the details below to start building your next adventure</p>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="" enctype="multipart/form-data" id="create-trip-form" novalidate>
            <div class="form-layout">

                <!-- ══ LEFT COLUMN ══ -->
                <div>
                    <!-- Basic Info -->
                    <div class="form-card">
                        <div class="card-title">📋 Trip Details</div>

                        <div class="form-group">
                            <label for="name">Trip Name <span class="required-star">*</span></label>
                            <input type="text" id="name" name="name" placeholder="e.g. Summer in Europe"
                                   maxlength="200" required
                                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea id="description" name="description"
                                      placeholder="What's this trip about? Destinations, goals, highlights…"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                        </div>

                        <div class="date-row">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" id="start_date" name="start_date"
                                       value="<?php echo htmlspecialchars($_POST['start_date'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" id="end_date" name="end_date"
                                       value="<?php echo htmlspecialchars($_POST['end_date'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Budget -->
                    <div class="form-card">
                        <div class="card-title">💰 Budget</div>

                        <div class="budget-row">
                            <div class="form-group">
                                <label for="budget">Total Budget</label>
                                <input type="number" id="budget" name="budget" min="0" step="0.01"
                                       placeholder="0.00"
                                       value="<?php echo htmlspecialchars($_POST['budget'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="currency">Currency</label>
                                <select id="currency" name="currency">
                                    <?php
                                    $currencies = [
                                        'USD' => '🇺🇸 USD',
                                        'EUR' => '🇪🇺 EUR',
                                        'GBP' => '🇬🇧 GBP',
                                        'PKR' => '🇵🇰 PKR',
                                        'AED' => '🇦🇪 AED',
                                        'JPY' => '🇯🇵 JPY',
                                        'AUD' => '🇦🇺 AUD',
                                        'CAD' => '🇨🇦 CAD',
                                        'INR' => '🇮🇳 INR',
                                        'SGD' => '🇸🇬 SGD',
                                    ];
                                    $selected_currency = $_POST['currency'] ?? 'USD';
                                    foreach ($currencies as $code => $label):
                                    ?>
                                        <option value="<?php echo $code; ?>"
                                            <?php echo $selected_currency === $code ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Cover Photo -->
                    <div class="form-card">
                        <div class="card-title">🖼️ Cover Photo</div>

                        <div class="upload-area" id="upload-area">
                            <input type="file" name="cover_photo" id="cover_photo"
                                   accept="image/jpeg,image/png,image/gif,image/webp"
                                   onchange="previewPhoto(this)">
                            <div id="upload-placeholder">
                                <div class="upload-icon">📷</div>
                                <div class="upload-text">Click or drag & drop a photo</div>
                                <div class="upload-hint">JPEG, PNG, GIF or WebP · Max 5 MB</div>
                            </div>
                        </div>
                        <img id="photo-preview" src="" alt="Cover preview">
                    </div>
                </div>

                <!-- ══ RIGHT COLUMN ══ -->
                <div>
                    <!-- Status -->
                    <div class="form-card">
                        <div class="card-title">📌 Trip Status</div>

                        <div class="status-options" id="status-options">
                            <?php
                            $statuses = [
                                'draft'     => ['🗒️', 'Draft',     'Only visible to you. Work in progress.'],
                                'published' => ['✅', 'Published', 'Finalized and saved to your profile.'],
                                'shared'    => ['🔗', 'Shared',    'Anyone with the link can view it.'],
                            ];
                            $selected_status = $_POST['status'] ?? 'draft';
                            foreach ($statuses as $val => [$icon, $label, $desc]):
                            ?>
                                <label class="status-option <?php echo $selected_status === $val ? 'selected' : ''; ?>">
                                    <input type="radio" name="status" value="<?php echo $val; ?>"
                                           <?php echo $selected_status === $val ? 'checked' : ''; ?>>
                                    <div>
                                        <div class="status-option-label"><?php echo $icon . ' ' . $label; ?></div>
                                        <div class="status-option-desc"><?php echo $desc; ?></div>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="form-card">
                        <div class="card-title">🚀 Create Trip</div>
                        <button type="submit" class="btn-submit">Create Trip ✈️</button>
                        <a href="my_trips.php" class="btn-cancel">Cancel</a>
                    </div>

                    <!-- Tips -->
                    <div class="form-card">
                        <div class="card-title">💡 Tips</div>
                        <ul class="tips-list">
                            <li>
                                <span class="tip-icon">📅</span>
                                Set your dates now — you can always adjust them later.
                            </li>
                            <li>
                                <span class="tip-icon">💰</span>
                                Add a budget to track spending across all your activities.
                            </li>
                            <li>
                                <span class="tip-icon">🖼️</span>
                                A great cover photo makes your trip easy to spot in your list.
                            </li>
                            <li>
                                <span class="tip-icon">🔗</span>
                                Use <strong>Shared</strong> status to let friends view your itinerary.
                            </li>
                        </ul>
                    </div>
                </div>

            </div><!-- /.form-layout -->
        </form>
    </main>

    <footer>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
    </footer>
    <script src="assets/js/main.js"></script>
    <script>
        // ── Cover photo preview ──────────────────────────────────
        function previewPhoto(input) {
            const preview     = document.getElementById('photo-preview');
            const placeholder = document.getElementById('upload-placeholder');

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => {
                    preview.src          = e.target.result;
                    preview.style.display = 'block';
                    placeholder.style.display = 'none';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // ── Drag-and-drop highlight ──────────────────────────────
        const uploadArea = document.getElementById('upload-area');
        uploadArea.addEventListener('dragover',  e => { e.preventDefault(); uploadArea.classList.add('drag-over'); });
        uploadArea.addEventListener('dragleave', ()  => uploadArea.classList.remove('drag-over'));
        uploadArea.addEventListener('drop',      e => {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            const fileInput = document.getElementById('cover_photo');
            fileInput.files = e.dataTransfer.files;
            previewPhoto(fileInput);
        });

        // ── Status option highlight on click ────────────────────
        document.querySelectorAll('.status-option input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', () => {
                document.querySelectorAll('.status-option').forEach(el => el.classList.remove('selected'));
                radio.closest('.status-option').classList.add('selected');
            });
        });

        // ── Client-side date validation ──────────────────────────
        document.getElementById('create-trip-form').addEventListener('submit', function (e) {
            const start = document.getElementById('start_date').value;
            const end   = document.getElementById('end_date').value;
            if (start && end && end < start) {
                e.preventDefault();
                alert('End date cannot be before the start date.');
            }
        });
    </script>
</body>
</html>
