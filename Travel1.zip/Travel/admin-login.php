<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Already logged in as admin → go straight to admin panel
if (isLoggedIn() && isAdmin()) {
    header('Location: /Travel/admin/index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    // ── Option 1: Hard-coded fallback (always works, no DB needed) ──
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user_id']   = 1;
        $_SESSION['user_name'] = 'Admin';
        $_SESSION['is_admin']  = true;
        header('Location: /Travel/admin/index.php');
        exit();
    }

    // ── Option 2: Check admin table (id, username, password) ─────
    // Only run if admin table exists
    $table_check = $conn->query("SHOW TABLES LIKE 'admin'");
    if ($table_check && $table_check->num_rows > 0) {
        $stmt = $conn->prepare("SELECT id, username, password FROM admin WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $admin_row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($admin_row) {
            $pass_ok = ($password === $admin_row['password'])
                    || password_verify($password, $admin_row['password']);
            if ($pass_ok) {
                $_SESSION['user_id']   = $admin_row['id'];
                $_SESSION['user_name'] = $admin_row['username'];
                $_SESSION['is_admin']  = true;
                header('Location: /Travel/admin/index.php');
                exit();
            }
        }
    }

    // ── Option 3: Check users table with role=admin ───────────────
    if (strpos($username, '@') !== false) {
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['is_admin']  = true;
            header('Location: /Travel/admin/index.php');
            exit();
        }
    }

    $error = 'Invalid admin credentials.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background:
                linear-gradient(rgba(5,8,25,0.72), rgba(5,8,25,0.82)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* Glow blobs */
        body::before, body::after {
            content: ''; position: fixed; border-radius: 50%; pointer-events: none;
            animation: blob 12s ease-in-out infinite;
        }
        body::before {
            width: 500px; height: 500px;
            background: radial-gradient(circle, rgba(239,68,68,0.18) 0%, transparent 70%);
            top: -150px; right: -100px;
        }
        body::after {
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(99,102,241,0.18) 0%, transparent 70%);
            bottom: -100px; left: -100px;
            animation-delay: -6s;
        }
        @keyframes blob {
            0%,100% { transform: translate(0,0) scale(1); }
            50%      { transform: translate(20px,15px) scale(1.06); }
        }

        /* Card */
        .auth-card {
            position: relative; z-index: 1;
            width: 100%; max-width: 420px;
            background: rgba(8,12,40,0.88);
            backdrop-filter: blur(22px);
            -webkit-backdrop-filter: blur(22px);
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 22px;
            padding: 44px 40px 38px;
            box-shadow: 0 28px 70px rgba(0,0,0,0.60);
        }

        /* Admin badge */
        .admin-badge {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            background: rgba(239,68,68,0.18); border: 1px solid rgba(239,68,68,0.35);
            border-radius: 30px; padding: 7px 20px; width: fit-content;
            margin: 0 auto 22px;
        }
        .admin-badge span { font-size: 12px; font-weight: 700; color: #fca5a5; letter-spacing: 1px; text-transform: uppercase; }

        /* Brand */
        .auth-brand { text-align: center; margin-bottom: 30px; }
        .brand-icon { font-size: 50px; display: block; margin-bottom: 10px; filter: drop-shadow(0 3px 10px rgba(0,0,0,0.5)); }
        .auth-brand h1 { color: #ffffff; font-size: 24px; font-weight: 800; margin: 0 0 6px; }
        .auth-brand p  { color: rgba(255,255,255,0.45); font-size: 13px; }

        /* Alert */
        .alert { padding: 12px 15px; border-radius: 8px; font-size: 13px; margin-bottom: 22px; display: flex; align-items: center; gap: 8px; font-weight: 500; }
        .alert-error { background: rgba(239,68,68,0.20); color: #fca5a5; border-left: 3px solid #ef4444; }

        /* Form */
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 12px; font-weight: 700; color: rgba(255,255,255,0.65); margin-bottom: 8px; letter-spacing: 0.8px; text-transform: uppercase; }
        .input-wrap { position: relative; }
        .input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); font-size: 16px; pointer-events: none; line-height: 1; }
        .input-wrap input {
            width: 100%; padding: 13px 14px 13px 44px;
            background: rgba(255,255,255,0.08); border: 1.5px solid rgba(255,255,255,0.15);
            border-radius: 10px; font-size: 15px; font-family: inherit; color: #ffffff;
            transition: border-color 0.25s, background 0.25s, box-shadow 0.25s;
        }
        .input-wrap input::placeholder { color: rgba(255,255,255,0.30); font-size: 14px; }
        .input-wrap input:focus { outline: none; border-color: #818cf8; background: rgba(255,255,255,0.13); box-shadow: 0 0 0 3px rgba(129,140,248,0.20); }
        .toggle-pw { position: absolute; right: 13px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.35); padding: 0; line-height: 1; }
        .toggle-pw:hover { color: #ffffff; }

        /* Hint box */
        .hint-box { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.10); border-radius: 9px; padding: 12px 16px; margin-bottom: 22px; font-size: 12px; color: rgba(255,255,255,0.45); line-height: 1.7; }
        .hint-box strong { color: rgba(255,255,255,0.70); }

        /* Submit */
        .btn-auth {
            width: 100%; padding: 14px;
            background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%);
            color: #ffffff; border: none; border-radius: 10px;
            font-size: 16px; font-weight: 700; cursor: pointer; letter-spacing: 0.4px;
            transition: transform 0.2s, box-shadow 0.2s; margin-top: 4px;
            box-shadow: 0 4px 18px rgba(239,68,68,0.40);
        }
        .btn-auth:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(239,68,68,0.55); }
        .btn-auth:active { transform: translateY(0); }

        /* Divider */
        .divider { display: flex; align-items: center; gap: 12px; margin: 22px 0 18px; color: rgba(255,255,255,0.20); font-size: 12px; }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: rgba(255,255,255,0.10); }

        /* Footer */
        .auth-footer { text-align: center; font-size: 13px; color: rgba(255,255,255,0.40); }
        .auth-footer a { color: #818cf8; font-weight: 700; text-decoration: none; }
        .auth-footer a:hover { color: #ffffff; text-decoration: underline; }

        @media (max-width: 480px) { .auth-card { padding: 36px 22px 30px; } }
    </style>
</head>
<body>
    <div class="auth-card">

        <div class="admin-badge"><span>🛡️ Admin Portal</span></div>

        <div class="auth-brand">
            <span class="brand-icon">⚙️</span>
            <h1>Admin Login</h1>
            <p>Restricted access — authorised personnel only</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="hint-box">
            <strong>Username:</strong> admin &nbsp;&nbsp; <strong>Password:</strong> admin123<br>
            <span style="font-size:11px;opacity:0.7;">(Uses your admin table: id, username, password)</span>
        </div>

        <form method="POST" action="" novalidate>
            <div class="form-group">
                <label>Admin Username</label>
                <div class="input-wrap">
                    <span class="input-icon">👤</span>
                    <input type="text" id="email" name="email" placeholder="admin"
                           required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <span class="input-icon">🔒</span>
                    <input type="password" id="password" name="password"
                           placeholder="Admin password" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('password',this)">👁️</button>
                </div>
            </div>
            <button type="submit" class="btn-auth">Access Admin Panel →</button>
        </form>

        <div class="divider"><span>or</span></div>
        <div class="auth-footer">
            Not an admin? <a href="login.php">User login here</a>
        </div>
    </div>

    <script>
        function togglePw(id, btn) {
            const inp = document.getElementById(id);
            inp.type = inp.type === 'password' ? 'text' : 'password';
            btn.textContent = inp.type === 'password' ? '👁️' : '🙈';
        }
    </script>
</body>
</html>
