<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
}
?>

<h1>Welcome <?php echo $_SESSION['name']; ?></h1>

<a href="create_trip.php">Create Trip</a><br><br>
<a href="my_trips.php">My Trips</a><br><br>

<h2>Popular Destinations</h2>

<ul>
    <li>Goa</li>
    <li>Manali</li>
    <li>Dubai</li>
</ul>