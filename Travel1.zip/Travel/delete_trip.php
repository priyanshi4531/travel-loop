<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$trip_id = (int)($_POST['trip_id'] ?? $_GET['id'] ?? 0);

if ($trip_id) {
    // Only delete if the trip belongs to the logged-in user
    $stmt = $conn->prepare("DELETE FROM trips WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $trip_id, $user_id);
    $stmt->execute();
    $stmt->close();
}

header('Location: my_trips.php');
exit();
