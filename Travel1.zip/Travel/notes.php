<?php
$page_title = 'Trip Notes';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$msg = ''; $msg_type = '';

// ── Add note ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_note'])) {
    $trip_id = (int)($_POST['trip_id'] ?? 0);
    $title   = sanitizeInput($_POST['title']   ?? '');
    $content = sanitizeInput($_POST['content'] ?? '');

    if (empty($title) || empty($content)) {
        $msg = 'Title and content are required.'; $msg_type = 'error';
    } else {
        $chk = $conn->prepare("SELECT id FROM trips WHERE id = ? AND user_id = ?");
        $chk->bind_param("ii", $trip_id, $user_id); $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $ins = $conn->prepare("INSERT INTO trip_notes (trip_id, user_id, title, content) VALUES (?,?,?,?)");
            $ins->bind_param("iiss", $trip_id, $user_id, $title, $content);
            $ins->execute(); $ins->close();
            $msg = 'Note saved!'; $msg_type = 'success';
        } else {
            $msg = 'Invalid trip selected.'; $msg_type = 'error';
        }
        $chk->close();
    }
}

// ── Edit note ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_note'])) {
    $note_id = (int)$_POST['note_id'];
    $title   = sanitizeInput($_POST['edit_title']   ?? '');
    $content = sanitizeInput($_POST['edit_content'] ?? '');
    if (!empty($title) && !empty($content)) {
        $upd = $conn->prepare("UPDATE trip_notes tn JOIN trips t ON tn.trip_id=t.id SET tn.title=?, tn.content=? WHERE tn.id=? AND t.user_id=?");
        $upd->bind_param("ssii", $title, $content, $note_id, $user_id);
        $upd->execute(); $upd->close();
    }
    header('Location: notes.php'); exit();
}

// ── Delete note ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_note'])) {
    $note_id = (int)$_POST['note_id'];
    $del = $conn->prepare("DELETE tn FROM trip_notes tn JOIN trips t ON tn.trip_id=t.id WHERE tn.id=? AND t.user_id=?");
    $del->bind_param("ii", $note_id, $user_id); $del->execute(); $del->close();
    header('Location: notes.php'); exit();
}

// ── Fetch trips ───────────────────────────────────────────────────
$trips_stmt = $conn->prepare("SELECT id, name FROM trips WHERE user_id = ? ORDER BY created_at DESC");
$trips_stmt->bind_param("i", $user_id); $trips_stmt->execute();
$user_trips = $trips_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$trips_stmt->close();

// ── Fetch notes grouped by trip ───────────────────────────────────
$notes_stmt = $conn->prepare(
    "SELECT tn.*, t.name AS trip_name
     FROM trip_notes tn
     JOIN trips t ON tn.trip_id = t.id
     WHERE t.user_id = ?
     ORDER BY tn.trip_id, tn.updated_at DESC"
);
$notes_stmt->bind_param("i", $user_id); $notes_stmt->execute();
$all_notes = $notes_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$notes_stmt->close();

$notes_by_trip = [];
foreach ($all_notes as $note) {
    $notes_by_trip[$note['trip_id']]['name']    = $note['trip_name'];
    $notes_by_trip[$note['trip_id']]['notes'][] = $note;
}

// Note card colors
$note_colors = ['#fef9c3','#dbeafe','#d1fae5','#fce7f3','#ede9fe','#ffedd5','#e0f2fe'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif; color: #1a1a2e; min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.60), rgba(8,12,35,0.60)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* NAV */
        header { background: #0f172a; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 20px rgba(0,0,0,0.3); }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2) !important; color: #fff !important; }

        /* HERO */
        .hero {
            background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 56px 40px 48px; text-align: center;
        }
        .hero-badge { display: inline-block; background: rgba(102,126,234,0.25); border: 1px solid rgba(102,126,234,0.45); color: #a5b4fc; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 6px 16px; border-radius: 20px; margin-bottom: 16px; }
        .hero h1 { font-size: 36px; font-weight: 900; color: #fff; margin-bottom: 10px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); }
        .hero p  { font-size: 15px; color: rgba(255,255,255,0.62); }

        main { max-width: 1200px; margin: 0 auto; padding: 36px 24px 70px; }

        .alert { padding: 12px 18px; border-radius: 9px; font-size: 14px; margin-bottom: 24px; font-weight: 500; }
        .alert-success { background: rgba(34,197,94,0.18); color: #86efac; border-left: 3px solid #22c55e; }
        .alert-error   { background: rgba(239,68,68,0.18); color: #fca5a5; border-left: 3px solid #ef4444; }

        /* LAYOUT */
        .layout { display: grid; grid-template-columns: 320px 1fr; gap: 28px; align-items: start; }

        /* FORM CARD */
        .form-card { background: rgba(255,255,255,0.97); border-radius: 16px; box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; }
        .form-card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; background: linear-gradient(135deg,#667eea,#764ba2); }
        .form-card-header h3 { font-size: 16px; font-weight: 800; color: #fff; }
        .form-body { padding: 22px 24px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 7px; }
        .form-group input,
        .form-group select,
        .form-group textarea { width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 8px; font-size: 14px; font-family: inherit; color: #1a1a2e; background: #fafbff; transition: border-color 0.2s; }
        .form-group textarea { resize: vertical; min-height: 120px; }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus { outline: none; border-color: #667eea; background: #fff; }
        .btn-save { width: 100%; padding: 12px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; transition: opacity 0.2s, transform 0.15s; }
        .btn-save:hover { opacity: 0.88; transform: translateY(-1px); }

        /* NOTES AREA */
        .sec-title { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; text-shadow: 0 1px 6px rgba(0,0,0,0.4); }

        .trip-section { margin-bottom: 32px; }
        .trip-label { font-size: 14px; font-weight: 800; color: rgba(255,255,255,0.85); margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
        .trip-label span { background: rgba(255,255,255,0.15); color: rgba(255,255,255,0.70); font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 12px; }

        /* NOTES GRID — sticky note style */
        .notes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; }
        .note-card { border-radius: 12px; padding: 18px 18px 14px; box-shadow: 0 4px 16px rgba(0,0,0,0.10); position: relative; transition: transform 0.2s, box-shadow 0.2s; }
        .note-card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.15); }
        .note-card-title { font-size: 14px; font-weight: 800; color: #1a1a2e; margin-bottom: 8px; line-height: 1.3; }
        .note-card-content { font-size: 13px; color: #444; line-height: 1.6; margin-bottom: 12px;
            display: -webkit-box; -webkit-line-clamp: 5; -webkit-box-orient: vertical; overflow: hidden; }
        .note-card-footer { display: flex; align-items: center; justify-content: space-between; padding-top: 10px; border-top: 1px solid rgba(0,0,0,0.08); }
        .note-date { font-size: 11px; color: #888; font-weight: 500; }
        .note-actions { display: flex; gap: 6px; }
        .btn-edit { background: rgba(102,126,234,0.15); color: #667eea; border: none; border-radius: 6px; padding: 4px 10px; font-size: 12px; font-weight: 700; cursor: pointer; transition: background 0.2s; }
        .btn-edit:hover { background: rgba(102,126,234,0.30); }
        .btn-del  { background: rgba(239,68,68,0.12); color: #ef4444; border: none; border-radius: 6px; padding: 4px 10px; font-size: 12px; font-weight: 700; cursor: pointer; transition: background 0.2s; }
        .btn-del:hover { background: rgba(239,68,68,0.25); }

        /* EMPTY */
        .empty-card { background: rgba(255,255,255,0.97); border-radius: 16px; padding: 48px 20px; text-align: center; box-shadow: 0 6px 28px rgba(0,0,0,0.14); }
        .empty-card .ei { font-size: 52px; margin-bottom: 14px; }
        .empty-card p { color: #aaa; font-size: 15px; }

        /* EDIT MODAL */
        .modal-overlay { display: none; position: fixed; inset: 0; z-index: 500; background: rgba(0,0,0,0.55); backdrop-filter: blur(4px); align-items: center; justify-content: center; padding: 20px; }
        .modal-overlay.open { display: flex; }
        .modal-box { background: #fff; border-radius: 16px; width: 100%; max-width: 480px; box-shadow: 0 24px 60px rgba(0,0,0,0.30); overflow: hidden; animation: mIn 0.22s ease; }
        @keyframes mIn { from { transform: translateY(24px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal-head { padding: 18px 24px; background: linear-gradient(135deg,#667eea,#764ba2); display: flex; align-items: center; justify-content: space-between; }
        .modal-head h3 { font-size: 16px; font-weight: 800; color: #fff; }
        .modal-close { background: rgba(255,255,255,0.20); border: none; color: #fff; width: 30px; height: 30px; border-radius: 50%; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
        .modal-close:hover { background: rgba(255,255,255,0.35); }
        .modal-body { padding: 22px 24px; }
        .modal-body .form-group { margin-bottom: 16px; }
        .modal-body .form-group:last-child { margin-bottom: 0; }
        .btn-update { width: 100%; padding: 12px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; margin-top: 16px; }

        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 22px; font-size: 13px; }

        @media (max-width: 900px) { .layout { grid-template-columns: 1fr; } }
        @media (max-width: 600px) { header nav { padding: 0 16px; } .hero { padding: 40px 20px; } .hero h1 { font-size: 26px; } main { padding: 24px 16px 50px; } .notes-grid { grid-template-columns: 1fr 1fr; } }
        @media (max-width: 420px) { .notes-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php">Budget</a></li>
            <li><a href="packing.php">Packing</a></li>
            <li><a href="itinerary.php">Itinerary</a></li>
            <li><a href="notes.php" class="active">Notes</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<div class="hero">
    <div class="hero-badge">📝 Trip Notes</div>
    <h1>Your Travel Notes</h1>
    <p>Capture ideas, tips, reminders and memories for every trip</p>
</div>

<main>
    <?php if ($msg): ?>
        <div class="alert alert-<?php echo $msg_type; ?>"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="layout">

        <!-- ── LEFT: Add Note Form ── -->
        <div>
            <div class="form-card">
                <div class="form-card-header">
                    <h3>📝 New Note</h3>
                </div>
                <?php if (!empty($user_trips)): ?>
                <form method="POST" action="" class="form-body">
                    <input type="hidden" name="add_note" value="1">

                    <div class="form-group">
                        <label>Trip</label>
                        <select name="trip_id" required>
                            <option value="">— Select Trip —</option>
                            <?php foreach ($user_trips as $t): ?>
                                <option value="<?php echo (int)$t['id']; ?>">
                                    <?php echo htmlspecialchars($t['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="title" placeholder="e.g. Things to try in Tokyo"
                               required maxlength="200">
                    </div>

                    <div class="form-group">
                        <label>Note</label>
                        <textarea name="content" placeholder="Write your note here…" required></textarea>
                    </div>

                    <button type="submit" class="btn-save">💾 Save Note</button>
                </form>
                <?php else: ?>
                <div style="padding:32px 24px; text-align:center; color:#aaa;">
                    <div style="font-size:40px;margin-bottom:12px;">🗺️</div>
                    <p>Create a trip first to add notes!</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ── RIGHT: Notes Grid ── -->
        <div>
            <div class="sec-title">📒 All Notes</div>

            <?php if (!empty($notes_by_trip)): ?>
                <?php foreach ($notes_by_trip as $trip_id => $trip_data):
                    $notes = $trip_data['notes'];
                ?>
                <div class="trip-section">
                    <div class="trip-label">
                        🗺️ <?php echo htmlspecialchars($trip_data['name']); ?>
                        <span><?php echo count($notes); ?> note<?php echo count($notes) !== 1 ? 's' : ''; ?></span>
                    </div>
                    <div class="notes-grid">
                        <?php foreach ($notes as $idx => $note):
                            $bg = $note_colors[$idx % count($note_colors)];
                            $updated = !empty($note['updated_at'])
                                ? date('M j, Y', strtotime($note['updated_at']))
                                : '';
                        ?>
                        <div class="note-card" style="background:<?php echo $bg; ?>;">
                            <div class="note-card-title"><?php echo htmlspecialchars($note['title']); ?></div>
                            <div class="note-card-content"><?php echo nl2br(htmlspecialchars($note['content'])); ?></div>
                            <div class="note-card-footer">
                                <span class="note-date"><?php echo $updated; ?></span>
                                <div class="note-actions">
                                    <button class="btn-edit" onclick="openEdit(
                                        <?php echo (int)$note['id']; ?>,
                                        '<?php echo htmlspecialchars(addslashes($note['title']), ENT_QUOTES); ?>',
                                        '<?php echo htmlspecialchars(addslashes($note['content']), ENT_QUOTES); ?>'
                                    )">✏️ Edit</button>
                                    <form method="POST" action="" style="display:inline;">
                                        <input type="hidden" name="delete_note" value="1">
                                        <input type="hidden" name="note_id" value="<?php echo (int)$note['id']; ?>">
                                        <button type="submit" class="btn-del"
                                                onclick="return confirm('Delete this note?')">🗑️</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>

            <?php else: ?>
                <div class="empty-card">
                    <div class="ei">📝</div>
                    <p>No notes yet.<br>Add your first note from the form!</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<!-- ── EDIT MODAL ── -->
<div class="modal-overlay" id="edit-modal" onclick="closeEditOnBg(event)">
    <div class="modal-box">
        <div class="modal-head">
            <h3>✏️ Edit Note</h3>
            <button class="modal-close" onclick="closeEdit()">✕</button>
        </div>
        <form method="POST" action="" class="modal-body">
            <input type="hidden" name="edit_note" value="1">
            <input type="hidden" name="note_id" id="edit-note-id">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="edit_title" id="edit-title" required maxlength="200">
            </div>
            <div class="form-group">
                <label>Note</label>
                <textarea name="edit_content" id="edit-content" style="min-height:140px;" required></textarea>
            </div>
            <button type="submit" class="btn-update">💾 Update Note</button>
        </form>
    </div>
</div>

<footer><p>© 2026 Travel Planner. All rights reserved.</p></footer>

<script>
function openEdit(id, title, content) {
    document.getElementById('edit-note-id').value  = id;
    document.getElementById('edit-title').value    = title;
    document.getElementById('edit-content').value  = content;
    document.getElementById('edit-modal').classList.add('open');
}
function closeEdit() {
    document.getElementById('edit-modal').classList.remove('open');
}
function closeEditOnBg(e) {
    if (e.target === document.getElementById('edit-modal')) closeEdit();
}
</script>
</body>
</html>