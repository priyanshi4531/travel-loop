<?php
$page_title = 'Itinerary Builder';
require_once 'includes/header.php';
requireLogin();
?>

<h1>Itinerary Builder</h1>
<p>Build your custom itinerary here.</p>

<?php require_once 'includes/footer.php'; ?>
