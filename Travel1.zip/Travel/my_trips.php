<?php
$page_title = 'My Trips';
require_once 'includes/auth.php';
require_once 'includes/db.php';

requireLogin();

$user_id = $_SESSION['user_id'];

// Fetch all trips for the logged-in user
$stmt = $conn->prepare("SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$trips = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Travel Planner</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
            min-height: 100vh;
        }
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .page-header h1 {
            color: white;
            margin: 0;
            font-size: 28px;
        }
        .page-header p {
            opacity: 0.9;
            font-size: 14px;
            margin: 5px 0 0;
        }
        .btn-create {
            background: white;
            color: #667eea;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
            transition: transform 0.2s, box-shadow 0.2s;
            white-space: nowrap;
        }
        .btn-create:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .trips-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }
        .trip-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
        }
        .trip-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }
        .trip-cover {
            width: 100%;
            height: 180px;
            object-fit: cover;
            display: block;
        }
        .trip-cover-placeholder {
            width: 100%;
            height: 180px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
        }
        .trip-body {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .trip-name {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            margin: 0 0 8px;
        }
        .trip-description {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 12px;
            flex: 1;
            /* Clamp to 3 lines */
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .trip-dates {
            font-size: 13px;
            color: #888;
            margin-bottom: 12px;
        }
        .trip-dates span {
            margin-right: 12px;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 16px;
        }
        .status-draft     { background: #fff3cd; color: #856404; }
        .status-published { background: #d4edda; color: #155724; }
        .status-shared    { background: #d1ecf1; color: #0c5460; }
        .trip-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .btn-sm {
            padding: 7px 14px;
            border-radius: 5px;
            font-size: 13px;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.2s;
            display: inline-block;
        }
        .btn-sm:hover { opacity: 0.85; }
        .btn-view   { background: #667eea; color: white; }
        .btn-edit   { background: #f39c12; color: white; }
        .btn-delete {
            background: #e74c3c;
            color: white;
            border: none;
            cursor: pointer;
            font-family: inherit;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .empty-state .empty-icon {
            font-size: 64px;
            margin-bottom: 16px;
        }
        .empty-state h2 {
            color: #2c3e50;
            margin-bottom: 8px;
        }
        .empty-state p {
            color: #888;
            margin-bottom: 24px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            transition: transform 0.2s;
        }
        .btn-primary:hover { transform: translateY(-2px); }

        @media (max-width: 600px) {
            .page-header { flex-direction: column; align-items: flex-start; }
            .trips-grid  { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">✈️ Travel Planner</div>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="my_trips.php">My Trips</a></li>
                <li><a href="profile.php">Profile</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin/index.php">Admin</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1>🗺️ My Trips</h1>
                <p>All your travel adventures in one place</p>
            </div>
            <a href="create trip.php" class="btn-create">+ New Trip</a>
        </div>

        <?php if ($trips->num_rows > 0): ?>
            <div class="trips-grid">
                <?php while ($trip = $trips->fetch_assoc()): ?>
                    <div class="trip-card">
                        <!-- Cover photo or placeholder -->
                        <?php if (!empty($trip['cover_photo']) && file_exists('assets/uploads/' . $trip['cover_photo'])): ?>
                            <img
                                src="assets/uploads/<?php echo htmlspecialchars($trip['cover_photo']); ?>"
                                alt="<?php echo htmlspecialchars($trip['name']); ?>"
                                class="trip-cover"
                            >
                        <?php else: ?>
                            <div class="trip-cover-placeholder">🌍</div>
                        <?php endif; ?>

                        <div class="trip-body">
                            <div class="trip-name"><?php echo htmlspecialchars($trip['name']); ?></div>

                            <?php if (!empty($trip['description'])): ?>
                                <div class="trip-description"><?php echo htmlspecialchars($trip['description']); ?></div>
                            <?php endif; ?>

                            <div class="trip-dates">
                                <?php if (!empty($trip['start_date'])): ?>
                                    <span>📅 <?php echo date('M d, Y', strtotime($trip['start_date'])); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($trip['end_date'])): ?>
                                    <span>→ <?php echo date('M d, Y', strtotime($trip['end_date'])); ?></span>
                                <?php endif; ?>
                            </div>

                            <?php if (!empty($trip['status'])): ?>
                                <span class="status-badge status-<?php echo htmlspecialchars($trip['status']); ?>">
                                    <?php echo ucfirst(htmlspecialchars($trip['status'])); ?>
                                </span>
                            <?php endif; ?>

                            <div class="trip-actions">
                                <a href="trip-detail.php?id=<?php echo (int)$trip['id']; ?>" class="btn-sm btn-view">View</a>
                                <a href="edit-trip.php?id=<?php echo (int)$trip['id']; ?>" class="btn-sm btn-edit">Edit</a>
                                <form method="POST" action="delete_trip.php" style="display:inline;"
                                      onsubmit="return confirm('Delete this trip? This cannot be undone.');">
                                    <input type="hidden" name="trip_id" value="<?php echo (int)$trip['id']; ?>">
                                    <button type="submit" class="btn-sm btn-delete">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🧳</div>
                <h2>No trips yet</h2>
                <p>Start planning your first adventure!</p>
                <a href="create trip.php" class="btn-primary">Create Your First Trip</a>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
    </footer>
    <script src="assets/js/main.js"></script>
</body>
</html>
