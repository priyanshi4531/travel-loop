<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email    = sanitizeInput($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email and password are required.';
    } else {
        $stmt = $conn->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['is_admin']  = ($user['role'] === 'admin');
                header('Location: dashboard.php');
                exit();
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'Invalid email or password.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login – Travel Planner</title>
    <style>
        /* ── shared auth styles ── */
        <?php include 'includes/auth-styles.css.php'; ?>

        /* login keeps centered card with padding */
        body { padding: 32px 16px; }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="auth-brand">
            <span class="brand-icon">✈️</span>
            <h1>Welcome Back</h1>
            <p>Sign in to continue your journey</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="" novalidate>
            <div class="form-group">
                <label for="email">📧 Email Address</label>
                <input type="email" id="email" name="email"
                       placeholder="you@example.com" required
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="password">🔒 Password</label>
                <div class="pw-wrap">
                    <input type="password" id="password" name="password"
                           placeholder="Your password" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('password',this)">👁️</button>
                </div>
            </div>
            <button type="submit" class="btn-auth">Login &nbsp;→</button>
        </form>

        <div class="divider"><span>or</span></div>

        <p class="auth-footer">Don't have an account? <a href="signup.php">Sign up here</a></p>
        <p class="auth-footer" style="margin-top:10px;">
            <a href="admin-login.php" style="color:rgba(255,255,255,0.35);font-size:12px;">Admin? Login here →</a>
        </p>
    </div>
    <script>
        function togglePw(id, btn) {
            const inp = document.getElementById(id);
            inp.type = inp.type === 'password' ? 'text' : 'password';
            btn.textContent = inp.type === 'password' ? '👁️' : '🙈';
        }
    </script>
</body>
</html>
