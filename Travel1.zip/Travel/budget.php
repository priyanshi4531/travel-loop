<?php
$page_title = 'Budget Planner';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];

// ── Static transport options per city ──────────────────────────────
$transport_options = [
    'Paris'     => [
        ['type'=>'✈️ Flight',    'from'=>'CDG Airport',   'to'=>'City Centre',  'price'=>18,  'duration'=>'45 min'],
        ['type'=>'🚇 Metro',     'from'=>'Any Station',   'to'=>'Any Station',  'price'=>2,   'duration'=>'20 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Hotel',        'price'=>55,  'duration'=>'40 min'],
        ['type'=>'🚌 Bus',       'from'=>'Gare du Nord',  'to'=>'Eiffel Tower', 'price'=>2,   'duration'=>'35 min'],
        ['type'=>'🛵 Scooter',   'from'=>'Rental Shop',   'to'=>'Self Drive',   'price'=>30,  'duration'=>'Per day'],
    ],
    'Tokyo'     => [
        ['type'=>'✈️ Flight',    'from'=>'Narita Airport','to'=>'Shinjuku',     'price'=>14,  'duration'=>'90 min'],
        ['type'=>'🚄 Shinkansen','from'=>'Tokyo Stn',     'to'=>'Osaka',        'price'=>130, 'duration'=>'2.5 hrs'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Hotel',        'price'=>200, 'duration'=>'60 min'],
        ['type'=>'🚌 Bus',       'from'=>'Shibuya',       'to'=>'Asakusa',      'price'=>3,   'duration'=>'40 min'],
        ['type'=>'🚇 Metro',     'from'=>'Any Station',   'to'=>'Any Station',  'price'=>2,   'duration'=>'15 min'],
    ],
    'New York'  => [
        ['type'=>'✈️ Flight',    'from'=>'JFK Airport',   'to'=>'Manhattan',    'price'=>18,  'duration'=>'60 min'],
        ['type'=>'🚇 Subway',    'from'=>'Any Station',   'to'=>'Any Station',  'price'=>3,   'duration'=>'25 min'],
        ['type'=>'🚕 Yellow Cab','from'=>'Times Square',  'to'=>'Central Park', 'price'=>15,  'duration'=>'10 min'],
        ['type'=>'🚌 Bus',       'from'=>'Port Authority','to'=>'Brooklyn',     'price'=>3,   'duration'=>'45 min'],
        ['type'=>'🚲 Citi Bike', 'from'=>'Dock Station',  'to'=>'Self Ride',    'price'=>4,   'duration'=>'Per ride'],
    ],
    'Rome'      => [
        ['type'=>'✈️ Flight',    'from'=>'FCO Airport',   'to'=>'Termini Stn',  'price'=>14,  'duration'=>'35 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Colosseum',    'price'=>48,  'duration'=>'45 min'],
        ['type'=>'🚌 Bus',       'from'=>'Termini',       'to'=>'Vatican',      'price'=>2,   'duration'=>'30 min'],
        ['type'=>'🛵 Vespa',     'from'=>'Rental Shop',   'to'=>'Self Drive',   'price'=>40,  'duration'=>'Per day'],
        ['type'=>'🚶 Walking',   'from'=>'Hotel',         'to'=>'City Centre',  'price'=>0,   'duration'=>'20 min'],
    ],
    'Bali'      => [
        ['type'=>'✈️ Flight',    'from'=>'DPS Airport',   'to'=>'Kuta',         'price'=>10,  'duration'=>'30 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Ubud',         'price'=>25,  'duration'=>'60 min'],
        ['type'=>'🛵 Scooter',   'from'=>'Rental Shop',   'to'=>'Self Drive',   'price'=>8,   'duration'=>'Per day'],
        ['type'=>'🚌 Shuttle',   'from'=>'Kuta',          'to'=>'Seminyak',     'price'=>5,   'duration'=>'20 min'],
        ['type'=>'🚗 Private Car','from'=>'Hotel',        'to'=>'Any Spot',     'price'=>40,  'duration'=>'Per day'],
    ],
    'London'    => [
        ['type'=>'✈️ Flight',    'from'=>'Heathrow',      'to'=>'Paddington',   'price'=>12,  'duration'=>'25 min'],
        ['type'=>'🚇 Tube',      'from'=>'Any Station',   'to'=>'Any Station',  'price'=>3,   'duration'=>'20 min'],
        ['type'=>'🚕 Black Cab', 'from'=>'Trafalgar Sq',  'to'=>'Tower Bridge', 'price'=>18,  'duration'=>'15 min'],
        ['type'=>'🚌 Red Bus',   'from'=>'Victoria',      'to'=>'Oxford St',    'price'=>2,   'duration'=>'30 min'],
        ['type'=>'🚲 Santander', 'from'=>'Dock Station',  'to'=>'Self Ride',    'price'=>3,   'duration'=>'Per ride'],
    ],
    'Barcelona' => [
        ['type'=>'✈️ Flight',    'from'=>'BCN Airport',   'to'=>'City Centre',  'price'=>5,   'duration'=>'35 min'],
        ['type'=>'🚇 Metro',     'from'=>'Any Station',   'to'=>'Any Station',  'price'=>2,   'duration'=>'20 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Hotel',        'price'=>35,  'duration'=>'30 min'],
        ['type'=>'🚌 Bus',       'from'=>'Sagrada Fam.',  'to'=>'Beach',        'price'=>2,   'duration'=>'25 min'],
        ['type'=>'🛵 Scooter',   'from'=>'Rental Shop',   'to'=>'Self Drive',   'price'=>25,  'duration'=>'Per day'],
    ],
    'Dubai'     => [
        ['type'=>'✈️ Flight',    'from'=>'DXB Airport',   'to'=>'Downtown',     'price'=>3,   'duration'=>'30 min'],
        ['type'=>'🚇 Metro',     'from'=>'Any Station',   'to'=>'Any Station',  'price'=>2,   'duration'=>'20 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Burj Khalifa', 'price'=>20,  'duration'=>'25 min'],
        ['type'=>'🚌 Bus',       'from'=>'Gold Souk',     'to'=>'Mall of UAE',  'price'=>1,   'duration'=>'40 min'],
        ['type'=>'🚗 Luxury Car','from'=>'Hotel',         'to'=>'Desert Safari','price'=>80,  'duration'=>'Per day'],
    ],
    'Sydney'    => [
        ['type'=>'✈️ Flight',    'from'=>'SYD Airport',   'to'=>'City Centre',  'price'=>18,  'duration'=>'30 min'],
        ['type'=>'🚢 Ferry',     'from'=>'Circular Quay', 'to'=>'Manly Beach',  'price'=>8,   'duration'=>'30 min'],
        ['type'=>'🚕 Cab',       'from'=>'Airport',       'to'=>'Hotel',        'price'=>45,  'duration'=>'35 min'],
        ['type'=>'🚌 Bus',       'from'=>'CBD',           'to'=>'Bondi Beach',  'price'=>4,   'duration'=>'40 min'],
        ['type'=>'🚇 Train',     'from'=>'Central Stn',   'to'=>'Any Station',  'price'=>4,   'duration'=>'25 min'],
    ],
    'Bangkok'   => [
        ['type'=>'✈️ Flight',    'from'=>'BKK Airport',   'to'=>'City Centre',  'price'=>8,   'duration'=>'45 min'],
        ['type'=>'🛺 Tuk-Tuk',   'from'=>'Grand Palace',  'to'=>'Wat Pho',      'price'=>3,   'duration'=>'10 min'],
        ['type'=>'🚕 Grab Cab',  'from'=>'Hotel',         'to'=>'Chatuchak',    'price'=>6,   'duration'=>'30 min'],
        ['type'=>'🚌 Bus',       'from'=>'Silom',         'to'=>'Khao San Rd',  'price'=>1,   'duration'=>'35 min'],
        ['type'=>'🚇 BTS Skytrain','from'=>'Any Station', 'to'=>'Any Station',  'price'=>2,   'duration'=>'15 min'],
    ],
];

// ── Static hotel data per city ──────────────────────────────────────
$hotels_data = [
    'Paris'     => [
        ['name'=>'Le Meurice',           'stars'=>5,'price'=>950,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Spa · Pool · Fine Dining'],
        ['name'=>'Hotel Lutetia',         'stars'=>5,'price'=>720,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Bar · Gym · Concierge'],
        ['name'=>'Hôtel du Louvre',       'stars'=>4,'price'=>380,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Restaurant · WiFi · Parking'],
        ['name'=>'Ibis Paris Centre',     'stars'=>3,'price'=>120,'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Breakfast · AC'],
        ['name'=>'Generator Paris',       'stars'=>2,'price'=>45, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Bar · Lockers'],
    ],
    'Tokyo'     => [
        ['name'=>'The Peninsula Tokyo',   'stars'=>5,'price'=>880,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Spa · Pool · Rooftop Bar'],
        ['name'=>'Park Hyatt Tokyo',      'stars'=>5,'price'=>750,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Pool · Gym · Fine Dining'],
        ['name'=>'Shinjuku Granbell',     'stars'=>4,'price'=>220,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Bar · WiFi · City View'],
        ['name'=>'APA Hotel Shinjuku',    'stars'=>3,'price'=>90, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Onsen · Breakfast'],
        ['name'=>'Khaosan Tokyo Hostel',  'stars'=>1,'price'=>28, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Lounge · Lockers'],
    ],
    'New York'  => [
        ['name'=>'The Plaza Hotel',       'stars'=>5,'price'=>1100,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Spa · Fine Dining · Concierge'],
        ['name'=>'Four Seasons NY',       'stars'=>5,'price'=>950,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Pool · Gym · Bar'],
        ['name'=>'Marriott Times Square', 'stars'=>4,'price'=>320,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Restaurant · WiFi · Gym'],
        ['name'=>'Pod 51 Hotel',          'stars'=>3,'price'=>130,'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Rooftop · AC'],
        ['name'=>'HI NYC Hostel',         'stars'=>1,'price'=>55, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Kitchen · Lockers'],
    ],
    'Rome'      => [
        ['name'=>'Hotel de Russie',       'stars'=>5,'price'=>820,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Spa · Garden · Fine Dining'],
        ['name'=>'Hassler Roma',          'stars'=>5,'price'=>700,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Rooftop Bar · Gym · Pool'],
        ['name'=>'Hotel Artemide',        'stars'=>4,'price'=>210,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Restaurant · WiFi · Spa'],
        ['name'=>'Hotel Navona',          'stars'=>3,'price'=>95, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Breakfast · AC'],
        ['name'=>'The Yellow Hostel',     'stars'=>1,'price'=>30, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Bar · Tours'],
    ],
    'Bali'      => [
        ['name'=>'Four Seasons Jimbaran', 'stars'=>5,'price'=>680,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Private Pool · Spa · Beach'],
        ['name'=>'COMO Uma Ubud',         'stars'=>5,'price'=>520,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Infinity Pool · Yoga · Dining'],
        ['name'=>'Alaya Resort Ubud',     'stars'=>4,'price'=>180,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Pool · Spa · Restaurant'],
        ['name'=>'Kuta Paradiso Hotel',   'stars'=>3,'price'=>65, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'Pool · WiFi · Breakfast'],
        ['name'=>'Puri Garden Hostel',    'stars'=>1,'price'=>15, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Garden · Kitchen'],
    ],
    'London'    => [
        ['name'=>'The Savoy',             'stars'=>5,'price'=>900,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Spa · Fine Dining · Thames View'],
        ['name'=>'Claridge\'s',           'stars'=>5,'price'=>780,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Bar · Gym · Concierge'],
        ['name'=>'Marriott Grosvenor Sq', 'stars'=>4,'price'=>280,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Restaurant · WiFi · Gym'],
        ['name'=>'Travelodge London',     'stars'=>3,'price'=>90, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · AC · 24hr Reception'],
        ['name'=>'St Christopher\'s Inn', 'stars'=>1,'price'=>35, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Bar · Lockers'],
    ],
    'Barcelona' => [
        ['name'=>'Hotel Arts Barcelona',  'stars'=>5,'price'=>750,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Pool · Spa · Sea View'],
        ['name'=>'W Barcelona',           'stars'=>5,'price'=>620,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Rooftop Pool · Bar · Beach'],
        ['name'=>'Hotel Catalonia',       'stars'=>4,'price'=>190,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Pool · Restaurant · WiFi'],
        ['name'=>'Hostal Grau',           'stars'=>3,'price'=>80, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Breakfast · AC'],
        ['name'=>'Kabul Party Hostel',    'stars'=>1,'price'=>22, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Rooftop · Bar'],
    ],
    'Dubai'     => [
        ['name'=>'Burj Al Arab',          'stars'=>5,'price'=>2200,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Private Beach · Helipad · Butler'],
        ['name'=>'Atlantis The Palm',     'stars'=>5,'price'=>900,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Waterpark · Beach · Aquarium'],
        ['name'=>'JW Marriott Marquis',   'stars'=>5,'price'=>420,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Pool · Spa · Fine Dining'],
        ['name'=>'Rove Downtown Dubai',   'stars'=>3,'price'=>95, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'Pool · WiFi · Gym'],
        ['name'=>'Dubai Youth Hostel',    'stars'=>1,'price'=>30, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · AC · Kitchen'],
    ],
    'Sydney'    => [
        ['name'=>'Park Hyatt Sydney',     'stars'=>5,'price'=>820,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'Harbour View · Pool · Spa'],
        ['name'=>'Four Seasons Sydney',   'stars'=>5,'price'=>680,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Pool · Gym · Fine Dining'],
        ['name'=>'Novotel Sydney',        'stars'=>4,'price'=>220,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Restaurant · WiFi · Gym'],
        ['name'=>'Ibis Sydney Airport',   'stars'=>3,'price'=>110,'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'WiFi · Shuttle · AC'],
        ['name'=>'Sydney Harbour YHA',    'stars'=>1,'price'=>40, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · Harbour View · Kitchen'],
    ],
    'Bangkok'   => [
        ['name'=>'Mandarin Oriental BKK', 'stars'=>5,'price'=>750,'img'=>'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70','amenities'=>'River View · Spa · Fine Dining'],
        ['name'=>'The Peninsula Bangkok', 'stars'=>5,'price'=>620,'img'=>'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&q=70','amenities'=>'Pool · Gym · Helipad'],
        ['name'=>'Chatrium Hotel',        'stars'=>4,'price'=>160,'img'=>'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&q=70','amenities'=>'Pool · Restaurant · WiFi'],
        ['name'=>'Lub d Bangkok',         'stars'=>3,'price'=>55, 'img'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&q=70','amenities'=>'Pool · WiFi · Bar'],
        ['name'=>'NapPark Hostel',        'stars'=>1,'price'=>12, 'img'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=70','amenities'=>'Hostel · AC · Lockers'],
    ],
];

// Fetch user trips for budget selector
$trips_stmt = $conn->prepare("SELECT id, name, start_date, end_date FROM trips WHERE user_id = ? ORDER BY created_at DESC");
$trips_stmt->bind_param("i", $user_id);
$trips_stmt->execute();
$user_trips = $trips_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$trips_stmt->close();

// Fetch all cities
$cities_stmt = $conn->prepare("SELECT id, name, country FROM cities ORDER BY name ASC");
$cities_stmt->execute();
$all_cities = $cities_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$cities_stmt->close();

// Fetch budget items for user's trips
$budget_stmt = $conn->prepare(
    "SELECT bi.*, t.name AS trip_name FROM budget_items bi
     JOIN trips t ON bi.trip_id = t.id
     WHERE t.user_id = ?
     ORDER BY bi.trip_id, bi.category"
);
$budget_stmt->bind_param("i", $user_id);
$budget_stmt->execute();
$budget_items = $budget_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$budget_stmt->close();

// Group budget items by trip
$budget_by_trip = [];
foreach ($budget_items as $item) {
    $budget_by_trip[$item['trip_id']]['name']    = $item['trip_name'];
    $budget_by_trip[$item['trip_id']]['items'][] = $item;
}

// Handle add budget item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_budget'])) {
    $trip_id       = (int)($_POST['trip_id'] ?? 0);
    $category      = sanitizeInput($_POST['category'] ?? 'other');
    $description   = sanitizeInput($_POST['description'] ?? '');
    $estimated     = floatval($_POST['estimated_cost'] ?? 0);
    $actual        = !empty($_POST['actual_cost']) ? floatval($_POST['actual_cost']) : null;
    $currency      = sanitizeInput($_POST['currency'] ?? 'USD');

    // Verify trip belongs to user
    $chk = $conn->prepare("SELECT id FROM trips WHERE id = ? AND user_id = ?");
    $chk->bind_param("ii", $trip_id, $user_id);
    $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        $ins = $conn->prepare("INSERT INTO budget_items (trip_id,category,description,estimated_cost,actual_cost,currency) VALUES (?,?,?,?,?,?)");
        $ins->bind_param("issdds", $trip_id, $category, $description, $estimated, $actual, $currency);
        $ins->execute();
        $ins->close();
    }
    $chk->close();
    header('Location: budget.php');
    exit();
}

// Handle delete budget item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_item'])) {
    $item_id = (int)$_POST['item_id'];
    $del = $conn->prepare("DELETE bi FROM budget_items bi JOIN trips t ON bi.trip_id=t.id WHERE bi.id=? AND t.user_id=?");
    $del->bind_param("ii", $item_id, $user_id);
    $del->execute();
    $del->close();
    header('Location: budget.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Planner – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            color: #1a1a2e;
            min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.60), rgba(8,12,35,0.60)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* ── NAV ── */
        header { background: #0f172a; box-shadow: 0 2px 20px rgba(0,0,0,0.35); position: sticky; top: 0; z-index: 200; }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 8px; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-menu .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2); color: #fff !important; padding: 8px 16px; }
        .nav-menu .nav-cta a:hover { opacity: 0.88; }

        /* ── HERO ── */
        .hero {
            position: relative; overflow: hidden;
            background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 64px 40px 56px;
        }
        .hero-inner { max-width: 1200px; margin: 0 auto; text-align: center; }
        .hero-badge { display: inline-block; background: rgba(102,126,234,0.25); border: 1px solid rgba(102,126,234,0.45); color: #a5b4fc; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 6px 16px; border-radius: 20px; margin-bottom: 18px; }
        .hero-title { font-size: 42px; font-weight: 900; color: #fff; line-height: 1.15; margin-bottom: 14px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); }
        .hero-sub { font-size: 16px; color: rgba(255,255,255,0.62); max-width: 520px; margin: 0 auto; }

        /* ── MAIN WRAPPER ── */
        .page-main { max-width: 1200px; margin: 0 auto; padding: 40px 24px 70px; }

        /* ── CITY SELECTOR ── */
        .city-selector { margin-bottom: 32px; }
        .city-selector-label { font-size: 13px; font-weight: 700; color: rgba(255,255,255,0.55); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
        .city-pills { display: flex; flex-wrap: wrap; gap: 10px; }
        .city-pill {
            padding: 9px 20px; border-radius: 30px; border: 1.5px solid rgba(255,255,255,0.22);
            background: rgba(255,255,255,0.10); color: rgba(255,255,255,0.80);
            font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s;
            backdrop-filter: blur(8px);
        }
        .city-pill:hover { background: rgba(255,255,255,0.18); border-color: rgba(255,255,255,0.40); color: #fff; }
        .city-pill.active { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; color: #fff; box-shadow: 0 4px 14px rgba(102,126,234,0.45); }

        /* ── SECTION HEADER ── */
        .sec-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .sec-title { font-size: 20px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 10px; text-shadow: 0 1px 6px rgba(0,0,0,0.4); }
        .sec-badge { background: rgba(255,255,255,0.15); color: rgba(255,255,255,0.75); font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 12px; }

        /* ── CITY SECTION WRAPPER ── */
        .city-section { display: none; }
        .city-section.active { display: block; }

        /* ── HOTEL GRID ── */
        .hotels-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px; }
        .hotel-card {
            background: #fff; border-radius: 14px; overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.12); transition: transform 0.25s, box-shadow 0.25s;
        }
        .hotel-card:hover { transform: translateY(-5px); box-shadow: 0 12px 32px rgba(0,0,0,0.18); }
        .hotel-img { width: 100%; height: 180px; object-fit: cover; display: block; }
        .hotel-body { padding: 16px 18px 18px; }
        .hotel-stars { color: #f59e0b; font-size: 14px; margin-bottom: 6px; letter-spacing: 1px; }
        .hotel-name { font-size: 16px; font-weight: 800; color: #1a1a2e; margin-bottom: 6px; line-height: 1.3; }
        .hotel-price { font-size: 18px; font-weight: 800; color: #667eea; margin-bottom: 8px; }
        .hotel-price span { font-size: 13px; font-weight: 500; color: #888; }
        .hotel-amenities { font-size: 12px; color: #888; margin-bottom: 14px; line-height: 1.5; }
        .btn-book {
            display: block; width: 100%; padding: 10px; text-align: center;
            background: linear-gradient(135deg,#667eea,#764ba2); color: #fff;
            border: none; border-radius: 8px; font-size: 14px; font-weight: 700;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
        }
        .btn-book:hover { opacity: 0.88; transform: translateY(-1px); }

        /* ── TRANSPORT SECTION ── */
        .transport-section { margin-bottom: 48px; }
        .filter-pills { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 22px; }
        .filter-pill {
            padding: 7px 16px; border-radius: 24px; border: 1.5px solid rgba(255,255,255,0.22);
            background: rgba(255,255,255,0.10); color: rgba(255,255,255,0.75);
            font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s;
            backdrop-filter: blur(6px);
        }
        .filter-pill:hover { background: rgba(255,255,255,0.18); color: #fff; }
        .filter-pill.active { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; color: #fff; box-shadow: 0 3px 10px rgba(102,126,234,0.40); }
        .transport-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
        .transport-card {
            background: #fff; border-radius: 14px; padding: 22px 16px 18px;
            text-align: center; box-shadow: 0 4px 16px rgba(0,0,0,0.10);
            transition: transform 0.22s, box-shadow 0.22s;
        }
        .transport-card:hover { transform: translateY(-4px); box-shadow: 0 10px 28px rgba(0,0,0,0.15); }
        .transport-card.hidden { display: none; }
        .transport-icon { font-size: 40px; margin-bottom: 10px; display: block; line-height: 1; }
        .transport-type { font-size: 13px; font-weight: 700; color: #667eea; margin-bottom: 6px; }
        .transport-route { font-size: 13px; color: #444; font-weight: 600; margin-bottom: 6px; line-height: 1.4; }
        .transport-route .arrow { color: #aaa; margin: 0 4px; }
        .transport-duration { display: inline-block; background: #f0f4ff; color: #667eea; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 12px; margin-bottom: 10px; }
        .transport-price { font-size: 18px; font-weight: 800; color: #1a1a2e; margin-bottom: 12px; }
        .transport-price.free { color: #10b981; }
        .btn-select {
            display: block; width: 100%; padding: 8px; text-align: center;
            background: #f0f4ff; color: #667eea; border: 1.5px solid #c7d2fe;
            border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .btn-select:hover { background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border-color: transparent; }

        /* ── BUDGET TRACKER ── */
        .budget-section { margin-bottom: 60px; }
        .budget-card {
            background: rgba(255,255,255,0.97); border-radius: 16px;
            box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; margin-bottom: 28px;
        }
        .budget-card-header {
            padding: 20px 28px; border-bottom: 1px solid #f0f0f0;
            display: flex; align-items: center; justify-content: space-between;
        }
        .budget-card-header h3 { font-size: 17px; font-weight: 800; color: #1a1a2e; }
        .budget-form { padding: 24px 28px; }
        .form-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 16px; }
        .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group label { font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group select,
        .form-group input {
            padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 8px;
            font-size: 14px; color: #1a1a2e; font-family: inherit; transition: border-color 0.2s;
            background: #fafbff;
        }
        .form-group select:focus,
        .form-group input:focus { outline: none; border-color: #667eea; background: #fff; }
        .btn-add-budget {
            padding: 11px 28px; background: linear-gradient(135deg,#667eea,#764ba2);
            color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 700;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
        }
        .btn-add-budget:hover { opacity: 0.88; transform: translateY(-1px); }

        /* Budget table */
        .budget-trip-block { margin-bottom: 28px; }
        .budget-trip-name {
            font-size: 15px; font-weight: 800; color: #1a1a2e;
            padding: 14px 24px; background: #f8f9ff; border-bottom: 1px solid #eef0f8;
            display: flex; align-items: center; gap: 8px;
        }
        .budget-table { width: 100%; border-collapse: collapse; }
        .budget-table th {
            padding: 11px 20px; text-align: left; font-size: 11px; font-weight: 700;
            color: #888; text-transform: uppercase; letter-spacing: 0.5px;
            background: #fafbff; border-bottom: 1px solid #f0f0f0;
        }
        .budget-table td { padding: 13px 20px; border-bottom: 1px solid #f8f8f8; font-size: 14px; color: #444; vertical-align: middle; }
        .budget-table tbody tr:last-child td { border-bottom: none; }
        .budget-table tbody tr:hover td { background: #fafbff; }
        .cat-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;
        }
        .cat-flights    { background: #dbeafe; color: #1d4ed8; }
        .cat-hotels     { background: #ede9fe; color: #6d28d9; }
        .cat-food       { background: #fef3c7; color: #92400e; }
        .cat-activities { background: #d1fae5; color: #065f46; }
        .cat-transport  { background: #e0f2fe; color: #0369a1; }
        .cat-shopping   { background: #fce7f3; color: #9d174d; }
        .cat-other      { background: #f3f4f6; color: #374151; }
        .diff-under { color: #10b981; font-weight: 700; }
        .diff-over  { color: #ef4444; font-weight: 700; }
        .diff-na    { color: #aaa; }
        .btn-delete {
            padding: 5px 12px; background: #fee2e2; color: #dc2626;
            border: none; border-radius: 6px; font-size: 12px; font-weight: 700;
            cursor: pointer; transition: background 0.2s;
        }
        .btn-delete:hover { background: #fca5a5; }

        /* Empty state */
        .empty-state { padding: 48px 20px; text-align: center; }
        .empty-state .empty-icon { font-size: 52px; margin-bottom: 14px; }
        .empty-state p { color: #aaa; font-size: 15px; margin-bottom: 18px; }
        .btn-primary-link {
            display: inline-block; padding: 10px 24px;
            background: linear-gradient(135deg,#667eea,#764ba2); color: #fff;
            border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 700;
        }

        /* ── BOOKING MODAL ── */
        .modal-overlay {
            display: none; position: fixed; inset: 0; z-index: 1000;
            background: rgba(0,0,0,0.65); backdrop-filter: blur(4px);
            align-items: center; justify-content: center; padding: 20px;
        }
        .modal-overlay.open { display: flex; }
        .modal-box {
            background: #fff; border-radius: 18px; width: 100%; max-width: 480px;
            box-shadow: 0 24px 60px rgba(0,0,0,0.35); overflow: hidden;
            animation: modalIn 0.25s ease;
        }
        @keyframes modalIn {
            from { transform: translateY(30px) scale(0.97); opacity: 0; }
            to   { transform: translateY(0)    scale(1);    opacity: 1; }
        }
        .modal-header {
            padding: 22px 26px 18px;
            background: linear-gradient(135deg,#667eea,#764ba2);
            display: flex; align-items: flex-start; justify-content: space-between;
        }
        .modal-header-info h3 { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 4px; }
        .modal-header-info p  { font-size: 13px; color: rgba(255,255,255,0.75); }
        .modal-close {
            background: rgba(255,255,255,0.20); border: none; color: #fff;
            width: 32px; height: 32px; border-radius: 50%; font-size: 18px;
            cursor: pointer; display: flex; align-items: center; justify-content: center;
            transition: background 0.2s; flex-shrink: 0;
        }
        .modal-close:hover { background: rgba(255,255,255,0.35); }
        .modal-summary {
            display: flex; gap: 10px; flex-wrap: wrap;
            padding: 14px 26px; background: #f8f9ff; border-bottom: 1px solid #eef0f8;
        }
        .modal-tag {
            display: inline-flex; align-items: center; gap: 5px;
            background: #e0e7ff; color: #4338ca; font-size: 12px; font-weight: 700;
            padding: 4px 12px; border-radius: 20px;
        }
        .modal-body { padding: 22px 26px 26px; }
        .modal-field { margin-bottom: 16px; }
        .modal-field label {
            display: block; font-size: 12px; font-weight: 700; color: #555;
            text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 7px;
        }
        .modal-field input,
        .modal-field select {
            width: 100%; padding: 11px 14px; border: 1.5px solid #e5e7eb;
            border-radius: 9px; font-size: 14px; font-family: inherit; color: #1a1a2e;
            background: #fafbff; transition: border-color 0.2s;
        }
        .modal-field input:focus,
        .modal-field select:focus { outline: none; border-color: #667eea; background: #fff; }
        .modal-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .modal-price-row {
            display: flex; align-items: center; justify-content: space-between;
            background: #f0f4ff; border-radius: 10px; padding: 14px 18px; margin-bottom: 18px;
        }
        .modal-price-label { font-size: 13px; color: #555; font-weight: 600; }
        .modal-price-val   { font-size: 20px; font-weight: 900; color: #667eea; }
        .btn-confirm-book {
            width: 100%; padding: 14px; background: linear-gradient(135deg,#667eea,#764ba2);
            color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 800;
            cursor: pointer; transition: opacity 0.2s, transform 0.15s;
            letter-spacing: 0.3px;
        }
        .btn-confirm-book:hover { opacity: 0.88; transform: translateY(-1px); }

        /* Success state */
        .booking-success {
            display: none; text-align: center; padding: 36px 26px;
        }
        .booking-success .success-icon { font-size: 60px; margin-bottom: 14px; }
        .booking-success h3 { font-size: 20px; font-weight: 800; color: #1a1a2e; margin-bottom: 8px; }
        .booking-success p  { font-size: 14px; color: #666; margin-bottom: 22px; line-height: 1.6; }
        .btn-done {
            padding: 11px 32px; background: linear-gradient(135deg,#667eea,#764ba2);
            color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700;
            cursor: pointer;
        }

        /* ── FOOTER ── */
        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 24px; font-size: 13px; }

        /* ── RESPONSIVE ── */
        @media (max-width: 1024px) {
            .hotels-grid { grid-template-columns: repeat(2, 1fr); }
            .transport-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            header nav { padding: 0 16px; }
            .hero { padding: 44px 20px 40px; }
            .hero-title { font-size: 30px; }
            .page-main { padding: 28px 16px 50px; }
            .hotels-grid { grid-template-columns: repeat(2, 1fr); }
            .transport-grid { grid-template-columns: repeat(2, 1fr); }
            .form-row { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 520px) {
            .hotels-grid { grid-template-columns: 1fr; }
            .transport-grid { grid-template-columns: repeat(2, 1fr); }
            .form-row { grid-template-columns: 1fr; }
            .form-row-2 { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<!-- ===== NAVBAR ===== -->
<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my-trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php" class="active">Budget</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?>
            <li><a href="admin/index.php">Admin</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<!-- ===== HERO ===== -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-badge">💰 Budget Planner</div>
        <h1 class="hero-title">💰 Travel Budget Planner</h1>
        <p class="hero-sub">Hotels, Transport &amp; Budget tracking for every trip</p>
    </div>
</section>

<!-- ===== PAGE MAIN ===== -->
<div class="page-main">

    <!-- ── CITY SELECTOR ── -->
    <div class="city-selector">
        <div class="city-selector-label">🌍 Select a City</div>
        <div class="city-pills">
            <?php
            $city_keys = array_keys($transport_options);
            foreach ($city_keys as $idx => $city_name):
                $active_class = ($idx === 0) ? ' active' : '';
            ?>
            <button class="city-pill<?php echo $active_class; ?>"
                    onclick="showCity('<?php echo htmlspecialchars($city_name, ENT_QUOTES); ?>')">
                <?php echo htmlspecialchars($city_name); ?>
            </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── PER-CITY SECTIONS ── -->
    <?php foreach ($transport_options as $city_name => $transports):
        $is_first = ($city_name === $city_keys[0]);
        $hotels   = $hotels_data[$city_name] ?? [];
        $city_id  = 'city-' . preg_replace('/\s+/', '-', $city_name);
    ?>
    <div id="<?php echo htmlspecialchars($city_id); ?>"
         class="city-section<?php echo $is_first ? ' active' : ''; ?>">

        <!-- ── SECTION A: HOTELS ── -->
        <div class="sec-header">
            <h2 class="sec-title">🏨 Hotel Booking
                <span class="sec-badge">Price: High → Low</span>
            </h2>
        </div>
        <div class="hotels-grid">
            <?php foreach ($hotels as $hotel): ?>
            <div class="hotel-card">
                <img class="hotel-img"
                     src="<?php echo htmlspecialchars($hotel['img']); ?>"
                     alt="<?php echo htmlspecialchars($hotel['name']); ?>"
                     loading="lazy"
                     onerror="this.src='https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&q=70'">
                <div class="hotel-body">
                    <div class="hotel-stars">
                        <?php echo str_repeat('⭐', (int)$hotel['stars']); ?>
                    </div>
                    <div class="hotel-name"><?php echo htmlspecialchars($hotel['name']); ?></div>
                    <div class="hotel-price">
                        $<?php echo number_format($hotel['price']); ?>
                        <span>/ night</span>
                    </div>
                    <div class="hotel-amenities"><?php echo htmlspecialchars($hotel['amenities']); ?></div>
                    <button class="btn-book" onclick="openHotelModal(
                        '<?php echo htmlspecialchars(addslashes($hotel['name']), ENT_QUOTES); ?>',
                        '<?php echo str_repeat('⭐', (int)$hotel['stars']); ?>',
                        '$<?php echo number_format($hotel['price']); ?> / night',
                        '<?php echo htmlspecialchars(addslashes($hotel['amenities']), ENT_QUOTES); ?>',
                        '<?php echo htmlspecialchars(addslashes($city_name), ENT_QUOTES); ?>'
                    )">🏨 Book Now</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- ── SECTION B: TRANSPORT ── -->
        <div class="transport-section">
            <div class="sec-header">
                <h2 class="sec-title">🚌 Transport Options</h2>
            </div>

            <!-- Filter pills -->
            <div class="filter-pills" id="filter-<?php echo htmlspecialchars($city_id); ?>">
                <button class="filter-pill active" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'all', this)">All</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Flight', this)">✈️ Flight</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Cab', this)">🚕 Cab</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Bus', this)">🚌 Bus</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Metro', this)">🚇 Metro/Train</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Tuk', this)">🛺 Auto/Tuk-Tuk</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Express', this)">🚄 Express</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Scooter', this)">🛵 Scooter</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Bike', this)">🚲 Bike</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Ferry', this)">🚢 Ferry</button>
                <button class="filter-pill" onclick="filterTransport('<?php echo htmlspecialchars($city_id); ?>', 'Walk', this)">🚶 Walk</button>
            </div>

            <!-- Transport cards -->
            <div class="transport-grid" id="tgrid-<?php echo htmlspecialchars($city_id); ?>">
                <?php foreach ($transports as $t):
                    // Extract the text label from the emoji+text type string
                    $type_raw = $t['type'];
                    // Build a data-type attribute with the raw type for JS filtering
                ?>
                <div class="transport-card" data-type="<?php echo htmlspecialchars($type_raw); ?>">
                    <span class="transport-icon"><?php
                        // Extract just the emoji (first grapheme cluster)
                        preg_match('/^\X/u', $type_raw, $em);
                        echo isset($em[0]) ? htmlspecialchars($em[0]) : '🚗';
                    ?></span>
                    <div class="transport-type"><?php
                        // Strip leading emoji for the label
                        $label = trim(preg_replace('/^\X\s*/u', '', $type_raw));
                        echo htmlspecialchars($label);
                    ?></div>
                    <div class="transport-route">
                        <?php echo htmlspecialchars($t['from']); ?>
                        <span class="arrow">→</span>
                        <?php echo htmlspecialchars($t['to']); ?>
                    </div>
                    <span class="transport-duration"><?php echo htmlspecialchars($t['duration']); ?></span>
                    <div class="transport-price<?php echo ($t['price'] == 0) ? ' free' : ''; ?>">
                        <?php echo ($t['price'] == 0) ? 'Free' : '$' . number_format($t['price']); ?>
                    </div>
                    <button class="btn-select" onclick="openTransportModal(
                        '<?php echo htmlspecialchars(addslashes($type_raw), ENT_QUOTES); ?>',
                        '<?php echo htmlspecialchars(addslashes($t['from']), ENT_QUOTES); ?>',
                        '<?php echo htmlspecialchars(addslashes($t['to']), ENT_QUOTES); ?>',
                        '<?php echo htmlspecialchars(addslashes($t['duration']), ENT_QUOTES); ?>',
                        '<?php echo ($t['price'] == 0) ? 'Free' : '$' . number_format($t['price']); ?>'
                    )">🎫 Book Now</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div><!-- /city-section -->
    <?php endforeach; ?>

    <!-- ── BUDGET TRACKER ── -->
    <div class="budget-section">
        <div class="sec-header">
            <h2 class="sec-title">📊 Budget Tracker</h2>
        </div>

        <?php if (!empty($user_trips)): ?>
        <!-- Add Budget Item Form -->
        <div class="budget-card">
            <div class="budget-card-header">
                <h3>➕ Add Budget Item</h3>
            </div>
            <form method="POST" action="budget.php" class="budget-form">
                <input type="hidden" name="add_budget" value="1">
                <div class="form-row">
                    <div class="form-group">
                        <label>Trip</label>
                        <select name="trip_id" required>
                            <option value="">— Select Trip —</option>
                            <?php foreach ($user_trips as $trip): ?>
                            <option value="<?php echo (int)$trip['id']; ?>">
                                <?php echo htmlspecialchars($trip['name'] ?? $trip['title'] ?? 'Trip #' . $trip['id']); ?>
                                <?php if (!empty($trip['start_date'])): ?>
                                    (<?php echo date('M Y', strtotime($trip['start_date'])); ?>)
                                <?php endif; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category" required>
                            <option value="flights">✈️ Flights</option>
                            <option value="hotels">🏨 Hotels</option>
                            <option value="food">🍽️ Food</option>
                            <option value="activities">🎯 Activities</option>
                            <option value="transport">🚌 Transport</option>
                            <option value="shopping">🛍️ Shopping</option>
                            <option value="other">📦 Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Currency</label>
                        <select name="currency">
                            <option value="USD">USD $</option>
                            <option value="EUR">EUR €</option>
                            <option value="GBP">GBP £</option>
                            <option value="JPY">JPY ¥</option>
                            <option value="AUD">AUD A$</option>
                            <option value="SGD">SGD S$</option>
                            <option value="THB">THB ฿</option>
                            <option value="IDR">IDR Rp</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group" style="grid-column: span 3;">
                        <label>Description</label>
                        <input type="text" name="description" placeholder="e.g. Return flight to Paris" required maxlength="255">
                    </div>
                </div>
                <div class="form-row-2">
                    <div class="form-group">
                        <label>Estimated Cost</label>
                        <input type="number" name="estimated_cost" placeholder="0.00" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label>Actual Cost <span style="font-weight:400;color:#aaa;">(optional)</span></label>
                        <input type="number" name="actual_cost" placeholder="0.00" step="0.01" min="0">
                    </div>
                </div>
                <button type="submit" class="btn-add-budget">➕ Add Item</button>
            </form>
        </div>

        <!-- Budget Items by Trip -->
        <?php if (!empty($budget_by_trip)):
            $cat_icons = [
                'flights'    => '✈️',
                'hotels'     => '🏨',
                'food'       => '🍽️',
                'activities' => '🎯',
                'transport'  => '🚌',
                'shopping'   => '🛍️',
                'other'      => '📦',
            ];
            foreach ($budget_by_trip as $trip_id => $trip_data):
                $items = $trip_data['items'] ?? [];
                $total_est = array_sum(array_column($items, 'estimated_cost'));
                $total_act = array_sum(array_filter(array_column($items, 'actual_cost'), fn($v) => $v !== null));
        ?>
        <div class="budget-card budget-trip-block">
            <div class="budget-trip-name">
                🗺️ <?php echo htmlspecialchars($trip_data['name']); ?>
                <span style="margin-left:auto;font-size:13px;font-weight:600;color:#888;">
                    Est: $<?php echo number_format($total_est, 2); ?>
                    <?php if ($total_act > 0): ?>
                    &nbsp;|&nbsp; Actual: $<?php echo number_format($total_act, 2); ?>
                    <?php endif; ?>
                </span>
            </div>
            <table class="budget-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Estimated</th>
                        <th>Actual</th>
                        <th>Difference</th>
                        <th>Currency</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item):
                        $cat = strtolower($item['category'] ?? 'other');
                        $icon = $cat_icons[$cat] ?? '📦';
                        $est  = floatval($item['estimated_cost']);
                        $act  = ($item['actual_cost'] !== null && $item['actual_cost'] !== '') ? floatval($item['actual_cost']) : null;
                        if ($act !== null) {
                            $diff = $act - $est;
                            $diff_class = ($diff <= 0) ? 'diff-under' : 'diff-over';
                            $diff_str   = ($diff <= 0 ? '-$' . number_format(abs($diff), 2) : '+$' . number_format($diff, 2));
                        }
                    ?>
                    <tr>
                        <td>
                            <span class="cat-badge cat-<?php echo htmlspecialchars($cat); ?>">
                                <?php echo $icon; ?> <?php echo htmlspecialchars(ucfirst($cat)); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                        <td>$<?php echo number_format($est, 2); ?></td>
                        <td><?php echo ($act !== null) ? '$' . number_format($act, 2) : '<span class="diff-na">—</span>'; ?></td>
                        <td>
                            <?php if ($act !== null): ?>
                                <span class="<?php echo $diff_class; ?>"><?php echo $diff_str; ?></span>
                            <?php else: ?>
                                <span class="diff-na">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($item['currency'] ?? 'USD'); ?></td>
                        <td>
                            <form method="POST" action="budget.php" style="display:inline;">
                                <input type="hidden" name="delete_item" value="1">
                                <input type="hidden" name="item_id" value="<?php echo (int)$item['id']; ?>">
                                <button type="submit" class="btn-delete"
                                        onclick="return confirm('Delete this budget item?')">🗑️</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="budget-card">
            <div class="empty-state">
                <div class="empty-icon">📊</div>
                <p>No budget items yet. Add your first item above!</p>
            </div>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <!-- No trips -->
        <div class="budget-card">
            <div class="empty-state">
                <div class="empty-icon">🗺️</div>
                <p>You need to create a trip before tracking your budget.</p>
                <a href="create-trip.php" class="btn-primary-link">➕ Create Your First Trip</a>
            </div>
        </div>
        <?php endif; ?>
    </div><!-- /budget-section -->

</div><!-- /page-main -->

<!-- ===== FOOTER ===== -->
<footer>
    <p>© 2026 Travel Planner. All rights reserved.</p>
</footer>

<!-- ===== BOOKING MODAL ===== -->
<div class="modal-overlay" id="booking-modal" onclick="closeModalOnBg(event)">
    <div class="modal-box" id="modal-box">

        <!-- Form view -->
        <div id="modal-form-view">
            <div class="modal-header">
                <div class="modal-header-info">
                    <h3 id="modal-title">Book Transport</h3>
                    <p id="modal-subtitle">Fill in your details to confirm</p>
                </div>
                <button class="modal-close" onclick="closeModal()">✕</button>
            </div>

            <div class="modal-summary" id="modal-summary"></div>

            <div class="modal-body">
                <div class="modal-price-row">
                    <span class="modal-price-label">Price per person</span>
                    <span class="modal-price-val" id="modal-price">$0</span>
                </div>

                <div class="modal-field">
                    <label>Full Name</label>
                    <input type="text" id="book-name" placeholder="Your full name" required>
                </div>

                <div class="modal-row">
                    <div class="modal-field">
                        <label>Travel Date</label>
                        <input type="date" id="book-date" required>
                    </div>
                    <div class="modal-field">
                        <label>Passengers / Guests</label>
                        <select id="book-passengers">
                            <option value="1">1 Person</option>
                            <option value="2">2 People</option>
                            <option value="3">3 People</option>
                            <option value="4">4 People</option>
                            <option value="5">5 People</option>
                            <option value="6">6+ People</option>
                        </select>
                    </div>
                </div>

                <div class="modal-field" id="hotel-nights-field" style="display:none;">
                    <label>Number of Nights</label>
                    <input type="number" id="book-nights" placeholder="e.g. 3" min="1" value="1">
                </div>

                <div class="modal-field">
                    <label>Special Requests <span style="font-weight:400;color:#aaa;">(optional)</span></label>
                    <input type="text" id="book-notes" placeholder="Any special requirements…">
                </div>

                <button class="btn-confirm-book" onclick="confirmBooking()">
                    ✅ Confirm Booking
                </button>
            </div>
        </div>

        <!-- Success view -->
        <div class="booking-success" id="modal-success-view">
            <div class="success-icon">🎉</div>
            <h3>Booking Confirmed!</h3>
            <p id="success-message">Your booking has been confirmed.<br>Check your email for details.</p>
            <button class="btn-done" onclick="closeModal()">Done</button>
        </div>

    </div>
</div>

<script>
// ── Show/hide city sections ──────────────────────────────────────────
function showCity(cityName) {
    document.querySelectorAll('.city-section').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.city-pill').forEach(btn => btn.classList.remove('active'));
    var cityId = 'city-' + cityName.replace(/\s+/g, '-');
    var section = document.getElementById(cityId);
    if (section) section.classList.add('active');
    document.querySelectorAll('.city-pill').forEach(btn => {
        if (btn.textContent.trim() === cityName) btn.classList.add('active');
    });
}

// ── Transport filter ─────────────────────────────────────────────────
function filterTransport(cityId, keyword, clickedBtn) {
    var pillContainer = document.getElementById('filter-' + cityId);
    if (pillContainer) pillContainer.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    if (clickedBtn) clickedBtn.classList.add('active');
    var grid = document.getElementById('tgrid-' + cityId);
    if (!grid) return;
    grid.querySelectorAll('.transport-card').forEach(card => {
        if (keyword === 'all') {
            card.classList.remove('hidden');
        } else {
            var type = card.getAttribute('data-type') || '';
            type.toLowerCase().indexOf(keyword.toLowerCase()) !== -1
                ? card.classList.remove('hidden')
                : card.classList.add('hidden');
        }
    });
}

// ── Modal state ──────────────────────────────────────────────────────
var _modalType = 'transport'; // 'transport' or 'hotel'

function openTransportModal(type, from, to, duration, price) {
    _modalType = 'transport';
    document.getElementById('modal-title').textContent    = 'Book ' + type;
    document.getElementById('modal-subtitle').textContent = from + ' → ' + to;
    document.getElementById('modal-price').textContent    = price;
    document.getElementById('hotel-nights-field').style.display = 'none';

    // Summary tags
    var summary = document.getElementById('modal-summary');
    summary.innerHTML =
        '<span class="modal-tag">🚏 ' + from + '</span>' +
        '<span class="modal-tag">📍 ' + to + '</span>' +
        '<span class="modal-tag">⏱️ ' + duration + '</span>' +
        '<span class="modal-tag">' + price + '</span>';

    // Set min date to today
    document.getElementById('book-date').min = new Date().toISOString().split('T')[0];
    document.getElementById('book-date').value = '';
    document.getElementById('book-name').value = '';
    document.getElementById('book-notes').value = '';

    // Show form, hide success
    document.getElementById('modal-form-view').style.display = 'block';
    document.getElementById('modal-success-view').style.display = 'none';

    document.getElementById('booking-modal').classList.add('open');
}

function openHotelModal(name, stars, price, amenities, city) {
    _modalType = 'hotel';
    document.getElementById('modal-title').textContent    = name;
    document.getElementById('modal-subtitle').textContent = stars + '  ·  ' + city;
    document.getElementById('modal-price').textContent    = price;
    document.getElementById('hotel-nights-field').style.display = 'block';

    var summary = document.getElementById('modal-summary');
    summary.innerHTML =
        '<span class="modal-tag">🏙️ ' + city + '</span>' +
        '<span class="modal-tag">' + stars + '</span>' +
        '<span class="modal-tag">' + price + '</span>' +
        '<span class="modal-tag">✨ ' + amenities + '</span>';

    document.getElementById('book-date').min = new Date().toISOString().split('T')[0];
    document.getElementById('book-date').value = '';
    document.getElementById('book-name').value = '';
    document.getElementById('book-notes').value = '';
    document.getElementById('book-nights').value = '1';

    document.getElementById('modal-form-view').style.display = 'block';
    document.getElementById('modal-success-view').style.display = 'none';

    document.getElementById('booking-modal').classList.add('open');
}

function confirmBooking() {
    var name = document.getElementById('book-name').value.trim();
    var date = document.getElementById('book-date').value;
    if (!name) { alert('Please enter your full name.'); return; }
    if (!date) { alert('Please select a travel date.'); return; }

    var passengers = document.getElementById('book-passengers').value;
    var price      = document.getElementById('modal-price').textContent;
    var title      = document.getElementById('modal-title').textContent;

    var msg = '';
    if (_modalType === 'hotel') {
        var nights = document.getElementById('book-nights').value || '1';
        msg = '<strong>' + title + '</strong> has been booked for <strong>' + name + '</strong>.<br>' +
              'Check-in: <strong>' + date + '</strong> · <strong>' + nights + ' night(s)</strong> · ' +
              '<strong>' + passengers + ' guest(s)</strong><br>Rate: ' + price;
    } else {
        msg = '<strong>' + title + '</strong> booked for <strong>' + name + '</strong>.<br>' +
              'Date: <strong>' + date + '</strong> · <strong>' + passengers + ' passenger(s)</strong><br>Price: ' + price;
    }

    document.getElementById('success-message').innerHTML = msg;
    document.getElementById('modal-form-view').style.display  = 'none';
    document.getElementById('modal-success-view').style.display = 'block';
}

function closeModal() {
    document.getElementById('booking-modal').classList.remove('open');
}

function closeModalOnBg(e) {
    if (e.target === document.getElementById('booking-modal')) closeModal();
}

// ── On page load: show first city ───────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
    var firstPill = document.querySelector('.city-pill');
    if (firstPill) showCity(firstPill.textContent.trim());
});
</script>
</body>
</html>

