<?php
$page_title = 'View Itinerary';
require_once 'includes/header.php';
requireLogin();
?>

<h1>Itinerary</h1>
<p>View your itinerary here.</p>

<?php require_once 'includes/footer.php'; ?>
