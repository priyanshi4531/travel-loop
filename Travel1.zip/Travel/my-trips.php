<?php
// Redirect to the canonical underscore version
header('Location: my_trips.php');
exit();
