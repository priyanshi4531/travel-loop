<?php
$page_title = 'Packing Checklist';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$msg = '';
$msg_type = '';

// ── Handle actions ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Add item
    if (isset($_POST['add_item'])) {
        $trip_id   = (int)($_POST['trip_id'] ?? 0);
        $item_name = sanitizeInput($_POST['item_name'] ?? '');
        $category  = sanitizeInput($_POST['category']  ?? 'other');
        $quantity  = max(1, (int)($_POST['quantity']   ?? 1));

        if (empty($item_name)) {
            $msg = 'Item name is required.'; $msg_type = 'error';
        } else {
            // Verify trip belongs to user
            $chk = $conn->prepare("SELECT id FROM trips WHERE id = ? AND user_id = ?");
            $chk->bind_param("ii", $trip_id, $user_id);
            $chk->execute();
            if ($chk->get_result()->num_rows > 0) {
                $ins = $conn->prepare("INSERT INTO packing_items (trip_id, user_id, item_name, category, quantity, is_packed) VALUES (?,?,?,?,?,0)");
                $ins->bind_param("iissi", $trip_id, $user_id, $item_name, $category, $quantity);
                $ins->execute();
                $ins->close();
                $msg = 'Item added!'; $msg_type = 'success';
            }
            $chk->close();
        }
    }

    // Toggle packed
    if (isset($_POST['toggle_item'])) {
        $item_id    = (int)$_POST['item_id'];
        $is_packed  = (int)$_POST['is_packed'];
        $new_status = $is_packed ? 0 : 1;
        $upd = $conn->prepare("UPDATE packing_items pi JOIN trips t ON pi.trip_id=t.id SET pi.is_packed=? WHERE pi.id=? AND t.user_id=?");
        $upd->bind_param("iii", $new_status, $item_id, $user_id);
        $upd->execute();
        $upd->close();
        header('Location: packing.php'); exit();
    }

    // Delete item
    if (isset($_POST['delete_item'])) {
        $item_id = (int)$_POST['item_id'];
        $del = $conn->prepare("DELETE pi FROM packing_items pi JOIN trips t ON pi.trip_id=t.id WHERE pi.id=? AND t.user_id=?");
        $del->bind_param("ii", $item_id, $user_id);
        $del->execute();
        $del->close();
        header('Location: packing.php'); exit();
    }
}

// ── Fetch user trips ──────────────────────────────────────────────
$trips_stmt = $conn->prepare("SELECT id, name FROM trips WHERE user_id = ? ORDER BY created_at DESC");
$trips_stmt->bind_param("i", $user_id);
$trips_stmt->execute();
$user_trips = $trips_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$trips_stmt->close();

// ── Fetch packing items grouped by trip ──────────────────────────
$items_stmt = $conn->prepare(
    "SELECT pi.*, t.name AS trip_name
     FROM packing_items pi
     JOIN trips t ON pi.trip_id = t.id
     WHERE t.user_id = ?
     ORDER BY pi.trip_id, pi.category, pi.item_name"
);
$items_stmt->bind_param("i", $user_id);
$items_stmt->execute();
$all_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$items_stmt->close();

// Group by trip
$items_by_trip = [];
foreach ($all_items as $item) {
    $items_by_trip[$item['trip_id']]['name']    = $item['trip_name'];
    $items_by_trip[$item['trip_id']]['items'][] = $item;
}

$cat_icons = [
    'clothing'    => '👕',
    'toiletries'  => '🧴',
    'documents'   => '📄',
    'electronics' => '💻',
    'medicine'    => '💊',
    'other'       => '📦',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> – Travel Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif; color: #1a1a2e;
            min-height: 100vh;
            background:
                linear-gradient(rgba(8,12,35,0.60), rgba(8,12,35,0.60)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
        }

        /* NAV */
        header { background: #0f172a; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 20px rgba(0,0,0,0.3); }
        header nav { display: flex; justify-content: space-between; align-items: center; padding: 0 40px; height: 64px; }
        .logo { font-size: 20px; font-weight: 800; color: #fff; text-decoration: none; }
        .nav-menu { display: flex; list-style: none; gap: 4px; align-items: center; }
        .nav-menu a { color: rgba(255,255,255,0.70); text-decoration: none; font-size: 14px; font-weight: 500; padding: 8px 13px; border-radius: 8px; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { color: #fff; background: rgba(255,255,255,0.10); }
        .nav-cta a { background: linear-gradient(135deg,#667eea,#764ba2) !important; color: #fff !important; }

        /* HERO */
        .hero {
            background: linear-gradient(135deg, rgba(8,15,50,0.85) 0%, rgba(25,8,60,0.90) 100%),
                        url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90') center/cover no-repeat;
            padding: 56px 40px 48px; text-align: center;
        }
        .hero-badge { display: inline-block; background: rgba(102,126,234,0.25); border: 1px solid rgba(102,126,234,0.45); color: #a5b4fc; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 6px 16px; border-radius: 20px; margin-bottom: 16px; }
        .hero h1 { font-size: 36px; font-weight: 900; color: #fff; margin-bottom: 10px; text-shadow: 0 2px 16px rgba(0,0,0,0.5); }
        .hero p  { font-size: 15px; color: rgba(255,255,255,0.62); }

        /* MAIN */
        main { max-width: 1100px; margin: 0 auto; padding: 36px 24px 70px; }

        /* ALERT */
        .alert { padding: 12px 18px; border-radius: 9px; font-size: 14px; margin-bottom: 24px; font-weight: 500; }
        .alert-success { background: rgba(34,197,94,0.18); color: #86efac; border-left: 3px solid #22c55e; }
        .alert-error   { background: rgba(239,68,68,0.18); color: #fca5a5; border-left: 3px solid #ef4444; }

        /* LAYOUT */
        .layout { display: grid; grid-template-columns: 340px 1fr; gap: 28px; align-items: start; }

        /* CARD */
        .card { background: rgba(255,255,255,0.97); border-radius: 16px; box-shadow: 0 6px 28px rgba(0,0,0,0.14); overflow: hidden; margin-bottom: 24px; }
        .card:last-child { margin-bottom: 0; }
        .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
        .card-header h3 { font-size: 16px; font-weight: 800; color: #1a1a2e; }

        /* FORM */
        .form-body { padding: 22px 24px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 7px; }
        .form-group input,
        .form-group select { width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 8px; font-size: 14px; font-family: inherit; color: #1a1a2e; background: #fafbff; transition: border-color 0.2s; }
        .form-group input:focus,
        .form-group select:focus { outline: none; border-color: #667eea; background: #fff; }
        .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn-add { width: 100%; padding: 12px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; transition: opacity 0.2s, transform 0.15s; margin-top: 4px; }
        .btn-add:hover { opacity: 0.88; transform: translateY(-1px); }

        /* QUICK ADD SUGGESTIONS */
        .suggestions { padding: 0 24px 20px; }
        .suggestions-label { font-size: 12px; font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; }
        .suggestion-chips { display: flex; flex-wrap: wrap; gap: 7px; }
        .chip { padding: 5px 12px; background: #f0f4ff; color: #667eea; border: 1.5px solid #c7d2fe; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .chip:hover { background: #667eea; color: #fff; border-color: #667eea; }

        /* PROGRESS BAR */
        .progress-wrap { padding: 16px 24px; border-bottom: 1px solid #f0f0f0; }
        .progress-label { display: flex; justify-content: space-between; font-size: 13px; font-weight: 600; color: #555; margin-bottom: 8px; }
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 10px; overflow: hidden; }
        .progress-fill { height: 100%; background: linear-gradient(135deg,#667eea,#764ba2); border-radius: 10px; transition: width 0.4s; }

        /* TRIP BLOCK */
        .trip-block { margin-bottom: 28px; }
        .trip-block:last-child { margin-bottom: 0; }
        .trip-name-bar { padding: 14px 22px; background: #f8f9ff; border-bottom: 1px solid #eef0f8; display: flex; align-items: center; justify-content: space-between; }
        .trip-name-bar h4 { font-size: 15px; font-weight: 800; color: #1a1a2e; display: flex; align-items: center; gap: 8px; }
        .trip-stats { font-size: 12px; color: #888; font-weight: 600; }

        /* CATEGORY GROUP */
        .cat-group { padding: 0 22px; }
        .cat-label { font-size: 11px; font-weight: 700; color: #aaa; text-transform: uppercase; letter-spacing: 0.8px; padding: 14px 0 8px; border-bottom: 1px solid #f5f5f5; margin-bottom: 4px; }

        /* PACKING ITEM ROW */
        .item-row { display: flex; align-items: center; gap: 12px; padding: 11px 0; border-bottom: 1px solid #f8f8f8; }
        .item-row:last-child { border-bottom: none; }
        .item-check { width: 22px; height: 22px; border-radius: 6px; border: 2px solid #c7d2fe; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all 0.2s; }
        .item-check.packed { background: linear-gradient(135deg,#667eea,#764ba2); border-color: transparent; }
        .item-check.packed::after { content: '✓'; color: #fff; font-size: 13px; font-weight: 800; }
        .item-name { flex: 1; font-size: 14px; color: #1a1a2e; font-weight: 500; }
        .item-name.packed { text-decoration: line-through; color: #aaa; }
        .item-qty { font-size: 12px; color: #888; background: #f3f4f6; padding: 2px 8px; border-radius: 10px; font-weight: 600; }
        .item-cat-badge { font-size: 11px; font-weight: 700; padding: 3px 9px; border-radius: 12px; }
        .cat-clothing    { background: #dbeafe; color: #1d4ed8; }
        .cat-toiletries  { background: #fce7f3; color: #9d174d; }
        .cat-documents   { background: #fef3c7; color: #92400e; }
        .cat-electronics { background: #d1fae5; color: #065f46; }
        .cat-medicine    { background: #ede9fe; color: #6d28d9; }
        .cat-other       { background: #f3f4f6; color: #374151; }
        .btn-del { background: none; border: none; color: #ddd; cursor: pointer; font-size: 16px; padding: 2px 4px; transition: color 0.2s; }
        .btn-del:hover { color: #ef4444; }

        /* EMPTY STATE */
        .empty-state { padding: 48px 20px; text-align: center; }
        .empty-state .ei { font-size: 52px; margin-bottom: 14px; }
        .empty-state p { color: #aaa; font-size: 15px; }

        /* SEC TITLE */
        .sec-title { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; text-shadow: 0 1px 6px rgba(0,0,0,0.4); }

        /* FOOTER */
        footer { background: #0f172a; color: rgba(255,255,255,0.45); text-align: center; padding: 22px; font-size: 13px; }

        @media (max-width: 900px) { .layout { grid-template-columns: 1fr; } }
        @media (max-width: 600px) { header nav { padding: 0 16px; } .hero { padding: 40px 20px; } .hero h1 { font-size: 26px; } main { padding: 24px 16px 50px; } }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="dashboard.php" class="logo">✈️ Travel Planner</a>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="my_trips.php">My Trips</a></li>
            <li><a href="city-search.php">Cities</a></li>
            <li><a href="activity-search.php">Activities</a></li>
            <li><a href="budget.php">Budget</a></li>
            <li><a href="packing.php" class="active">Packing</a></li>
            <li><a href="profile.php">Profile</a></li>
            <?php if (isAdmin()): ?><li><a href="admin/index.php">Admin</a></li><?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
            <li class="nav-cta"><a href="create-trip.php">+ New Trip</a></li>
        </ul>
    </nav>
</header>

<div class="hero">
    <div class="hero-badge">🧳 Packing Checklist</div>
    <h1>Pack Smart, Travel Light</h1>
    <p>Organise your packing list by trip and category — never forget anything again</p>
</div>

<main>
    <?php if ($msg): ?>
        <div class="alert alert-<?php echo $msg_type; ?>"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="layout">

        <!-- ── LEFT: Add Item Form ── -->
        <div>
            <div class="card">
                <div class="card-header">
                    <h3>➕ Add Packing Item</h3>
                </div>
                <?php if (!empty($user_trips)): ?>
                <form method="POST" action="" class="form-body">
                    <input type="hidden" name="add_item" value="1">

                    <div class="form-group">
                        <label>Trip</label>
                        <select name="trip_id" id="trip-select" required>
                            <option value="">— Select Trip —</option>
                            <?php foreach ($user_trips as $t): ?>
                                <option value="<?php echo (int)$t['id']; ?>">
                                    <?php echo htmlspecialchars($t['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Item Name</label>
                        <input type="text" name="item_name" id="item-name-input"
                               placeholder="e.g. Passport" required maxlength="200">
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label>Category</label>
                            <select name="category">
                                <option value="clothing">👕 Clothing</option>
                                <option value="toiletries">🧴 Toiletries</option>
                                <option value="documents">📄 Documents</option>
                                <option value="electronics">💻 Electronics</option>
                                <option value="medicine">💊 Medicine</option>
                                <option value="other">📦 Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Quantity</label>
                            <input type="number" name="quantity" value="1" min="1" max="99">
                        </div>
                    </div>

                    <button type="submit" class="btn-add">➕ Add to List</button>
                </form>

                <!-- Quick suggestions -->
                <div class="suggestions">
                    <div class="suggestions-label">Quick Add</div>
                    <div class="suggestion-chips">
                        <?php
                        $suggestions = ['Passport','Visa','Phone Charger','Sunscreen','Toothbrush',
                                        'T-Shirts','Jeans','Sneakers','Adapter','Camera',
                                        'Headphones','Medicines','Travel Insurance','Notebook','Umbrella'];
                        foreach ($suggestions as $s):
                        ?>
                        <span class="chip" onclick="quickAdd('<?php echo htmlspecialchars($s, ENT_QUOTES); ?>')">
                            <?php echo htmlspecialchars($s); ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <?php else: ?>
                <div class="empty-state">
                    <div class="ei">🗺️</div>
                    <p>Create a trip first to start packing!</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ── RIGHT: Packing Lists ── -->
        <div>
            <div class="sec-title">🧳 Your Packing Lists</div>

            <?php if (!empty($items_by_trip)): ?>
                <?php foreach ($items_by_trip as $trip_id => $trip_data):
                    $items   = $trip_data['items'];
                    $total   = count($items);
                    $packed  = count(array_filter($items, fn($i) => $i['is_packed']));
                    $pct     = $total > 0 ? round(($packed / $total) * 100) : 0;

                    // Group by category
                    $by_cat = [];
                    foreach ($items as $item) {
                        $by_cat[$item['category']][] = $item;
                    }
                ?>
                <div class="card trip-block">
                    <!-- Progress -->
                    <div class="progress-wrap">
                        <div class="progress-label">
                            <span>🗺️ <?php echo htmlspecialchars($trip_data['name']); ?></span>
                            <span><?php echo $packed; ?>/<?php echo $total; ?> packed (<?php echo $pct; ?>%)</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:<?php echo $pct; ?>%"></div>
                        </div>
                    </div>

                    <!-- Items by category -->
                    <?php foreach ($by_cat as $cat => $cat_items):
                        $icon = $cat_icons[$cat] ?? '📦';
                    ?>
                    <div class="cat-group">
                        <div class="cat-label"><?php echo $icon . ' ' . ucfirst($cat); ?></div>
                        <?php foreach ($cat_items as $item): ?>
                        <div class="item-row">
                            <!-- Toggle packed -->
                            <form method="POST" action="" style="display:contents;">
                                <input type="hidden" name="toggle_item" value="1">
                                <input type="hidden" name="item_id"    value="<?php echo (int)$item['id']; ?>">
                                <input type="hidden" name="is_packed"  value="<?php echo (int)$item['is_packed']; ?>">
                                <button type="submit" class="item-check <?php echo $item['is_packed'] ? 'packed' : ''; ?>"
                                        title="<?php echo $item['is_packed'] ? 'Mark unpacked' : 'Mark packed'; ?>"></button>
                            </form>

                            <span class="item-name <?php echo $item['is_packed'] ? 'packed' : ''; ?>">
                                <?php echo htmlspecialchars($item['item_name']); ?>
                            </span>

                            <?php if ($item['quantity'] > 1): ?>
                                <span class="item-qty">×<?php echo (int)$item['quantity']; ?></span>
                            <?php endif; ?>

                            <!-- Delete -->
                            <form method="POST" action="" style="display:contents;">
                                <input type="hidden" name="delete_item" value="1">
                                <input type="hidden" name="item_id"     value="<?php echo (int)$item['id']; ?>">
                                <button type="submit" class="btn-del"
                                        onclick="return confirm('Remove this item?')" title="Remove">🗑️</button>
                            </form>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>

            <?php else: ?>
                <div class="card">
                    <div class="empty-state">
                        <div class="ei">🧳</div>
                        <p>No packing items yet.<br>Add your first item from the form!</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

<footer><p>© 2026 Travel Planner. All rights reserved.</p></footer>

<script>
function quickAdd(name) {
    document.getElementById('item-name-input').value = name;
    document.getElementById('item-name-input').focus();
}
</script>
</body>
</html>