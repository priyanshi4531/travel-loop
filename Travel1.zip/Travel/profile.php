<?php
$page_title = 'My Profile';
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

requireLogin();

$user_id = $_SESSION['user_id'];
$error   = '';
$success = '';

// ── Fetch current user ────────────────────────────────────────────
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ── Handle form submission ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── Update profile info ───────────────────────────────────────
    if ($action === 'update_profile') {
        $name            = sanitizeInput($_POST['name']            ?? '');
        $city            = sanitizeInput($_POST['city']            ?? '');
        $country         = sanitizeInput($_POST['country']         ?? '');
        $bio             = sanitizeInput($_POST['bio']             ?? '');
        $phone           = sanitizeInput($_POST['phone']           ?? '');
        $additional_info = sanitizeInput($_POST['additional_info'] ?? '');

        if (empty($name)) {
            $error = 'Name is required.';
        } else {
            // Handle avatar upload
            $avatar = $user['avatar'];
            if (!empty($_FILES['avatar']['name'])) {
                $file     = $_FILES['avatar'];
                $allowed  = ['image/jpeg','image/png','image/gif','image/webp'];
                $max_size = 3 * 1024 * 1024;

                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime  = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);

                if (!in_array($mime, $allowed)) {
                    $error = 'Profile photo must be JPEG, PNG, GIF or WebP.';
                } elseif ($file['size'] > $max_size) {
                    $error = 'Profile photo must be smaller than 3 MB.';
                } else {
                    $ext        = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $new_avatar = 'avatar_' . $user_id . '_' . time() . '.' . $ext;
                    $upload_dir = __DIR__ . '/assets/uploads/';

                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_avatar)) {
                        // Delete old avatar if it exists
                        if (!empty($user['avatar']) && file_exists($upload_dir . $user['avatar'])) {
                            unlink($upload_dir . $user['avatar']);
                        }
                        $avatar = $new_avatar;
                    } else {
                        $error = 'Failed to upload photo. Please try again.';
                    }
                }
            }

            if (empty($error)) {
                $upd = $conn->prepare(
                    "UPDATE users SET name=?, phone=?, bio=?, city=?, country=?, additional_info=?, avatar=? WHERE id=?"
                );
                $upd->bind_param("sssssssi", $name, $phone, $bio, $city, $country, $additional_info, $avatar, $user_id);
                if ($upd->execute()) {
                    $success = 'Profile updated successfully!';
                    $_SESSION['user_name'] = $name;
                    // Refresh user data
                    $stmt2 = $conn->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt2->bind_param("i", $user_id);
                    $stmt2->execute();
                    $user = $stmt2->get_result()->fetch_assoc();
                    $stmt2->close();
                } else {
                    $error = 'Failed to update profile. Please try again.';
                }
                $upd->close();
            }
        }
    }

    // ── Change password ───────────────────────────────────────────
    if ($action === 'change_password') {
        $current_pw  = $_POST['current_password']  ?? '';
        $new_pw      = $_POST['new_password']      ?? '';
        $confirm_pw  = $_POST['confirm_password']  ?? '';

        if (empty($current_pw) || empty($new_pw) || empty($confirm_pw)) {
            $error = 'All password fields are required.';
        } elseif (!password_verify($current_pw, $user['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($new_pw) < 6) {
            $error = 'New password must be at least 6 characters.';
        } elseif ($new_pw !== $confirm_pw) {
            $error = 'New passwords do not match.';
        } else {
            $hashed = password_hash($new_pw, PASSWORD_BCRYPT);
            $upd = $conn->prepare("UPDATE users SET password=? WHERE id=?");
            $upd->bind_param("si", $hashed, $user_id);
            if ($upd->execute()) {
                $success = 'Password changed successfully!';
            } else {
                $error = 'Failed to change password. Please try again.';
            }
            $upd->close();
        }
    }
}

// Avatar URL helper
$avatar_src = !empty($user['avatar']) && file_exists(__DIR__ . '/assets/uploads/' . $user['avatar'])
    ? 'assets/uploads/' . htmlspecialchars($user['avatar'])
    : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Travel Planner</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background:
                linear-gradient(rgba(8,12,35,0.55), rgba(8,12,35,0.55)),
                url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=90')
                center / cover no-repeat fixed;
            min-height: 100vh;
        }
        /* ── Profile hero ── */
        .profile-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 14px;
            padding: 40px 36px;
            display: flex;
            align-items: center;
            gap: 28px;
            margin-bottom: 32px;
            flex-wrap: wrap;
        }
        .hero-avatar-wrap {
            position: relative;
            flex-shrink: 0;
        }
        .hero-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid rgba(255,255,255,0.5);
            box-shadow: 0 4px 16px rgba(0,0,0,0.25);
            display: block;
        }
        .hero-avatar-placeholder {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: rgba(255,255,255,0.25);
            border: 4px solid rgba(255,255,255,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
        }
        .hero-info h1 {
            color: white;
            font-size: 26px;
            margin: 0 0 4px;
        }
        .hero-info p {
            color: rgba(255,255,255,0.80);
            font-size: 14px;
            margin: 0 0 10px;
        }
        .hero-badge {
            display: inline-block;
            background: rgba(255,255,255,0.20);
            color: white;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.30);
        }

        /* ── Two-column layout ── */
        .profile-layout {
            display: grid;
            grid-template-columns: 1fr 360px;
            gap: 28px;
            align-items: start;
        }

        /* ── Cards ── */
        .profile-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            padding: 28px 30px;
            margin-bottom: 24px;
        }
        .profile-card:last-child { margin-bottom: 0; }
        .card-title {
            font-size: 15px;
            font-weight: 700;
            color: #2c3e50;
            margin: 0 0 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* ── Alert ── */
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-error   { background: #fde8e8; color: #c0392b; border-left: 4px solid #e74c3c; }
        .alert-success { background: #e8f8f0; color: #1e8449; border-left: 4px solid #27ae60; }

        /* ── Form elements ── */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .form-group { margin-bottom: 18px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #444;
            margin-bottom: 7px;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid #dde1ec;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            color: #1a1a2e;
            background: #fafbff;
            transition: border-color 0.25s, box-shadow 0.25s;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 90px;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.15);
            background: white;
        }
        .form-group input[readonly] {
            background: #f0f0f5;
            color: #888;
            cursor: not-allowed;
        }

        /* ── Avatar upload in form ── */
        .avatar-upload-row {
            display: flex;
            align-items: center;
            gap: 18px;
            margin-bottom: 22px;
            padding-bottom: 22px;
            border-bottom: 1px solid #f0f0f0;
        }
        .form-avatar {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e0e0f0;
            flex-shrink: 0;
        }
        .form-avatar-placeholder {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }
        .avatar-upload-info { flex: 1; }
        .avatar-upload-info label {
            display: inline-block;
            padding: 8px 16px;
            background: #f0f3ff;
            color: #667eea;
            border: 1.5px solid #c5cae9;
            border-radius: 7px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .avatar-upload-info label:hover { background: #e0e7ff; }
        .avatar-upload-info input[type="file"] { display: none; }
        .avatar-upload-hint {
            font-size: 12px;
            color: #aaa;
            margin-top: 5px;
        }

        /* ── Buttons ── */
        .btn-save {
            padding: 11px 28px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 3px 12px rgba(102,126,234,0.35);
        }
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(102,126,234,0.45);
        }

        /* ── Stats ── */
        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }
        .stat-item {
            background: #f8f9ff;
            border-radius: 10px;
            padding: 16px;
            text-align: center;
            border: 1px solid #eef0f8;
        }
        .stat-num   { font-size: 28px; font-weight: 800; color: #667eea; }
        .stat-label { font-size: 12px; color: #888; margin-top: 3px; }

        /* ── Member since ── */
        .meta-row {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: #888;
            padding: 10px 0;
            border-top: 1px solid #f0f0f0;
        }
        .meta-row:first-child { border-top: none; padding-top: 0; }

        /* ── Responsive ── */
        @media (max-width: 900px) {
            .profile-layout { grid-template-columns: 1fr; }
        }
        @media (max-width: 560px) {
            .form-row { grid-template-columns: 1fr; }
            .profile-hero { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <!-- ── Nav ── -->
    <header>
        <nav>
            <div class="logo">✈️ Travel Planner</div>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="my_trips.php">My Trips</a></li>
                <li><a href="profile.php" style="color:#a78bfa;">Profile</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin/index.php">Admin</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- ── Hero ── -->
        <div class="profile-hero">
            <div class="hero-avatar-wrap">
                <?php if ($avatar_src): ?>
                    <img src="<?php echo $avatar_src; ?>"
                         alt="<?php echo htmlspecialchars($user['name']); ?>"
                         class="hero-avatar">
                <?php else: ?>
                    <div class="hero-avatar-placeholder">👤</div>
                <?php endif; ?>
            </div>
            <div class="hero-info">
                <h1><?php echo htmlspecialchars($user['name']); ?></h1>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
                <span class="hero-badge">
                    <?php echo $user['role'] === 'admin' ? '⭐ Admin' : '🌍 Traveller'; ?>
                </span>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="profile-layout">

            <!-- ══ LEFT COLUMN ══ -->
            <div>
                <!-- Edit Profile -->
                <div class="profile-card">
                    <div class="card-title">👤 Edit Profile</div>

                    <form method="POST" action="" enctype="multipart/form-data" novalidate>
                        <input type="hidden" name="action" value="update_profile">

                        <!-- Avatar upload -->
                        <div class="avatar-upload-row">
                            <?php if ($avatar_src): ?>
                                <img src="<?php echo $avatar_src; ?>"
                                     alt="Avatar" class="form-avatar" id="form-avatar-img">
                            <?php else: ?>
                                <div class="form-avatar-placeholder" id="form-avatar-placeholder">👤</div>
                                <img src="" alt="Avatar" class="form-avatar"
                                     id="form-avatar-img" style="display:none;">
                            <?php endif; ?>

                            <div class="avatar-upload-info">
                                <label for="avatar-file">📷 Change Photo</label>
                                <input type="file" id="avatar-file" name="avatar"
                                       accept="image/jpeg,image/png,image/gif,image/webp"
                                       onchange="previewAvatar(this)">
                                <div class="avatar-upload-hint">JPEG, PNG, GIF or WebP · Max 3 MB</div>
                            </div>
                        </div>

                        <!-- Name + Phone -->
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name *</label>
                                <input type="text" id="name" name="name" required
                                       value="<?php echo htmlspecialchars($user['name']); ?>">
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" id="phone" name="phone"
                                       placeholder="+92 300 0000000"
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                        </div>

                        <!-- Email (read-only) -->
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>"
                                   readonly>
                        </div>

                        <!-- City + Country -->
                        <div class="form-row">
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" placeholder="Karachi"
                                       value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="country">Country</label>
                                <input type="text" id="country" name="country" placeholder="Pakistan"
                                       value="<?php echo htmlspecialchars($user['country'] ?? ''); ?>">
                            </div>
                        </div>

                        <!-- Bio -->
                        <div class="form-group">
                            <label for="bio">Bio</label>
                            <textarea id="bio" name="bio"
                                      placeholder="A short bio about yourself…"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                        </div>

                        <!-- Additional Info -->
                        <div class="form-group">
                            <label for="additional_info">Travel Interests</label>
                            <textarea id="additional_info" name="additional_info"
                                      placeholder="What kind of travel do you enjoy?"><?php echo htmlspecialchars($user['additional_info'] ?? ''); ?></textarea>
                        </div>

                        <button type="submit" class="btn-save">💾 Save Changes</button>
                    </form>
                </div>

                <!-- Change Password -->
                <div class="profile-card">
                    <div class="card-title">🔒 Change Password</div>

                    <form method="POST" action="" novalidate>
                        <input type="hidden" name="action" value="change_password">

                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password"
                                   placeholder="Enter current password">
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password"
                                       placeholder="Min. 6 characters">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password"
                                       placeholder="Repeat new password">
                            </div>
                        </div>

                        <button type="submit" class="btn-save">🔑 Update Password</button>
                    </form>
                </div>
            </div>

            <!-- ══ RIGHT COLUMN ══ -->
            <div>
                <!-- Stats -->
                <?php
                $stats_stmt = $conn->prepare(
                    "SELECT
                        (SELECT COUNT(*) FROM trips       WHERE user_id = ?) AS total_trips,
                        (SELECT COUNT(*) FROM trip_notes  WHERE user_id = ?) AS total_notes,
                        (SELECT COUNT(*) FROM packing_items WHERE user_id = ?) AS packing_items"
                );
                $stats_stmt->bind_param("iii", $user_id, $user_id, $user_id);
                $stats_stmt->execute();
                $stats = $stats_stmt->get_result()->fetch_assoc();
                $stats_stmt->close();
                ?>
                <div class="profile-card">
                    <div class="card-title">📊 Your Stats</div>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-num"><?php echo (int)$stats['total_trips']; ?></div>
                            <div class="stat-label">Trips</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num"><?php echo (int)$stats['total_notes']; ?></div>
                            <div class="stat-label">Notes</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num"><?php echo (int)$stats['packing_items']; ?></div>
                            <div class="stat-label">Packing Items</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">
                                <?php
                                $days = $user['created_at']
                                    ? (int)((time() - strtotime($user['created_at'])) / 86400)
                                    : 0;
                                echo $days;
                                ?>
                            </div>
                            <div class="stat-label">Days Member</div>
                        </div>
                    </div>
                </div>

                <!-- Account Info -->
                <div class="profile-card">
                    <div class="card-title">ℹ️ Account Info</div>

                    <div class="meta-row">
                        <span>📧</span>
                        <span><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <?php if (!empty($user['phone'])): ?>
                    <div class="meta-row">
                        <span>📞</span>
                        <span><?php echo htmlspecialchars($user['phone']); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($user['city']) || !empty($user['country'])): ?>
                    <div class="meta-row">
                        <span>📍</span>
                        <span>
                            <?php
                            $loc = array_filter([
                                htmlspecialchars($user['city']    ?? ''),
                                htmlspecialchars($user['country'] ?? ''),
                            ]);
                            echo implode(', ', $loc);
                            ?>
                        </span>
                    </div>
                    <?php endif; ?>
                    <div class="meta-row">
                        <span>📅</span>
                        <span>Member since <?php echo $user['created_at']
                            ? date('M Y', strtotime($user['created_at']))
                            : 'N/A'; ?></span>
                    </div>
                    <div class="meta-row">
                        <span>🏷️</span>
                        <span><?php echo $user['role'] === 'admin' ? 'Administrator' : 'Traveller'; ?></span>
                    </div>
                </div>

                <!-- Quick links -->
                <div class="profile-card">
                    <div class="card-title">🔗 Quick Links</div>
                    <div style="display:flex;flex-direction:column;gap:10px;">
                        <a href="my_trips.php"   style="color:#667eea;text-decoration:none;font-size:14px;">🗺️ My Trips</a>
                        <a href="dashboard.php"  style="color:#667eea;text-decoration:none;font-size:14px;">📊 Dashboard</a>
                        <a href="create-trip.php" style="color:#667eea;text-decoration:none;font-size:14px;">➕ Create New Trip</a>
                        <a href="logout.php"     style="color:#e74c3c;text-decoration:none;font-size:14px;">🚪 Logout</a>
                    </div>
                </div>
            </div>

        </div><!-- /.profile-layout -->
    </main>

    <footer>
        <p>&copy; 2026 Travel Planner. All rights reserved.</p>
    </footer>
    <script src="assets/js/main.js"></script>
    <script>
        function previewAvatar(input) {
            if (!input.files || !input.files[0]) return;
            const reader = new FileReader();
            reader.onload = e => {
                const img         = document.getElementById('form-avatar-img');
                const placeholder = document.getElementById('form-avatar-placeholder');
                img.src           = e.target.result;
                img.style.display = 'block';
                if (placeholder) placeholder.style.display = 'none';
            };
            reader.readAsDataURL(input.files[0]);
        }
    </script>
</body>
</html>
